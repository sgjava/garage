#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  PXCODE pxErr;
  int    Exist;

  PXInit();

  /* Determine if the table exists. */

  if ((pxErr = PXTblExist(TABLENAME, &Exist)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else 
    if (Exist)
      printf("Table exists.\n");
    else
      printf("Table does not exist.\n");

  PXExit();
    return(pxErr);
}
