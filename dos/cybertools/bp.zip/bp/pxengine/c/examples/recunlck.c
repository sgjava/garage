/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table"
#define NETDIR      ""
#define NETTYPE     NETSHARE

int main(void)
{
  TABLEHANDLE tblHandle;
  LOCKHANDLE  lckHandle;
  PXCODE      pxErr;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXNetRecLock(tblHandle, &lckHandle);

  /* Unlock previously locked record. */

  if ((pxErr = PXNetRecUnlock(tblHandle, lckHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
