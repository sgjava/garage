#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table"
#define NETDIR      ""
#define NETTYPE     NETSHARE

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;
  int         Changed;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Determine if table has been changed. */

  if ((pxErr = PXNetTblChanged(tblHandle, &Changed)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Table has %s\n",Changed ? "changed" : "not changed");
 
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
