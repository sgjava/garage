/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
#define NFLDS        5

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  PXCODE       pxErr;

  PXInit();

  /* Open a table that contains a BLOB field. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Put the record into the buffer. */

  PXRecGet(tblHandle, recHandle);

  /* Clone all existing BLOB fields in the record buffer. */

  if((pxErr = PXBlobClone(recHandle, 0)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  pxErr = PXExit();
  return (pxErr);
}
