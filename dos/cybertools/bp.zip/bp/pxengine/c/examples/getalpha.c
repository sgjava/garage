/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle;
  char         avalue[BUFSIZ];
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXFldHandle(tblHandle,"Field 1",&fldHandle);
  PXRecGet(tblHandle, recHandle);

  /* Get an alphanumeric value from a field. */

  if ((pxErr = PXGetAlpha(recHandle, fldHandle, BUFSIZ, avalue))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Field number %d contents: %s\n", fldHandle,avalue);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
