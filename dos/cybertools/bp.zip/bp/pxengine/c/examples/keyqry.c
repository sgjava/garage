/* The SETUP.C and KEYMAP.C programs must be compiled and run */
/* before this example can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

FIELDHANDLE fields[256];
char        fldName[26];
FIELDHANDLE compSecIndexHandle;
int         nfields;
int         Qmode,i;

int main(void)
{
  PXCODE pxErr;
  
  PXInit();

  if((pxErr = PXKeyQuery("table.xg0", fldName, &nfields,&Qmode, fields,
    &compSecIndexHandle)) != PXSUCCESS)
  printf("%s\n", PXErrMsg(pxErr));
  else
  {
    printf("Field name %s\n", fldName);
    printf("Number of fields %d\n", nfields);
    printf("The fields in this index are: ");
    for (i=0; i<3; i++)
      printf(" %d ", fields[i]);
    printf("\nThe handle for this index is: %d\n", compSecIndexHandle);
  }

  PXExit();
  return(pxErr);
}
