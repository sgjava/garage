#include <stdio.h>
#include "pxengine.h"

int main(void)
{
  PXCODE      pxErr;
  TABLEHANDLE tblHandle;

  PXInit();

  /* Open a non-existent table. */

  pxErr = PXTblOpen("Z:\TOP",&tblHandle,0,0);

  /* Print the associated error message. */

  printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
