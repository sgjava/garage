/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

/* Change the #define below to the full path of the table you wish to open. */
/* For example, you would enter:                                            */
/*                                                                          */
/*   #define TABLENAME "P:\\DATA\\PDOXDATA\\TABLE"                          */
/*                                                                          */
/* for a table located in the PDOXDATA subdirectory of the DATA             */
/* directory on the P: drive.                                               */

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;
    
  /* Attempt to initialize the Engine for local use. */

  pxErr = PXInit();
  if (pxErr != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }

  /* Open a table. */

  if ((pxErr = PXTblOpen(TABLENAME, &tblHandle, 0, 0)) != PXSUCCESS)
        printf("%s\n", PXErrMsg(pxErr));
  else
  {
    PXTblClose(tblHandle);
    printf("opened and closed data table : %s.db\n", TABLENAME);
  }
  PXExit();
  return(pxErr);
}
