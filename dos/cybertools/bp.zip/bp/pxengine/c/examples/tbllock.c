/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define NETDIR       ""
#define TABLENAME    "table"
#define NETTYPE      NETSHARE

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Lock table with full lock. */

  if ((pxErr = PXNetTblLock(tblHandle, FL)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXNetTblUnlock(tblHandle, FL);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
