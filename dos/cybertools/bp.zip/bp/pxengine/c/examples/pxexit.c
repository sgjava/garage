#include <stdio.h>
#include "pxengine.h"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Attempt to close Paradox environment. */

  if ((pxErr = PXExit()) != PXSUCCESS) 
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Engine terminated.\n");
  return(pxErr);
}
