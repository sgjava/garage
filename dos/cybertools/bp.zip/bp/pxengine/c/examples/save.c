/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "numbers"

main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  int          i;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  for (i=0;i<10;++i)
  {
    PXPutDoub(recHandle, 1, (double) i);
    PXRecAppend(tblHandle, recHandle);

    /* Save the table to disk after every fifth append operation. */

    if (i % 5)
      if ((pxErr = PXSave()) != PXSUCCESS)
        printf("%s\n", PXErrMsg(pxErr));
  }
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
