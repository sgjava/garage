/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE tblHandle;
  FIELDHANDLE fldHandle = 1;
  char        fldName[BUFSIZ];
  PXCODE      pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Get the field name for first field in table. */

  if ((pxErr = PXFldName(tblHandle, fldHandle, BUFSIZ, fldName))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Field handle %d has the field name %s\n", fldHandle, fldName);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
