/* The SETUP.C and PUTDATE.C programs must be compiled and run */
/* before this example can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "Numbers"

int main(void)
{
  PXCODE        pxErr;
  int           month, day, year;
  TDATE         date;
  TABLEHANDLE   tblHandle;
  RECORDHANDLE  recHandle;
  FIELDHANDLE   fldHandle;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXFldHandle(tblHandle,"Field 2",&fldHandle);
  PXRecGet(tblHandle,recHandle);
  pxErr = PXGetDate(recHandle, fldHandle, &date);

  /* Decode the date that was just retrieved. */

  if ((pxErr = PXDateDecode(date, &month, &day, &year)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Month: %d  Day: %d  Year: %d\n", month, day, year);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
