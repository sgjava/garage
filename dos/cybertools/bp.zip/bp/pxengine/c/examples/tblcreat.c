#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table1"

char *fields[] = {"Numeric Field", "Alpha Field", "Date Field", 
                  "Currency Field", "Short Field"};

char *types[] = {"N", "A50", "D", "$", "S"};
    
#define NFIELDS  (sizeof(fields) / sizeof(char *))

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Create a new table. */

  if ((pxErr = PXTblCreate(TABLENAME, NFIELDS, fields, types)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
