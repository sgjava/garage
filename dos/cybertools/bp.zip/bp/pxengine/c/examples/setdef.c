#include <stdio.h>
#include "pxengine.h"

main(void)
{
  PXCODE pxErr;

  /* Prepare Engine for initialization using the maximum buffer  */
  /* size, maximum allowable number of tables, maximum number of */
  /* locks and files.  Leave MAXRECBUFs AND SORTORDER at their   */
  /* present value.                                              */

  if ((pxErr = PXSetDefaults(MAXSWAPSIZE,MAXTABLEHANDLES,PXDEFAULT,
    MAXLOCKHANDLES,MAXFILEHANDLES,PXDEFAULT)) != PXSUCCESS)
    printf("%s\n",PXErrMsg(pxErr));

  /* Call PXInit with new default values. */

  PXInit();
  PXExit();
  return(pxErr);
}
