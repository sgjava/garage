#include <stdio.h>
#include "pxengine.h"

main(void)
{
  PXCODE pxErr;
  char   *sortTable;
  int    maxSwapsize,maxTableHandles,maxRecBufs,
           maxLockHandles,maxFileHandles;

  PXSetDefaults(MAXSWAPSIZE,MAXTABLEHANDLES,PXDEFAULT,
    MAXLOCKHANDLES,MAXFILEHANDLES,PXDEFAULT);

  /* Retrieve the current defaults. */

  if ((pxErr = PXGetDefaults(&maxSwapsize,&maxTableHandles,&maxRecBufs,
    &maxLockHandles,&maxFileHandles,&sortTable)) != PXSUCCESS)
    printf("%s\n",PXErrMsg(pxErr));
  else
  {
    printf("Swap Size: %d\nTable Handles: %d\nRecord Buffers: %d\n",
      maxSwapsize,maxTableHandles,maxRecBufs);
    printf("Lock Handles: %d\nFile Handles: %d\nSort Table: %s\n",
      maxLockHandles,maxFileHandles,
      sortTable == DEFSORTORDER ? "System Default":sortTable);
  }
  return (pxErr);
}
