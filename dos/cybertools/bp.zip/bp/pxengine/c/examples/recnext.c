/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include <stdlib.h>
#include "pxengine.h"

#define TABLENAME   "numbers"
#define MAXRECS      9

FIELDHANDLE hFldsSecondary[] = { 1 };

int main(void)
{
  TABLEHANDLE   tblHandle;
  RECORDHANDLE  recHandle;
  RECORDNUMBER  recNum;
  PXCODE        pxErr;
  long          recValue;
  int           i;

  /* Attempt to initialize the Engine for local use. */

  pxErr = PXInit();
  if (pxErr != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }

  /* Delete contents of table if they exist. */

  PXTblEmpty(TABLENAME);

  /* Delete all indexes for table. */

  PXKeyDrop(TABLENAME, 0);

  /* Open table after deleting records and indexes. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Open a record buffer for use in appending records. */

  PXRecBufOpen(tblHandle, &recHandle);

  /* Loop and add 20 records to the table. */

  for (i = 0; i < MAXRECS; i++)
  {
    /* Put a long value into field one. */

    recValue = (long) rand();
    PXPutLong(recHandle, 1, recValue);

    /* Insert this new record to the table. */

    if ((pxErr = PXRecInsert(tblHandle, recHandle)) != PXSUCCESS)
      printf("1 %s\n", PXErrMsg(pxErr));
  }
    
  /* Go to first record. */

  PXRecFirst(tblHandle);

  /* Print out values of Number field for records 1 to 20. */

  printf("--- Retrieval of records using PXRecNext() in unkeyed order ---\n");
  for (recNum = 1; recNum < MAXRECS; recNum++)
  {
    PXRecGet(tblHandle, recHandle);
    PXGetLong(recHandle, 1, &recValue);
    printf("Record %ld has value %ld\n", recNum, recValue);
    PXRecNext(tblHandle);
  }

  /* Create a secondary index on field 1. */

  if ((pxErr = PXKeyAdd(TABLENAME, 1, hFldsSecondary, SECONDARY))
    != PXSUCCESS)
    printf("0 %s\n", PXErrMsg(pxErr));

  /* Open table on our new index. */

  PXTblOpen(TABLENAME, &tblHandle, 1, 0);
    
  /* Go to first record. */

  PXRecFirst(tblHandle);

  /* Print out values of Number field for records 1 - 20. */

  printf("\n--- retrieval of records using PXRecNext() in keyed order ---\n");
  for (recNum = 1; recNum < MAXRECS; recNum++)
  {
    PXRecGet(tblHandle, recHandle);
    PXGetLong(recHandle, 1, &recValue);
    printf("record %ld has value %ld\n", recNum, recValue);
    PXRecNext(tblHandle);
  }
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
