/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle = 3;
  short        svalue = 321;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Update record with short value. */

  if ((pxErr = PXPutShort(recHandle, fldHandle, svalue))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXRecUpdate(tblHandle,recHandle);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
