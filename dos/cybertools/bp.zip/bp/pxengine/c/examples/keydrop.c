/* The SETUP.C and KEYADD.C programs must be compiled and run */
/* before this example can be executed. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pxengine.h"

#define TABLENAME  "table"

char  commandline[128];   /* String buffer used to build command line. */

int main(void)
{
  PXCODE   pxErr;

  /* Attempt to initialize the Engine for local use. */

  pxErr = PXInit();
  if (pxErr != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }

  /* Show directory of table indexes before PXKeyDrop(). */

  strcpy(commandline, "dir ");
  strcat(commandline, TABLENAME);
  strcat(commandline, ".*");
  printf("--- Directory of table indexes before PXKeyDrop() --- \n");
    system(commandline);
  
  /* Remove all indexes, including secondary indexes. */

  if ((pxErr = PXKeyDrop(TABLENAME, 0)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Show directory after dropping indexes. */

  printf("\n--- Directory of table indexes after PXKeyDrop() --- \n");
  system(commandline);

  PXExit();
  return(pxErr);
}
