/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
#define BLOBSIZE    512

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle;
  BLOBHANDLE   blbHandle;
  PXCODE       pxErr;

  PXInit();

  /* Open a table that contains a BLOB field. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecFirst(tblHandle);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  /* Open a new BLOB field for writing. */

  fldHandle = 4;
  if((pxErr = PXBlobOpenWrite(recHandle, fldHandle, &blbHandle,
    BLOBSIZE, PXBLOBNEW)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXBlobClose(blbHandle, PXBLOBACCEPT);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return (pxErr);
}
