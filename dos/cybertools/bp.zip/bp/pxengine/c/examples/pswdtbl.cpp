//  Borland Paradox Engine 3.0 Database Framework program example
//  Copyright (c) 1992 by Borland International   
//  
//  PSWDTBL - provides an example showing how to password protect a
//            table using the Database Framework.
//

#include <iostream.h>
#include <string.h>

// Paradox Engine 3.0 Header files.

#include <pxengine.h>
#include <envdef.h>   // Environment definitions for Database Framework.
#include <bengine.h>  // Header file for the BEngine class.
#include <bdatabas.h> // Header file for the BDatabase class.

// Specify the name of the table you want to create.

const char *tblName = "table1";

// Call the BEngine constructor and initialize the engine to
// single user or "PXInit()" mode.

BEngine Eng(pxLocal);

// Create and open the BDatabase instance DB with respect
// to the BEngine instance Eng.

BDatabase DB(&Eng);

// Array of field descriptors for the table, needed for the
// createTable member function in the BDatabase class.

FieldDesc fldArray[3];

// Number of fields in our table.

const int numFields = sizeof(fldArray) / sizeof(fldArray[0]);

int main()
{

  // Fill in the FieldDesc structure for every field in the table.

  fldArray[0].fldNum = 1;
  strcpy(fldArray[0].fldName, "Name");
  fldArray[0].fldType = fldChar;  // Create an alphanumeric field.
  fldArray[0].fldLen = 50;        // Specify the length of the field.

  fldArray[1].fldNum = 2;
  strcpy(fldArray[1].fldName, "Address");
  fldArray[1].fldType = fldChar;
  fldArray[1].fldLen = 50;

  fldArray[2].fldNum = 3;
  strcpy(fldArray[2].fldName, "Age");
  fldArray[2].fldType = fldShort;  // Create a short field.

  // Create the table 'tblName' with the structure provided in the
  // array of field descriptors fldArray.

  DB.createTable(tblName, numFields, fldArray);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "Table creation error: " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "Table '" << tblName << "' created successfully" << endl;

  // Password protect the table with the password "GARCIA".

  DB.encryptTable(tblName, "GARCIA");

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "Table encryption error: " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "Table '" << tblName << "' encrypted successfully" << endl;


  // Check if the table has been encrypted.

  if (DB.isProtected(tblName))
    cout << "Table 'tblName' is password-protected " << endl;
  else
    cout << "Table 'tblName' is not password-protected " << endl;

  // To access the table you must now add the password to the system
  // using the addPassword member function of the BEngine class
  // and decrypt the table with the decryptTable member function of
  // the BDatabase class.

  Eng.addPassword("GARCIA"); // Adds password to engine.

  if (Eng.lastError != PXSUCCESS)
    cout << "Error adding password to the system: " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "Password 'GARCIA' added to the engine" << endl;

  DB.decryptTable(tblName);  // Decrypts table with password.
  if (DB.lastError != PXSUCCESS)
    cout << "table decryption error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "table '" << tblName << "' decrypted successfully" << endl;

  // Check once again if the table is password-protected.

  if (DB.isProtected(tblName))
    cout << "now Table 'tblName' is password-protected" << endl;
  else
    cout << "now Table 'tblName' is not password-protected" << endl;

  return DB.lastError;

}
