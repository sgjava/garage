#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "newtbl"

char *fields[] = {"Numeric Field", "Alpha Field", "Date Field", 
                  "Currency Field", "Short Field"};

char *types[] = {"N", "A50", "D", "$", "S"};

TABLEHANDLE  tblHandle;
    
#define NFIELDS  (sizeof(fields) / sizeof(char *))

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Force tables to be created in Paradox 3.5 format. */

  PXTblCreateMode(PARADOX35);

  /* Create a new table. */

  if ((pxErr = PXTblCreate(TABLENAME, NFIELDS, fields, types)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Open table. */

  if ((pxErr = PXTblOpen(TABLENAME, &tblHandle, 0, 0)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Change table format to Paradox 4.0. */

  if ((pxErr = PXTblUpgrade(tblHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Close the table. */

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
