#include <stdio.h>
#include "pxengine.h"

#define PASSWORD   "password"
#define TABLENAME  "table"

int main(void)
{
  PXCODE pxErr;
  int    Protected;

  PXInit();

  /* Determine if table is protected. */

  if ((pxErr = PXTblProtected(TABLENAME, &Protected)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else 
    if (Protected)
      printf("Table is protected.\n");
    else
      printf("Table is not protected.\n");

  PXExit();
  return(pxErr);
}
