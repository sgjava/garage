/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include <stdlib.h>
#ifndef __TURBOC__
  #define randomize() srand(3)
  #define random(x)   rand() % x
#endif

#include "pxengine.h"

#define TABLENAME  "numbers"

FIELDHANDLE hFldsPrimary[] = { 1 };

int main(void)
{
  TABLEHANDLE   tblHandle;
  RECORDHANDLE  recHandle;
  RECORDNUMBER  recNum;
  PXCODE        pxErr;
  long          recValue;
  int           i;

  /* Attempt to initialize the Engine for local use. */

  pxErr = PXInit();
  if (pxErr != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }

  /* Delete contents of table if they exist. */

  PXTblEmpty(TABLENAME);

  /* Delete all indexes for table. */

  PXKeyDrop(TABLENAME, 0);

  /* Create a primary index on field 1. */

  if ((pxErr = PXKeyAdd(TABLENAME, 1, hFldsPrimary, PRIMARY))
    != PXSUCCESS)
    printf("0 %s\n", PXErrMsg(pxErr));

  /* Open the table on the primary index. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Open a record buffer for use in appending records. */

  PXRecBufOpen(tblHandle, &recHandle);

  /* Loop and add 20 records to the table. */

  for (i = 0; i < 20; i++)
  {
    /* Put a long value into field one. */

    recValue = (long) random(1959);
    PXPutLong(recHandle, 1, recValue);

    /* Append this new record to the table. */

    if ((pxErr = PXRecAppend(tblHandle, recHandle)) != PXSUCCESS)
        printf("1 %s\n", PXErrMsg(pxErr));

    /* Get the current record number (may not reflect current record
       number if users update table on a network). */

    PXRecNum(tblHandle, &recNum);

    /* Print out the record number of the added record. It should be    */
    /* clear from the result that a record append operation does not    */
    /* necessarily add a record to the end of a table if the table      */
    /* is opened with an index. When an ordered table, a record append  */
    /*  operation is equivalent to inserting a record.                  */
    
    printf("Record added at position %d\n", recNum);
  }

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
