//  Borland Paradox Engine 3.0 Database Framework program example
//  Copyright (c) 1992 by Borland International   
//  
//  PUTFIELD - provides an example showing how to insert a new 
//             record in a table using the Database Framework. 
//

#include <iostream.h>
#include <string.h>

// Paradox Engine 3.0 Header files.

#include <pxengine.h>
#include <envdef.h>   // Environment definitions for Database Framework.
#include <bengine.h>  // Header file for the BEngine class.
#include <bdatabas.h> // Header file for the BDatabase class.
#include <bcursor.h>  // Header file for the BCursor class.
#include <brecord.h>  // Header file for the BRecord class.

// Prototype for function to create a table.

void InitTable(void);

// Specify the name of the table you want to create.

const char *tblName = "table1";

// Call the BEngine constructor and initialize the engine to
// single user or "PXInit()" mode.

BEngine Eng(pxLocal);

// Create and open the BDatabase instance DB with respect to the
// BEngine instance Eng.

BDatabase DB(&Eng);

// Array of field descriptors for the table, needed for the
// createTable member function in the BDatabase class.

FieldDesc fldArray[5];

// Determine number of fields.

const int numFields = sizeof(fldArray) / sizeof(fldArray[0]);

int main()
{

  InitTable();   // Create a table to work with.

  // Dynamically create a BCursor object. A cursor allows
  // you to open and manipulate a Paradox table.

  BCursor *tblCursor = new BCursor(&DB, tblName, 0, FALSE);

  if (tblCursor->lastError != PXSUCCESS)
    cout << "error '" << Eng.getErrorMessage(tblCursor->lastError) <<
      "' in opening BCursor 'tblCursor.'" << endl;
  else
    cout << "cursor created successfully" << endl;

  // Go to the first record in the table.

  // Note that you must use gotoNext after gotoBegin to get to
  // the first record. When a BCursor is first opened, the cursor
  // status is 'atBegin', not 'atRecord'. No error checking is done.

  tblCursor->gotoBegin();
  tblCursor->gotoNext();

  // Fill the genericRec member of the BCursor class and insert
  // it into the table. Use a BRecord pointer to avoid extra
  // dereferencing. Also check the return value of putField for
  // an error instead of using lastError.

  BRecord *genRec = tblCursor->genericRec;

  Retcode pxErr;  // Store the return code from putField.

  pxErr = genRec->putField(1, "Frank Borland");
  if (pxErr != PXSUCCESS)
    cout << "error in putField to field 1" << endl;

  pxErr = genRec->putField(2, "Santa's Village");
  if (pxErr != PXSUCCESS)
    cout << "error in putField to field 2" << endl;

  pxErr = genRec->putField(3, 31);
  if (pxErr != PXSUCCESS)
    cout << "error in putField to field 3" << endl;


  BDate BDay;   // Create a BDate for field number 4.

  BDay.year  = 1961;
  BDay.month = 10;
  BDay.day   = 31;

  // Put the date information into field number 4.

  pxErr = genRec->putField(4, &BDay);
  if (pxErr != PXSUCCESS)
    cout << "error in putField to field 4" << endl;

  // Create a double value for field number 5.

  double weight = 185.5;

  pxErr = genRec->putField(5, weight);
  if (pxErr != PXSUCCESS)
    cout << "error in putField to field 5" << endl;

  // Insert the record.

  tblCursor->insertRec(genRec);

  // Check for errors.

  if (tblCursor->lastError)
  {
    cout << "Error inserting record: ";
    cout << Eng.getErrorMessage(tblCursor->lastError) << endl;
  }
  else
    cout << "Record inserted successfully" << endl;

  // Close the cursor, which closes the table as well.

  tblCursor->close();

  return 0;

}


void InitTable(void)
{

  // Fill in the FieldDesc structure for every field in the table.

  fldArray[0].fldNum = 1;
  strcpy(fldArray[0].fldName, "Name");
  fldArray[0].fldType = fldChar;      // Create an alphanumeric field.
  fldArray[0].fldLen = 50;            // Specify the length of the field.

  fldArray[1].fldNum = 2;
  strcpy(fldArray[1].fldName, "Address");
  fldArray[1].fldType = fldChar;
  fldArray[1].fldLen = 50;

  fldArray[2].fldNum = 3;
  strcpy(fldArray[2].fldName, "Age");
  fldArray[2].fldType = fldShort;     // Create a short field.

  fldArray[3].fldNum = 4;
  strcpy(fldArray[3].fldName, "Date of Birth");
  fldArray[3].fldType = fldDate;      // Create a date field.

  fldArray[4].fldNum = 5;
  strcpy(fldArray[4].fldName, "Weight");
  fldArray[4].fldType = fldDouble;    // Create a double field.

  // Create the Table 'tblName' with the structure provided in the
  // array of field descriptors fldArray.

  DB.createTable(tblName, numFields, fldArray);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "table create error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "table '" << tblName << "' created successfully" << endl;

}
