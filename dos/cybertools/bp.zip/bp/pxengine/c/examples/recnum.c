/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDNUMBER recNumber;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Get the current record number. */

  if ((pxErr = PXRecNum(tblHandle, &recNumber)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Current record number is %d\n", recNumber);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
