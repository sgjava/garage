/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle = 1;
  PXCODE       pxErr;
  int          Blank;

  PXInit();
  pxErr = PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  /* See if the field is blank. */

  if ((pxErr = PXFldBlank(recHandle, fldHandle, &Blank)) 
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else 
  {
    if (Blank) 
      printf("Field is blank.\n");
    else
      printf("Field is not blank.\n");
  }

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
