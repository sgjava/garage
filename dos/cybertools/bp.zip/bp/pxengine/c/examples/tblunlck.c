/* The SETUP.C program must be compiled and run before this example  */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table"
#define NETDIR      ""
#define NETTYPE     NETSHARE

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXNetTblLock(tblHandle, FL);

  /* Remove a full lock from a table. */

  if ((pxErr = PXNetTblUnlock(tblHandle, FL)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
