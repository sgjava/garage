/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE tblHandle;
  int         nKeyFlds;
  PXCODE      pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Determine how many fields are in index. */

  if ((pxErr = PXKeyNFlds(tblHandle, &nKeyFlds)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Number of fields in key: %d\n", nKeyFlds);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
