#include <stdio.h>
#include "pxengine.h"

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;
  int         x;

  /* Enable hardware handler so functions, rather than DOS, */
  /* return errors, */

  if ((pxErr = PXSetHWHandler(TRUE)) != PXSUCCESS)
    printf("%s\n",PXErrMsg(pxErr));

  PXInit();
  printf("Open drive A: and press any key to continue.\n");
  x = getchar();
  while (PXTblOpen("A:TABLE",&tblHandle,0,0) == PXERR_DRIVENOTREADY)
  {
    printf("Place disk in drive A:. Press return when ready.\n");
    x = getchar();
    x++;
  }
  PXExit();
  return (pxErr);
}
