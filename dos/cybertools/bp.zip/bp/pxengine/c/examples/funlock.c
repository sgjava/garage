/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define NETTYPE    NETSHARE
#define NETDIR     ""
#define FILENAME   "table.db"

int main(void)
{
  PXCODE pxErr;

  PXNetInit(NETDIR, NETTYPE, DEFUSERNAME);
  PXNetFileLock(FILENAME, WL);

  /* Attempt to unlock a file write lock. */

  if ((pxErr = PXNetFileUnlock(FILENAME, WL)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
