//  Borland Paradox Engine 3.0 Database Framework program example
//  Copyright (c) 1992 by Borland International   
//  
//  LOCKTBL - provides an example showing how to lock a file on 
//            the network using the Database Framework.
//

#include <iostream.h>
#include <string.h>

// Paradox Engine 3.0 Header files.

#include <pxengine.h>
#include <envdef.h>   // Environment definitions for Database Framework.
#include <bengine.h>  // Header file for the BEngine class.
#include <bdatabas.h> // Header file for the BDatabase class.

// Specify the name of the table you want to create.

const char *tblName = "table1";

// Call the BEngine constructor and initialize the engine to
// "network" or "PXNetInit()" mode.

BEngine Eng(pxNet);

// Create and open the BDatabase instance DB with respect
// to the BEngine instance Eng.

BDatabase DB(&Eng);

// Array of field descriptors for the table, needed for the
// createTable member function in the BDatabase class.

FieldDesc fldArray[3];

// Number of fields in the table.

const int numFields = sizeof(fldArray) / sizeof(fldArray[0]);

int main()
{
  if (Eng.lastError != PXSUCCESS)
    cout << "network initialization failed" <<
      Eng.getErrorMessage(DB.lastError) << endl;

  // Fill in the FieldDesc structure for every field in the table.

  fldArray[0].fldNum = 1;
  strcpy(fldArray[0].fldName, "Name");
  fldArray[0].fldType = fldChar;  // Create an alphanumeric field.
  fldArray[0].fldLen = 50;        // Specify the length of the field.

  fldArray[1].fldNum = 2;
  strcpy(fldArray[1].fldName, "Address");
  fldArray[1].fldType = fldChar;
  fldArray[1].fldLen = 50;

  fldArray[2].fldNum = 3;
  strcpy(fldArray[2].fldName, "Age");
  fldArray[2].fldType = fldShort;  // Create a short field.

  // Create the table 'tblName' with the structure provided in the
  // array of field descriptors fldArray.

  DB.createTable(tblName, numFields, fldArray);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
     cout << "table create error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
     cout << "table '" << tblName << "' created successfully" << endl;

  // Place a Full Lock on the table - see pxLockMode enumeration in
  // envdef.h for other types of locks.

  DB.lockNetFile(tblName, pxFL);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "network file locking error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "network file '" << tblName << "' locked successfully" << endl;

  // Unlock the file.

  DB.unlockNetFile(tblName, pxFL);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "network file unlocking error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "network file '" << tblName << "' unlocked successfully"
      << endl;

  return DB.lastError;

}
