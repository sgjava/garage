/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define SOURCETABLE   "table"
#define DESTTABLE     "table2"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Copy one table to another. */

  if ((pxErr = PXTblCopy(SOURCETABLE, DESTTABLE)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
