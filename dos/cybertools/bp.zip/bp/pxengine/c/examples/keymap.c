/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
#define MODE 0

FIELDHANDLE fields[] = { 1, 3, 6 };
FIELDHANDLE fldHandles[6];

int main(void)
{
  TABLEHANDLE tblHandle;
  FIELDHANDLE compSecIndexHandle;
  PXCODE      pxErr;

  PXInit();

  /* Determine field handle of composite index. */

  if((pxErr = PXKeyMap(TABLENAME, 3, fields, "New Order", MODE,
    &compSecIndexHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Add the composite secondary index to the table. */

  fldHandles[0] = compSecIndexHandle;
  if ((pxErr = PXKeyAdd(TABLENAME, 1, fldHandles, SECONDARY))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Open a table on the composite index. */

  PXTblOpen(TABLENAME, &tblHandle, compSecIndexHandle, 0);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
