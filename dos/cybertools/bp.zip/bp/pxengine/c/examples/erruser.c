/* The program "SETUP" must be compiled and run before this example will */
/* execute correctly. */

#include <stdio.h>
#include <string.h>
#include "pxengine.h"

#define NETDIR          "P:\\pdoxdata\\"
#define TABLENAME       "table"
#define NETTYPE		NETSHARE

int main(void)
{
    TABLEHANDLE tblHandle;
    PXCODE      pxErr;
    char        userName[BUFSIZ];

    PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
    PXTblOpen(TABLENAME, &tblHandle, 0, 0);

    /* Determine which user is causing a locking error */
    if ((pxErr = PXNetErrUser(BUFSIZ, userName)) != PXSUCCESS)
       printf("Error when calling PXNetErrUser -> %s\n", PXErrMsg(pxErr));
    else
    {
       if (strlen(userName) != 0)
            printf("The user causing the network error is %s\n", userName);
       else
            printf("No network error\n");
    }

    PXTblClose(tblHandle);
    PXExit();
    return(pxErr);
}
