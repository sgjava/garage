/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle = 3;
  long         lvalue = 76543L;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Update record with long value. */

  if ((pxErr = PXPutLong(recHandle, fldHandle, lvalue))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXRecUpdate(tblHandle,recHandle);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
