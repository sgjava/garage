#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Delete the table. */

  if ((pxErr = PXTblDelete(TABLENAME)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
