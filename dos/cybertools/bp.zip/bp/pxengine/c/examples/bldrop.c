/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

TABLEHANDLE   tblHandle;
RECORDHANDLE  recHandle;
BLOBHANDLE    blbHandle;
PXCODE        pxErr;

void main(void)
{
  PXInit();

  /* Open a table that contains a BLOB field. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Get a record with a reference to a BLOB in field 4. */

  PXRecGet(tblHandle, recHandle);

  /* Free the space associated with the BLOB referenced in field 4. */

  if((pxErr = PXBlobDrop(recHandle, 4)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
}
