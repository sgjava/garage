/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
char search[] = "SearchString";

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle = 1;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXPutAlpha(recHandle, fldHandle, search);

  /* Search for a match on Alpha field. */

  if ((pxErr = PXSrchFld(tblHandle, recHandle, fldHandle, 
    SEARCHFIRST)) != PXSUCCESS)
  {
    if (pxErr == PXERR_RECNOTFOUND)
      printf("No match found.\n");
    else
      printf("%s\n",PXErrMsg(pxErr));
  }
  else
    printf("Match found.\n");

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
