/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define PASSWORD    "password"
#define TABLENAME   "table"

int main(void)
{
  PXCODE pxErr;
  int    Protected;

  PXInit();
  PXTblProtected(TABLENAME, &Protected);

  if (Protected) 
    pxErr = PXPswAdd(PASSWORD);

  /* Open encrypted table, and when done with table, delete password 
     from system, if necessary. */

  if (Protected)
    if ((pxErr = PXPswDel(PASSWORD)) != PXSUCCESS)
      printf("%s\n",PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
