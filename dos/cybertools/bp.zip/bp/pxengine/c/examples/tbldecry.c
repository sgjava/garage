/* The SETUP.C and TBLENCRY.C programs must be compiled and run */
/* before this example can be executed.                         */

#include <stdio.h>
#include "pxengine.h"

#define PASSWORD    "password"
#define TABLENAME   "table"

int main(void)
{
  PXCODE pxErr;

  PXInit();
  PXPswAdd(PASSWORD);

  /* Attempt to decrypt the table. */

  if ((pxErr = PXTblDecrypt(TABLENAME)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
