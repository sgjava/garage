/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

TABLEHANDLE   tblHandle;
RECORDHANDLE  recHandle;
BLOBHANDLE    blbHandle;
PXCODE        pxErr;

int main(void)
{
  PXInit();

  /* Open a table that contains a BLOB field at field 4. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  /* Open a BLOB for writing and then close it at field handle = 4. */

  if((pxErr = PXBlobOpenWrite(recHandle, 4, &blbHandle, 2000, PXBLOBNEW))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXBlobClose(blbHandle, PXBLOBACCEPT);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return (pxErr);
}
