/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
#define CASEINS 1

int main(void)
{
  TABLEHANDLE tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE indexID;
  FIELDHANDLE fields[] = {6};
  FIELDHANDLE fldHandles[6];
  char buff[BUFSIZ];
  PXCODE pxErr;

  PXInit();

  /* Add a case-insensitive composite secondary index. */

  PXKeyMap(TABLENAME, 1, fields, "Case Insens. Index", CASEINS, &indexID);
  fldHandles[0] = indexID;
  PXKeyAdd(TABLENAME, 1, fldHandles, SECONDARY);

  /* Open the table on the composite secondary index. */

  PXTblOpen(TABLENAME, &tblHandle, indexID, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Search for a value that appears twice in table (in upper */
  /* and lower case).   */

  PXPutAlpha(recHandle, 6, "cat");
  if ((pxErr = PXSrchFld(tblHandle, recHandle, indexID, SEARCHFIRST))
    != PXSUCCESS)
  {
    if (pxErr == PXERR_RECNOTFOUND)
      printf("No match found.\n");
    else
      printf("%s\n", PXErrMsg(pxErr));
  }
  else
  {
    PXRecGet(tblHandle, recHandle);
    PXGetAlpha(recHandle, 6, BUFSIZ, buff);
    printf("The first value found was %s\n", buff);
  }

  if ((pxErr = PXSrchFld(tblHandle, recHandle, indexID, SEARCHNEXT))
    != PXSUCCESS)
  {
    if (pxErr == PXERR_RECNOTFOUND)
      printf("No match found.\n");
    else
      printf("%s\n", PXErrMsg(pxErr));
  }
  else
  {
    PXRecGet(tblHandle, recHandle);
    PXGetAlpha(recHandle, 6, BUFSIZ, buff);
    printf("The next value found was %s\n", buff);
  }


  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
