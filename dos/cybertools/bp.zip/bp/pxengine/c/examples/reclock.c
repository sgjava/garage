/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table"
#define NETDIR      ""
#define NETTYPE     NETSHARE

int main(void)
{
  RECORDHANDLE recHandle;
  TABLEHANDLE  tblHandle;
  LOCKHANDLE   lckHandle;
  PXCODE       pxErr;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Attempt to lock current record. */

  if ((pxErr = PXNetRecLock(tblHandle, &lckHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXNetRecUnlock(tblHandle, lckHandle);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
