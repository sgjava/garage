#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table1"
#define MAXSIZE      128          /* in Megabytes */

char *fields[] = {"Numeric Field", "Alpha Field", "Date Field",
                  "Currency Field", "Short Field"};

char *types[] = {"N", "A50", "D", "$", "S"};
    
#define NFIELDS  (sizeof(fields) / sizeof(char *))

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Set the maximum table size before creating table. */

  if ((pxErr = PXTblMaxSize(MAXSIZE)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
    
  PXTblCreate(TABLENAME, NFIELDS, fields, types);
  PXExit();
  return(pxErr);
}
