/* This program sets up two tables for use by the example programs. */
/* TABLE contains two BLOB fields and four records.  NUMBERS is     */
/* an empty table containing a numeric and a date field.            */

#include "pxengine.h"
#include <stdio.h>
#include <stdlib.h>
#include <io.h>
#include <fcntl.h>
#ifndef __TURBOC__
  #include <malloc.h>
  #include <sys\types.h>
  #include <errno.h>
#else
  #include <alloc.h>
#endif
#include <sys\stat.h>

#define TABLENAME  "table"
#define NFLDS       6

/* Prototypes */

int  PX(int rc);
void Initialize(void);
void MakeNumbersTable(void);
void MakeNewRecord(RECORDHANDLE recHandle, char *keyValue,
       char *secIndexValue);
void SetupRecordBuffer(TABLEHANDLE tblHandle, RECORDHANDLE *recHandle);
void StuffBuffer(void);
void MakeAndFillTable(void);
void ExitEngine(void);

char  *buffer;
long  file_length;

void main(void)
{
  Initialize();
  MakeAndFillTable();
  MakeNumbersTable();
  ExitEngine();
}

/*****************************************/
/*               FUNCTIONS               */
/*****************************************/

#ifdef __TURBOC__
#pragma warn -rvl    /* Turn off warning for Borland compilers. */
#endif

int PX(int rc)
{
  if (!rc)
    return rc;
  else
  {
    printf("Engine Error:  %s", PXErrMsg(rc));
    exit(rc);
  }
}

#ifdef __TURBOC__
#pragma warn +rvl    /* Turn warning back on. */
#endif

void Initialize(void)
{
  PX(PXInit());
}

/* Fill buffer from an existing text file such as RECNEXT.C. */

void StuffBuffer(void)
{
  int      input_file;
  unsigned buffer_length;

  input_file = open("recnext.c", O_RDONLY | O_TEXT);
  buffer_length = (unsigned) filelength(input_file);
  buffer = (char *) malloc(buffer_length);
  if (buffer)
    file_length = read(input_file, buffer, buffer_length);
  close(input_file);
}

void MakeAndFillTable(void)
{
  static char * Fields[] = {"Field 1",
                            "Field 2",
                            "Field 3",
                            "Field 4",   /* the BLOB fields */
                            "Field 5",
                            "Field 6"};

  static char * Types[] = {"A30",
                           "A30",
                             "N",
                           "M40",       /* the BLOB fields, Fields 4 & 5 */
                           "M20",
                            "A3"};

  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;

  /* prepare BLOB buffer */
  StuffBuffer();

  /* Create and open a table that contains a BLOB field. */

  PX(PXTblCreate(TABLENAME, NFLDS, Fields, Types));
  PX(PXTblOpen(TABLENAME, &tblHandle, 0, 0));

  SetupRecordBuffer(tblHandle, &recHandle);
  PX(PXRecAppend(tblHandle, recHandle));

  MakeNewRecord(recHandle, "Value 2", "cat");
  PX(PXRecAppend(tblHandle, recHandle));

  MakeNewRecord(recHandle, "Value 3", "CAT");
  PX(PXRecAppend(tblHandle, recHandle));

  MakeNewRecord(recHandle, "Value 4", "map");
  PX(PXRecAppend(tblHandle, recHandle));

  PX(PXRecBufClose(recHandle));
  PX(PXTblClose(tblHandle));

}
/* Set up a record buffer for the predefined table structure. */

void SetupRecordBuffer(TABLEHANDLE tblHandle, RECORDHANDLE *recHandle)
{
  BLOBHANDLE blbHandle;
  PXRecBufOpen(tblHandle, recHandle);
  PX(PXPutAlpha(*recHandle, 1, "SearchString"));
  PX(PXPutAlpha(*recHandle, 2, "Data"));
  PX(PXPutDoub(*recHandle, 3, 3422));
  PXPutAlpha(*recHandle, 6, "Car");

  PX(PXBlobOpenWrite(*recHandle, 4, &blbHandle, 5000, PXBLOBNEW));
  PX(PXBlobPut(blbHandle,(unsigned)file_length, 0, buffer));
  PX(PXBlobClose(blbHandle, PXBLOBACCEPT));

  PX(PXBlobOpenWrite(*recHandle, 5, &blbHandle, 5000, PXBLOBNEW));
  PX(PXBlobPut(blbHandle, (unsigned)file_length, 0, buffer));
  PX(PXBlobClose(blbHandle, PXBLOBACCEPT));
}

void MakeNewRecord(RECORDHANDLE recHandle, char *keyValue,
  char *secIndexValue)
{
  PXBlobClone(recHandle, 0);
  PXPutAlpha(recHandle, 1, keyValue);
  PXPutAlpha(recHandle, 6, secIndexValue);
}
 
void MakeNumbersTable(void)
{
  static char * OtherFields[] = {"Field 1", "Field 2"};
  static char * OtherTypes[] = {"N", "D"};
  PX(PXTblCreate("Numbers", 2, OtherFields, OtherTypes));
}

void ExitEngine(void)
{
  PX(PXExit());
}
