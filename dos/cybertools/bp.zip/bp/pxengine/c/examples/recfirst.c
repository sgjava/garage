/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Go to the first record. */

  if ((pxErr = PXRecFirst(tblHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
