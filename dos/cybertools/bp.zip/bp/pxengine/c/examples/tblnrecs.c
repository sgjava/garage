#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDNUMBER nRecs;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Determine how many records are in table. */

  if ((pxErr = PXTblNRecs(tblHandle, &nRecs)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Number of records: %d\n", nRecs);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
