//  Borland Paradox Engine 3.0 Database Framework program example
//  Copyright (c) 1992 by Borland International   
//  
//  FLDCOUNT - provides an example showing how to dynamically create
//             a cursor, count the number of records in a table and
//             count the number of fields using the Database Framework.
//

#include <iostream.h>
#include <string.h>

// Paradox Engine 3.0 Header files.

#include <pxengine.h>
#include <envdef.h>   // Environment definitions for Database Framework.
#include <bengine.h>  // Header file for the BEngine class.
#include <bdatabas.h> // Header file for the BDatabase class.
#include <bcursor.h>  // Header file for the BCursor class.
#include <brecord.h>  // Header file for the BRecord class.

// Prototype for function that creates a table.

void InitTable(void);

// Specify the name of the table you want to create.

const char *tblName = "table1";

// Call the BEngine constructor and initialize the engine to
// single user or "PXInit()" mode.

BEngine Eng(pxLocal);

// Create and open the BDatabase instance DB with respect
// to the BEngine instance Eng.

BDatabase DB(&Eng);

int main(void)
{
  long numRecs;    // Number of records in the table.
  int  numFields;  // Number of fields in the table.

  if (!DB.tableExists(tblName))
    InitTable();      // Create a table.

  // Dynamically create a BCursor object. A cursor allows
  // you to open and manipulate a Paradox table.

  BCursor *tblCursor = new BCursor(&DB, tblName, 0, FALSE);

  // Check to see if there was an error.

  if (tblCursor->lastError != PXSUCCESS)
    cout << "error '" << Eng.getErrorMessage(tblCursor->lastError) <<
      "' in opening BCursor 'tblCursor.'" << endl;
  else
    cout << "cursor created successfully" << endl;

  // Get the number of records in the table.

  numRecs = tblCursor->getRecCount();

  // Check to see if there was an error.

  if (tblCursor->lastError != PXSUCCESS)
    cout << "error '" << Eng.getErrorMessage(tblCursor->lastError) <<
      "' in getting number of records" << endl;
  else
    cout << "number of records in the table is " << numRecs << endl;

  // Get the number of fields in the table.

  numFields = DB.getFieldCount(tblName);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "error getting field count : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "number of fields in the table is " << numFields << endl;

  // Close the cursor, which also closes the table.

  tblCursor->close();

  return 0;

}


// Function to create a table.

void InitTable(void)
{
  // Array of field descriptors for the table, needed for the
  // createTable member function in the BDatabase class.

  FieldDesc fldArray[3];

  // Number of fields in the table.

  const int numFields = sizeof(fldArray) / sizeof(fldArray[0]);

  // Fill in the FieldDesc structure for every field in the Table.

  fldArray[0].fldNum = 1;
  strcpy(fldArray[0].fldName, "Name");
  fldArray[0].fldType = fldChar;  // Create an alphanumeric field.
  fldArray[0].fldLen = 50;        // Specify the length of the field.

  fldArray[1].fldNum = 2;
  strcpy(fldArray[1].fldName, "Address");
  fldArray[1].fldType = fldChar;
  fldArray[1].fldLen = 50;

  fldArray[2].fldNum = 3;
  strcpy(fldArray[2].fldName, "Age");
  fldArray[2].fldType = fldShort;  // Create a short field.

  // Create the table 'tblName' with the structure provided in the
  // array of field descriptors fldArray.

  DB.createTable(tblName, numFields, fldArray);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "table create error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "table '" << tblName << "' created successfully" << endl;

}
