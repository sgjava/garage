/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include <string.h>
#include "pxengine.h"

#define TABLENAME  "table"

struct TRecBuffer
{
  char    LastName[30];
  char    FirstName[30];
  char    number[8];      /* A numeric field takes 8 bytes of space. */
  char    field4[50];
  char    field5[30];
  char    field6[3];
};

TABLEHANDLE       tblHandle;
RECORDHANDLE      recHandle;
PXCODE            pxErr;
struct TRecBuffer rawData;

int main(void)
{
  pxErr = PXInit();

  pxErr = PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  pxErr = PXRecBufOpen(tblHandle, &recHandle);

  /* Get a record. */

  pxErr = PXRecGet(tblHandle, recHandle);

  /* Read data from record into a buffer. */

  pxErr = PXRawGet(recHandle, &rawData, sizeof(rawData));

  /* Modify data in the buffer. */

  strcpy(rawData.field6, "aaa");

  /* Note that the field must be padded with blanks if the data does  */
  /* not fill it, so that any comparisons performed on the field will */
  /* return the correct result. */

  /* Put data from our buffer into record buffer. */

  pxErr = PXRawPut(recHandle, (char *) &rawData, sizeof(rawData));
  if (pxErr)
    printf("%s\n", PXErrMsg(pxErr));

  /* Update record in the table. */

  PXRecUpdate(tblHandle, recHandle);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return 0;
}
