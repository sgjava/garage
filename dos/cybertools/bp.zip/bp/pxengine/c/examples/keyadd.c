/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pxengine.h"

#define TABLENAME  "table"

char commandline[128];   /* string buffer used to build command line */

FIELDHANDLE hFldsPrimary[]      = { 1, 2 };
FIELDHANDLE hFldsSecondary[]    = { 3 };
FIELDHANDLE hFldsIncSecondary[] = { 6 };

#define NPRIMARYFLDS (sizeof(hFldsPrimary) / sizeof(FIELDHANDLE))

int main(void)
{
  PXCODE pxErr;

  /* Attempt to initialize the Engine for local use. */

  pxErr = PXInit();
  if (pxErr != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }

  /* Create a primary index on fields 1 and 2. */

  if ((pxErr = PXKeyAdd(TABLENAME, NPRIMARYFLDS, hFldsPrimary, PRIMARY))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Create a secondary index on field 3. */

  if ((pxErr = PXKeyAdd(TABLENAME, 1, hFldsSecondary, SECONDARY)) 
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Create a maintained secondary index on field 6. */

  if ((pxErr = PXKeyAdd(TABLENAME, 1, hFldsIncSecondary, INCSECONDARY))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Build the string needed to list our index files. */

  strcpy(commandline,"dir ");
  strcat(commandline,TABLENAME);
  strcat(commandline,".*");

  /* Spawn a DOS command interpreter to process the DIR command. */

  system(commandline);

  PXExit();
  return(pxErr);
}
