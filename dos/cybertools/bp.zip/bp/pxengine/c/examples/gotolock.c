/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table"
#define NETDIR      ""
#define NETTYPE     NETSHARE

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  LOCKHANDLE   lckHandle;
  PXCODE       pxErr;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXNetRecLock(tblHandle, &lckHandle);

  /* Go to record previously locked. */

  if ((pxErr = PXNetRecGotoLock(tblHandle, lckHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXNetRecUnlock(tblHandle, lckHandle);
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
