/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "numbers"

int main(void)
{
  TABLEHANDLE   tblHandle;
  RECORDHANDLE  recHandle;
  FIELDHANDLE   fldHandle = 2;
  TDATE         date;
  int           month = 12, day = 5, year = 1989;
  PXCODE        pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXDateEncode(month, day, year, &date);

  /* Update record with new date. */

  if ((pxErr = PXPutDate(recHandle, fldHandle, date))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXRecAppend(tblHandle, recHandle);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
