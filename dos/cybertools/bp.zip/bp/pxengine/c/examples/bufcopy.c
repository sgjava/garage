/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE srcRecHandle, destRecHandle;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &srcRecHandle);
  PXRecBufOpen(tblHandle, &destRecHandle);
  PXRecGet(tblHandle, srcRecHandle);

  /* Copy source record handle to destination record handle. */

  if ((pxErr = PXRecBufCopy(srcRecHandle, destRecHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXRecBufClose(srcRecHandle);
  PXRecBufClose(destRecHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
