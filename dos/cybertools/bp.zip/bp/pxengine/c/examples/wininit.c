#include <windows.h>
#include "pxengine.h"

#ifdef __TURBOC__
  #pragma argsused
#endif

int PASCAL WinMain (HANDLE hInst, HANDLE hPrevInst, 
  LPSTR lpCmdLine, int nCmdShow)
{
  PXCODE pxErr;

  /* Attempt to initialize Engine for shared environment. */

  if ((pxErr = PXWinInit("Example", PXSINGLECLIENT)) != PXSUCCESS)
    MessageBox(GetFocus(), PXErrMsg(pxErr), "Engine Error", MB_ICONSTOP);
  else
    PXExit();
  return (pxErr);
}
