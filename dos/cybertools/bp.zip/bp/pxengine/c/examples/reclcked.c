/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME    "table"
#define NETDIR       ""
#define NETTYPE      NETSHARE

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;
  int         Locked;

  PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Determine if record is locked. */

  if ((pxErr = PXNetRecLocked(tblHandle, &Locked)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Record is %s\n", Locked ? "locked" : "unlocked");

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
