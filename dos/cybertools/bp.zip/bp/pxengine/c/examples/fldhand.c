/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"
#define FIELDNAME  "Field 1"

int main(void)
{
  FIELDHANDLE fldHandle;
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Get the field handle associated with the field name. */

  if ((pxErr = PXFldHandle(tblHandle, FIELDNAME, &fldHandle)) 
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Field name %s has field handle %d\n", FIELDNAME, fldHandle);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
