#include <stdio.h>
#include "pxengine.h"

/* The network control directory is the network directory where the     */
/* PARADOX.NET file is located. Be sure that your network account       */
/* has the appropriate access (read/write,etc) to the directory         */
/* that contains the .NET file. Also make sure that the drivers         */
/* for your particular network are loaded and your station is logged    */
/* logged into the network.                                             */

/* Change the #define below to reflect the location of PARADOX.NET.     */
/* Be sure to use double backslash characters (\\) to separate path     */
/* elements, for example, "P:\\DATA\\PDOXDATA\\".                       */

#define NETDIR    ""

/* Change the #define below so that it is appropriate for your network. */

#define NETTYPE   NETSHARE

int main(void)
{
  PXCODE pxErr;

  /* Attempt to initialize Engine. */

  printf("Attempting to initialize the Engine.\n");
  if ((pxErr = PXNetInit(NETDIR,NETTYPE,DEFUSERNAME)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
  {
    printf("Shutting down the Engine.\n");
    PXExit();
  }
  return(pxErr);
}
