/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define PASSWORD    "password"
#define TABLENAME   "table"

int main(void)
{
  PXCODE pxErr;
  int    Protected;

  PXInit();
  PXTblProtected(TABLENAME, &Protected);

  if (Protected) 
  {
    /* Submit password to system if a table is protected. */

    if ((pxErr = PXPswAdd(PASSWORD)) != PXSUCCESS)
      printf("%s\n", PXErrMsg(pxErr));
  }

  PXExit();
  return(pxErr);
}
