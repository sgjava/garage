/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "numbers"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Empty the table. */

  if ((pxErr = PXTblEmpty(TABLENAME)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
