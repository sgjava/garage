#include <stdio.h>
#include "pxengine.h"

int main(void)
{
  PXCODE  pxErr;
  TDATE   date;
  int     month = 9, day = 13, year = 1989;

  PXInit();

  /* Encode a date. */

  if ((pxErr = PXDateEncode(month, day, year, &date)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
