#include <stdio.h>
#include "pxengine.h"

int main(void)
{
  PXCODE pxErr;

  /* Attempt to initialize the Engine. */

  if ((pxErr = PXInit()) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXExit();

  return(pxErr);
}
