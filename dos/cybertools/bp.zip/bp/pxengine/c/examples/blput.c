/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include "pxengine.h"
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#ifndef __TURBOC__
  #include <malloc.h>
  #include <sys\types.h>
  #include <errno.h>
#else
  #include <alloc.h>
#endif
#include <sys\stat.h>


#define TABLENAME  "table"

TABLEHANDLE    tblHandle;
RECORDHANDLE   recHandle;
BLOBHANDLE     blbHandle;

int            input_file;
long           file_length;
unsigned       buffer_length;
char           *buffer;
PXCODE         pxErr;

int main(void)
{
  /* Read data to insert into BLOB. */

  input_file = open("recnext.c", O_RDONLY | O_TEXT);

  /* Create a buffer of size equal to the file length */

  buffer_length = (unsigned) filelength(input_file);

  buffer = (char *) malloc(buffer_length);
  if (buffer)
    file_length = read(input_file, buffer, buffer_length);
  close(input_file);

  PXInit();

  /* Open a table that contains a BLOB field at field 4. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  if((pxErr = PXBlobOpenWrite(recHandle, 4, &blbHandle, file_length, PXBLOBNEW))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
  {
    PXBlobPut(blbHandle, (unsigned) file_length, 0, buffer);
    PXBlobClose(blbHandle, PXBLOBACCEPT);
  }

  PXRecUpdate(tblHandle, recHandle);
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return (pxErr);
}
