/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

/* The example program TBLDECRY.C should be compiled and run after  */
/* this program to decrypt the table for other examples.            */

#include <stdio.h>
#include "pxengine.h"

#define PASSWORD   "password"
#define TABLENAME  "table"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Encrypt table with password. */

  if ((pxErr = PXTblEncrypt(TABLENAME, PASSWORD)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  PXExit();
  return(pxErr);
}
