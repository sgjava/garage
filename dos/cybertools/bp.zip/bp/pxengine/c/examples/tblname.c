#include <stdio.h>
#include "pxengine.h"

#define TABLENAME   "table1"

int main(void)
{
  TABLEHANDLE tblHandle;
  PXCODE      pxErr;
  char        tblName[BUFSIZ];

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Get the name of the table. */

  if ((pxErr = PXTblName(tblHandle, BUFSIZ, tblName)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("The name associated with table handle %d is %s\n",
      tblHandle, tblName);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
