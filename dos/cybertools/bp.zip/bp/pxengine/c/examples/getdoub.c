/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle = 3;
  double       doub;
  PXCODE       pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  /* Get a double value from a record. */

  if ((pxErr = PXGetDoub(recHandle, fldHandle, &doub))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Field number %d contents: %lf\n", fldHandle, doub);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
