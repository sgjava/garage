/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define NETTYPE   NETSHARE
#define NETDIR    ""

/* if you are placing a lock on a filename for use as a semaphore      */
/* on a network, a shared file must be used. Remember to use a         */
/* double backslash to separate path elements. For example, use        */
/* "T:\\DATA.DB" if the file DATA.DB is on the T drive. Remember       */
/* that, for a table, you need the .DB file extension.                 */

#define FILENAME       "table.db"

int main(void)
{
  PXCODE pxErr;

  /* Attempt to initialize the Engine. */

  if ((pxErr = PXNetInit(NETDIR,NETTYPE,DEFUSERNAME)) != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
    return pxErr;
  }
  /* Attempt to place a write-lock on a file. */

  if ((pxErr = PXNetFileLock(FILENAME, WL)) != PXSUCCESS)
  {
    printf("%s\n", PXErrMsg(pxErr));
  }
  /* If placing the lock was successful, now remove it. */

  else
  {
    PXNetFileUnlock(FILENAME, WL);
    printf("Write lock placed and removed for file %s\n", FILENAME);
  }
  PXExit();
  return(pxErr);
}
