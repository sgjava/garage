/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE tblHandle;
  int         nFlds;
  PXCODE      pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);

  /* Determine the number of fields in table. */

  if ((pxErr = PXRecNFlds(tblHandle, &nFlds)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    printf("Number of fields in table %s: %d\n",TABLENAME, nFlds);

  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
