/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define OLDNAME    "numbers"
#define NEWNAME    "newtbl"

int main(void)
{
  PXCODE pxErr;

  PXInit();

  /* Rename a table. */

  if ((pxErr = PXTblRename(OLDNAME, NEWNAME)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));

  /* Rename the table to the original name. */

  PXTblRename(NEWNAME, OLDNAME);

  PXExit();
  return(pxErr);
}
