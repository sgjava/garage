/* The SETUP.C and PUTDATE.C programs must be compiled and run */
/* before this example can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "numbers"

int main(void)
{
  RECORDHANDLE  recHandle;
  FIELDHANDLE   fldHandle = 2;
  TABLEHANDLE   tblHandle;
  TDATE         date;
  int           month, day, year;
  PXCODE        pxErr;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXRecGet(tblHandle, recHandle);

  /* Get a date field out of a record buffer. */

  if ((pxErr = PXGetDate(recHandle, fldHandle, &date))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else 
  {
    PXDateDecode(date, &month, &day, &year);
    printf("Date: %d/%d/%d\n", month, day, year);
  }

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
