//  Borland Paradox Engine 3.0 Database Framework program example
//  Copyright (c) 1992 by Borland International   
//  
//  ADDINDEX - provides an example showing how to add primary and 
//             secondary indexes to a table using the Database 
//             Framework.
//
//  This example uses the createPIndex and createSIndex member functions
//  of the BDatabase class to add a primary and secondary index to a
//  table.
//

#include <iostream.h>
#include <string.h>

// Paradox Engine 3.0 Header files.

#include <pxengine.h>
#include <envdef.h>   // Environment definitions for Database Framework.
#include <bengine.h>  // Header file for the BEngine class.
#include <bdatabas.h> // Header file for the BDatabase class.

// Specify the table you want to create.

const char *tblName = "table1";

// Call the BEngine constructor and initialize the engine to
// single user or "PXInit()" mode.

BEngine Eng(pxLocal);

// Create and open the BDatabase instance DB with respect to
// to the BEngine instance Eng.

BDatabase DB(&Eng);

// Array of field descriptors for the table, needed for the
// createTable member function in the BDatabase class.

FieldDesc fldArray[3];

// Number of fields in the table.

const int numFields = sizeof(fldArray) / sizeof(fldArray[0]);

int main()
{
  // Fill in the FieldDesc structure for every field in the table.

  fldArray[0].fldNum = 1;
  strcpy(fldArray[0].fldName, "Name");
  fldArray[0].fldType = fldChar;   // Create an alphanumeric field.
  fldArray[0].fldLen = 50;         // Specify the length of the field.

  fldArray[1].fldNum = 2;
  strcpy(fldArray[1].fldName, "Address");
  fldArray[1].fldType = fldChar;
  fldArray[1].fldLen = 50;

  fldArray[2].fldNum = 3;
  strcpy(fldArray[2].fldName, "Age");
  fldArray[2].fldType = fldShort;  // Create a short field.

  // Create the table 'tblName' with the structure provided in the
  // array of field descriptors fldArray.

  DB.createTable(tblName, numFields, fldArray);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "table create error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "table '" << tblName << "' created successfully" << endl;

  // Add a primary index composed of the first two fields to the 
  // table, that is, the Name and Address fields.

  DB.createPIndex(tblName, 2);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "add primary error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "primary index added successfully" << endl;

  // Add a secondary index on the third (Age) field.

  DB.createSIndex(tblName, 3, pxSecondary);

  // Check to see if there was an error.

  if (DB.lastError != PXSUCCESS)
    cout << "add secondary error : " <<
      Eng.getErrorMessage(DB.lastError) << endl;
  else
    cout << "secondary index added successfully" << endl;

  return DB.lastError;

}
