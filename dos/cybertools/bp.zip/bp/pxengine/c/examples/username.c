#include <stdio.h>
#include "pxengine.h"

#define NETDIR          "P:\\pdoxdata\\"
#define NETTYPE         NETSHARE

int main(void)
{
    PXCODE pxErr;
    char   userName[BUFSIZ];

    PXNetInit(NETDIR,NETTYPE,DEFUSERNAME);

    /* Get network user name */
    if ((pxErr = PXNetUserName(BUFSIZ,userName)) != PXSUCCESS)
        printf("%s\n", PXErrMsg(pxErr));
    else
        printf("The default user name is %s\n", userName);

    PXExit();
    return(pxErr);
}
