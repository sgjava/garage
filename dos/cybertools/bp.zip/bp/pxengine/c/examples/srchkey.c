/* The SETUP.C and KEYADD.C programs must be compiled and run  */
/* before this example can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

char search[] = "SearchString";

char buffer[32];      /* Buffer for reading data from table. */

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle1 = 1;
  PXCODE       pxErr;
  int          nFlds = 1;

  PXInit();
  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);
  PXPutAlpha(recHandle, fldHandle1, search);

  /* Search for an exact match on a key. */

  if ((pxErr = PXSrchKey(tblHandle, recHandle, nFlds,
    SEARCHFIRST)) != PXSUCCESS)
  {
    if (pxErr == PXERR_RECNOTFOUND)
      printf("No match found.\n");
    else
      printf("%s\n",PXErrMsg(pxErr));
  }
  else
  {
    PXGetAlpha(recHandle, 1, sizeof(buffer), buffer);
    printf("\nMatch found -> %s \n", buffer);
  }
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
