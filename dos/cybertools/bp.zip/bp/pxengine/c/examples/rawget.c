/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

struct TRecBuffer
{
  char    LastName[30];
  char    FirstName[30];
  char    number[8];        /* A numeric field takes 8 bytes of space. */
  char    field4[50];
  char    field5[30];
  char    field6[3];
};

TABLEHANDLE          tblHandle;
RECORDHANDLE         recHandle;
struct TRecBuffer    rawData;
PXCODE               pxErr;

int main(void)
{
  PXInit();

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Get record. */

  PXRecGet(tblHandle, recHandle);

  /* Read data from record into a buffer. */

  if((pxErr = PXRawGet(recHandle, &rawData, sizeof(rawData)))
    != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return(pxErr);
}
