/* The SETUP.C program must be compiled and run before this example */
/* can be executed. */

#include <stdio.h>
#include "pxengine.h"

#define TABLENAME  "table"

int main(void)
{
  TABLEHANDLE  tblHandle;
  RECORDHANDLE recHandle;
  FIELDHANDLE  fldHandle;
  BLOBHANDLE   blbHandle;
  PXCODE       pxErr;

  PXInit();

  /* Open a table that contains a BLOB field. */

  PXTblOpen(TABLENAME, &tblHandle, 0, 0);
  PXRecBufOpen(tblHandle, &recHandle);

  /* Open the BLOB field for reading only. */

  fldHandle = 4;    /* Field 4 is a BLOB field. */

  if((pxErr = PXBlobOpenRead(recHandle, fldHandle, &blbHandle)) != PXSUCCESS)
    printf("%s\n", PXErrMsg(pxErr));
  else
    PXBlobClose(blbHandle, PXBLOBACCEPT);

  PXRecBufClose(recHandle);
  PXTblClose(tblHandle);
  PXExit();
  return (pxErr);
}
