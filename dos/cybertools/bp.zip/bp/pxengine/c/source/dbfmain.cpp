
//
// DLLMAIN.CPP
//
// This file contains LibMain and WEP for creating 
// the Database Framework DLL.
//

#include <windows.h>

#ifndef _MSC_VER
   // take care of not-used argument warnings
   #pragma argsused
#endif

int FAR PASCAL LibMain(HINSTANCE hInstance, WORD /*wDataSeg*/,
  WORD /* cbHeapSize */, LPSTR lpCmdLine)
{
    return 1;
}

#ifndef _MSC_VER
   // take care of not-used argument warnings
   #pragma argsused
#endif

int FAR PASCAL WEP ( int /*bSystemExit*/ )
{
    return 1;
}

