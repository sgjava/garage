/*********************************************************************
**
**                    BENGINE.CPP
**
** Implement functions of the BEngine class.
**
*********************************************************************/


#include "pxengine.h"
#include "envdef.h"
#include "intstrct.h"
#include "bengine.h"
#include "bdatabas.h"
#include <string.h>

// Constructor. Makes a C++ BEngine object without opening the
// the Paradox Engine.

BEngine::BEngine()
{
  isOpen = FALSE;
  engineType = pxLocal;
  lastError = PXSUCCESS;
  engdef *eo = new engdef;           // See the INTSTRCT.H file. 
  if (! eo)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  } 
  eo->engenv.engineType = pxLocal; 
  eo->engenv.tabCrtMode = px40Fmt;
  eo->engenv.dosShare = pxLocalShare;
  eo->engenv.tabLckMode = px40Lck;
  eo->handleCnt = 0;
  eo->compIdxCnt = 0;
  engobj = (void *) eo;
}
 
//  This constructor makes a BEngine object and actually opens the
//  Paradox engine in the requested mode.

BEngine::BEngine(BEngineType eType)
{
  isOpen = FALSE;
  engdef *eo = new engdef;          // See the INTSTRCT.H file. 
  if (! eo)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  } 
  eo->engenv.engineType = eType; 
  eo->engenv.tabCrtMode = px40Fmt;
  eo->engenv.dosShare = pxLocalShare;    
  eo->engenv.tabLckMode = px40Lck;   
  eo->engenv.winShare = pxShared;
  eo->engenv.netNamePath[0] = eo->engenv.userName[0] 
    = eo->engenv.clientName[0] = 0; 
  eo->handleCnt = 0;
  eo->compIdxCnt = 0;
  engobj = (void *) eo;
  switch (eType)
  {
    case pxWin:

#ifdef WINDOWS
      engineType = pxWin;
      if ((lastError = PXWinInit("", PXSHARED)) != PXSUCCESS)
        return;
      break; 
#else 
      lastError = PXERR_INVENGINETYPE; 
      return;
#endif 
    case pxNet:
#ifdef WINDOWS
      lastError = PXERR_INVENGINETYPE; 
      return;
#else 
      engineType = pxNet;
      eo->engenv.dosShare = pxLocalShare;
      if ((lastError = PXNetInit("C:\\",LOCALSHARE,DEFUSERNAME)) 
        != PXSUCCESS)
        return;  
      break; 
#endif 
    case pxLocal:
#ifdef WINDOWS
      lastError = PXERR_INVENGINETYPE; 
      return;
#else 
      engineType = pxLocal;
      if ((lastError = PXInit()) != PXSUCCESS)
        return;
      break;
#endif
    default:
      lastError = PXERR_INVENGINETYPE;
      return;
  }
  isOpen = TRUE;
}


// Make an engine object and open it based on the specified 
// environment.  

BEngine::BEngine(const BEnv& env) 
{   
  lastError = PXSUCCESS;
  isOpen = FALSE;
  engdef *eo = new engdef;           // See the INTSTRCT.H file.
  if (! eo)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  } 
  eo->handleCnt = 0; 
  eo->compIdxCnt = 0;
  engobj = (void *) eo;
  engineType = env.engineType; 
  setDefaults(env); 
  open();
}

// Destructor; Closes the engine if it's open.

BEngine::~BEngine()
{
  close();
  engdef *eo  = (engdef *) engobj;
  if (eo)
  {
    // Reset pointers in any dependent database objects.

    for (int i=0; i < eo->handleCnt; i++)
      if (eo->dbList[i])
        ((dbdef *)eo->dbList[i]->dbobj)->engH = 0;
    if (eo->handleCnt)
      delete [] eo->dbList;
    delete eo; 
  }  
}

// Set default values for the Engine's resource parameters.

Retcode BEngine::setDefaults(const BEnv &env)
{
#ifdef WINDOWS 
  char so;                    // Windows sort orders.
#else 
  char far *so;               // DOS sort orders.
#endif 
  int bufSize, maxTables, maxRecBufs, maxLocks, maxFiles;

  BEnv &senv = ((engdef *) engobj)->engenv;
  senv = env;

  lastError= PXGetDefaults(&bufSize, &maxTables, &maxRecBufs,
    &maxLocks, &maxFiles,
#ifdef WINDOWS
   &so);  
#else 
   (char far * far *) &so);
#endif 
  if (! senv.sortOrder)               // For no specified order.   
  {
    if (so == SortOrderIntl)          // Use current defaults.
      senv.sortOrder = pxIntl;
    else if (so == SortOrderNorDan)
      senv.sortOrder = pxNorDan;
    else if (so == SortOrderNorDan4)
      senv.sortOrder = pxNorDan4;
    else if (so == SortOrderSwedFin)
      senv.sortOrder = pxSwedFin;
    else 
      senv.sortOrder = pxAscii;
  }
  else                                // For specified sort order.
  {
    if (senv.sortOrder == pxIntl)     // Use specified sort order.
      so = SortOrderIntl;
    else if (senv.sortOrder == pxNorDan)
      so = SortOrderNorDan;
    else if (senv.sortOrder == pxNorDan4)
      so = SortOrderNorDan4;
    else if (senv.sortOrder == pxSwedFin)
      so = SortOrderSwedFin; 
    else 
      so = SortOrderAscii; 
  }

  // Supply defaults for all values not supplied. 

  engineType = senv.engineType;
  if (! senv.bufSize)
    senv.bufSize = bufSize;
  if (! senv.maxTables)
    senv.maxTables = maxTables;
  if (! senv.maxRecBufs)
    senv.maxRecBufs = maxRecBufs;
  if (! senv.maxLocks)
    senv.maxLocks = maxLocks; 
  if (! senv.maxFiles)
    senv.maxFiles = maxFiles; 
  if (senv.tabCrtMode != px35Fmt) 
    senv.tabCrtMode = px40Fmt;  
  if (senv.tabLckMode != px35Lck) 
    senv.tabLckMode = px40Lck;  
  if (senv.dosShare != pxNetShare && senv.dosShare != pxNoShare) 
    senv.dosShare = pxLocalShare;   
  if (! (int) senv.netNamePath[0])
    strcpy(senv.netNamePath,"C:\\"); 
  if (senv.winShare != pxSingleClient && senv.winShare != pxExclusive) 
    senv.winShare = pxShared;   
 
  // now set new values as defaults 
  lastError = PXSetDefaults(senv.bufSize,  senv.maxTables, senv.maxRecBufs,
    senv.maxLocks, senv.maxFiles, so);
  return(lastError); 
}
 
// Open the engine based on a previously set environment. 
// The engine is opened in Local, Network or Windows mode
// based on the value of engineType.

Retcode BEngine::open()
{
#ifdef WINDOWS
  int wsmode;  
#else 
  int netType; 
#endif
  BEnv &senv = ((engdef *) engobj)->engenv;  

  if (isOpen)
    return(lastError = PXERR_ENGINEOPEN); 

  switch (senv.engineType)
  {
    case pxWin:    
#ifdef WINDOWS
      if (senv.winShare == pxSingleClient) 
        wsmode = PXSINGLECLIENT;
      else if (senv.winShare == pxExclusive) 
        wsmode = PXEXCLUSIVE;
      else 
        wsmode = PXSHARED;
      if ((lastError = PXWinInit(senv.clientName, wsmode)) != PXSUCCESS)
        return(lastError);
      break; 
#else 
      return(lastError = PXERR_INVENGINETYPE); 
#endif 
    case pxNet:
#ifdef WINDOWS
      return(lastError = PXERR_INVENGINETYPE); 
#else 
      if (senv.dosShare == pxNetShare)
        netType = NETSHARE; 
      else if (senv.dosShare == pxNoShare)
        netType = NOSHARE; 
      else 
        netType = LOCALSHARE; 
      if (senv.tabLckMode == px35Lck)
        netType |= PX35LOCKING;  
      if ((lastError = PXNetInit(senv.netNamePath,
        netType, senv.userName)) != PXSUCCESS)
        return(lastError);
      break;
#endif
    case pxLocal:
#ifdef WINDOWS
      return(lastError = PXERR_INVENGINETYPE);
#else
      if ((lastError = PXInit()) != PXSUCCESS)
        return(lastError);
      break;
#endif
    default:
      return(lastError = PXERR_INVENGINETYPE);
  }

  isOpen = TRUE;
  if (senv.tabCrtMode == px35Fmt)         // Default is Paradox 4.0 format.
    PXTblCreateMode(PARADOX35);  
  return(lastError = PXSUCCESS);
}

// Shut down the currently open engine and close all databases.

Retcode BEngine::close()
{
  // Close all open databases.

  engdef *eo = (engdef *) engobj;
  for (int i=0; i < eo->handleCnt; i++)
    if (eo->dbList[i]  && eo->dbList[i]->isOpen)
      if ((lastError = eo->dbList[i]->close())   // Close database.
        != PXSUCCESS)  
        return(lastError);
  for (i = 0; i < eo->compIdxCnt; i++)           // Delete compound key 
  { 						 // map information. 
    delete eo->keymap[i].tableName;
    delete [] eo->keymap[i].fieldArray;
  }
  if (eo->compIdxCnt)
    delete [] eo->keymap; 
  eo->compIdxCnt = 0;
  if (isOpen)
  {
    if ((lastError = PXExit()) != PXSUCCESS)
      return(lastError);
  }
  else 
    lastError = PXERR_ENGINENOTOPEN; 
  isOpen = FALSE;
  return(lastError);
}

// Get the current values for various engine parameters.

void BEngine::getDefaults(BEnv &env) const
{
  env = ((engdef *) engobj)->engenv;
}

// Enable or Disable the internal hardware error handler.

Retcode BEngine::setHWHandler(BOOL ehEnable)
{
  return(lastError = PXSetHWHandler((int) ehEnable));
}

// Add a password to the Paradox Engine using PXPswAdd.

Retcode BEngine::addPassword(char *password)
{
  if (! isOpen)
    return(lastError = PXERR_ENGINENOTOPEN); 
  return(lastError = PXPswAdd(password));
}

// Set the maximum size of tables you can create. 

Retcode BEngine::setMaxTblSize(int maxSize)
{
  if (! isOpen)
    return(lastError = PXERR_ENGINENOTOPEN); 
  return(lastError = PXTblMaxSize(maxSize));
}  

// Choose between Paradox 3.5 and Paradox 4.0 file formats.

Retcode BEngine::setTblCreateMode(PXTabCrtMode crtMode)
{
  if (! isOpen)
    return(lastError = PXERR_ENGINENOTOPEN); 
  if (crtMode == px40Fmt)
    return(lastError = PXTblCreateMode(PARADOX40));
  else
    return(lastError = PXTblCreateMode(PARADOX35));
}  

// Delete a previously entered password.

Retcode BEngine::deletePassword(char *password)
{
  if (! isOpen)
    return(lastError = PXERR_ENGINENOTOPEN); 
  return(lastError = PXPswDel(password));
}

// Get the error message corresponding to an error.  

char far *BEngine::getErrorMessage(int errnbr)
{
  return(PXOopErrMsg(errnbr));
}


// Return the name of the user in a shared environment.

char *BEngine::getUsername()
{
  engdef *eo = (engdef *) engobj;
  if ((lastError=PXNetUserName(MAXNAMELEN,eo->engenv.userName)) == PXSUCCESS)
    return(eo->engenv.userName);
  else   
    return(0);
}

// Redefine pure virtuals from the BDbObject class. 

char * BEngine::nameOf() const 
{
  return("BEngine"); 
}
 
void BEngine::printOn( ostream& os)
{ 
  os << nameOf() << "{ Engine Type = " << (int) engineType 
     << ", Open Status = " << (int) isOpen << "}\n";
}

