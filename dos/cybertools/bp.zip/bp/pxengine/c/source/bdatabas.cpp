/**********************************************************************
**
**                         BDATABAS.CPP
**
** Member functions of the BDatabase class.  
**
**********************************************************************/

#include "envdef.h"
#include "bdatabas.h"
#include "bengine.h"
#include "bcursor.h"
#include "pxengine.h"
#include "intstrct.h"
#include <stdlib.h>
#include <string.h>

#ifdef __DLL__
   #define EXPORT _export
#else
   #define EXPORT
#endif

//
// prototypes for utility functions
//

Retcode EXPORT addDatabase(engdef *, BDatabase *);   
void EXPORT deleteDatabase(engdef *, BDatabase *);   
Retcode EXPORT addKeymap(engdef *, const char *, int, int, const int *); 
Retcode EXPORT getDesc(TABLEHANDLE,int&,FieldDesc far *); 

// Constructor for universal database.

BDatabase::BDatabase(BEngine *eng)
{
  dbdef *dob = new dbdef;            // See INTSTRCT.H file. 
  if (! dob)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  } 
  dob->handleCnt = 0;
  dob->curList = 0;
  dob->engH = eng;
  dbobj = (void *)dob;

  if (! eng->isOpen)
  {
    isOpen = FALSE;
    lastError = PXERR_ENGINENOTOPEN;
    return;
  }
  isOpen = TRUE;
  lastError = addDatabase((engdef *)eng->engobj,this);                       
}

// Destructor; if the database is open, close it first.

BDatabase::~BDatabase()
{
  if (isOpen)
    close();
  dbdef *dob  = (dbdef *)dbobj;
  if (dob) 
  {
    // Reset pointers in any dependent cursor objects.

    for (int i=0; i < dob->handleCnt; i++)
      if (dob->curList[i])
        ((curdef *)dob->curList[i]->curobj)->dbH = 0;
    if (dob->handleCnt)
      delete [] dob->curList;
    if (dob->engH)                             // If engine is operating,
      deleteDatabase((engdef *)		       // remove from Engine's
        dob->engH->engobj,this);               // database list.
    delete dob; 
  } 
}

// Open the universal database

Retcode BDatabase::open()
{
  if (isOpen)
    return(lastError = PXERR_DBALREADYOPEN);

  dbdef *dob  = (dbdef *)dbobj;
  if (! dob->engH || ! dob->engH->isOpen)
    return(lastError = PXERR_ENGINENOTOPEN);

  isOpen = TRUE;
  return(lastError = PXSUCCESS);
}

//  Close the database; close all cursors associated with the database.

Retcode BDatabase::close()
{
  int i;
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  dbdef *dob = (dbdef *)dbobj;
  for (i=0; i < dob->handleCnt; i++)
    if (dob->curList[i] && dob->curList[i]->isOpen)
      if ((lastError = dob->curList[i]->close()) != 0)   // Close cursor.
        return(lastError);
  isOpen = FALSE;
  return(lastError = PXSUCCESS);
}

// See if a table exists in the database.

BOOL BDatabase::tableExists(const char *tableName)
{
  int exists = 0;
  if (isOpen)
    lastError = PXTblExist((char far *) tableName, &exists);
  else 
    lastError = PXERR_DBNOTOPEN;
  return(exists);
}

// Create a table based on its descriptor.

Retcode BDatabase::createTable(const char *tableName,
	  int numFields, const FieldDesc *desc)
{
  // Paradox data types are a single character plus 3-digit length
  // and the null terminator.

  const int pdxMaxTypeSize = 5;

  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  char *p;
  char far * far *fldNames  = new char far *[numFields];
  char far * far *fldTypes  = new char far *[numFields];
  char *typeStr    = new char[numFields * pdxMaxTypeSize];
  if (! fldNames || ! fldTypes || ! typeStr)
    return(lastError = PXERR_OUTOFMEM);

  lastError = PXSUCCESS;
  for (int i = 0; i < numFields; i++)
  {
    fldNames[i] = (char far *) desc[i].fldName;
    p = &typeStr[i * pdxMaxTypeSize];
    fldTypes[i] = (char far *) p;
    switch (desc[i].fldType)
    {
      case fldChar:
	*p++ = 'A';
        #ifdef _MSC_VER
        _itoa(desc[i].fldLen, p, 10);
        #else
        itoa(desc[i].fldLen, p, 10);
        #endif
        break;
      case fldShort:
	strcpy(p,"S");
	break;
      case fldDouble:
	if (desc[i].fldSubtype == fldstMoney)
        strcpy(p,"$");
        else
	  strcpy(p,"N");
	break;
      case fldDate:
	strcpy(p,"D");
	break;
      default:                                       // BLOB field.
	if (desc[i].fldSubtype == fldstMemo)
	  *p = 'M';
	else if (desc[i].fldSubtype == fldstFmtMemo)
	  *p = 'F';
	else if (desc[i].fldSubtype == fldstOleObj)
	  *p = 'O';
	else if (desc[i].fldSubtype == fldstGraphic)
	  *p = 'G';
	else if (desc[i].fldSubtype == fldstBinary)
	  *p = 'B';                                  // Binary BLOB.
	else
	  {
	    lastError = PXERR_INVFIELDTYPE;
	    break;
	  }
        #ifdef _MSC_VER
        _itoa(desc[i].fldLen, p+1, 10);  // header length
        #else
        itoa(desc[i].fldLen, p+1, 10);  // header length
        #endif
    } // end switch
  }
  if (! lastError)
    lastError = PXTblCreate((char far *) tableName, numFields,
      (char far * far *)fldNames, (char far * far *)fldTypes);
  delete [] fldNames;
  delete [] fldTypes;
  delete typeStr;
  return(lastError);
}

// Copy one table family to another.

Retcode BDatabase::copyTable(const char *srcTable, const char *destTable)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblCopy((char far *) srcTable, 
    (char far *) destTable));
}

// Append records of a table to the destination table.

Retcode BDatabase::appendTable(const char *srcTable, const char *destTable)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblAdd((char far *) srcTable, 
    (char far *) destTable));
}

// Renames a table and its family members.

Retcode BDatabase::renameTable(const char *oldName, const char *newName)
{ 
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblRename((char far *) oldName, 
    (char far *) newName));
}

// Delete a table and its family.

Retcode BDatabase::deleteTable(const char *tableName)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblDelete((char far *) tableName));
}

// Encrypt a table based on a supplied password.

Retcode BDatabase::encryptTable(const char *tableName,
          const char *password)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblEncrypt((char far *) tableName, 
    (char far *) password));
}

// Decrypt a table using a password.

Retcode BDatabase::decryptTable(const char *tableName)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblDecrypt((char far *) tableName));
}

// Empty a table. (Delete all its records).

Retcode BDatabase::emptyTable(const char *tableName)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXTblEmpty((char far *) tableName));
}

// Upgrade a table from Paradox 3.5 to Paradox 4.0 format. 

Retcode BDatabase::upgradeTable(const char *tableName) 
{
  TABLEHANDLE tblH;
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  if ((lastError = PXTblOpen((char far *)tableName, &tblH, 0, 0)) 
    != PXSUCCESS)
    return(lastError);
  lastError = PXTblUpgrade(tblH); 
  PXTblClose(tblH);
  return(lastError);
}

// Determine if a table is protected.

BOOL BDatabase::isProtected(const char *tableName)
{
  int prot = 0;
  if (! isOpen)
    lastError = PXERR_DBNOTOPEN;
  else 
    lastError = PXTblProtected((char far *) tableName, &prot);
  return((BOOL) prot);
}

// Return the number of fields (columns) in a table.

int BDatabase::getFieldCount(const char *tableName)
{
  TABLEHANDLE tblH;
  int nFields = 0;
  if (! isOpen)
  {
    lastError = PXERR_DBNOTOPEN;
    return(0); 
  }
  if ((lastError = PXTblOpen((char far *)tableName, &tblH, 0, 0)) 
    != PXSUCCESS)
    return(0);
  lastError = PXRecNFlds(tblH,&nFields);
  PXTblClose(tblH);
  if (lastError)
    return(0);
  else
    return(nFields);
}


// Given a table, return the number of fields in it and an array 
// of its field descriptors (FieldDesc structures). The caller is 
// responsible for deleting the free store memory allocated for 
// the field descriptors (using delete [] desc, where 
// desc is pointer to FieldDesc object).    

Retcode BDatabase::getDescVector(char *tableName, 
          int& numFields,
          FieldDesc *&desc)
{
  TABLEHANDLE tblH;
  numFields = 0;
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  if ((lastError = PXTblOpen((char far *)tableName, &tblH, 0, 0)) 
    != PXSUCCESS)
    return(lastError);
  PXRecNFlds(tblH,&numFields);
  desc = new FieldDesc [numFields];  // Allocate descriptor array.
  if (! desc)
    lastError = PXERR_OUTOFMEM; 
  else 
    lastError = getDesc(tblH, numFields, (FieldDesc far *) desc);
  PXTblClose(tblH);
  return(lastError);
}

// Given an ordered list of fields, establish a virtual field 
// as a composite of all the fields.

Retcode BDatabase::defineCompoundKey (const char *tableName,
          int numFields,
          const FIELDNUMBER *fldArray,
          const char *indexName,
          BOOL caseSen,
          FIELDNUMBER& indexHandle)
{
  dbdef *dob  = (dbdef *)dbobj;
  int mode = ! caseSen; 
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  if ((lastError = PXKeyMap((char far *) tableName, numFields,
    (FIELDNUMBER *) fldArray, (char *) indexName,
      mode, &indexHandle)) == PXSUCCESS)
    addKeymap((engdef *)dob->engH->engobj, tableName, numFields,
      indexHandle, (int *)fldArray);
  return(lastError);  
}

// Create a secondary index on the table.

Retcode BDatabase::createSIndex ( const char *tableName,
          FIELDNUMBER fieldH, PXKeyCrtMode keyMode)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXKeyAdd((char far *) tableName, 1, &fieldH, 
    (int)keyMode));
}

// Create a primary key by using the first numFields fields as the key.

Retcode BDatabase::createPIndex(const char *tableName, int numFields)
{
  FIELDNUMBER fh;
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXKeyAdd((char far *) tableName, numFields, 
    &fh, PRIMARY));
}

// Delete an index on the table; the value of indexID for the 
// primary key is zero.

Retcode BDatabase::dropIndex(const char *tableName, FIELDNUMBER indexID)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXKeyDrop((char far *) tableName, indexID));
}

// Get the number of primary key fields for the table.

int BDatabase::getNumPFields(const char *tableName)
{
  TABLEHANDLE tblH;
  int nFields = 0;
  if (! isOpen)
  {
    lastError = PXERR_DBNOTOPEN;
    return(0); 
  }
  if ((lastError = PXTblOpen((char far *) tableName, 
    &tblH, 0, 0)) != PXSUCCESS)
    return(0);
  lastError = PXKeyNFlds(tblH,&nFields);
  PXTblClose(tblH);
  if (lastError)
    return(0);
  else
    return(nFields);
}

// Return information on a composite secondary index.

Retcode BDatabase::getSKeyInfo (const char *indexName,
          char *fldName,
          int& numFields,
          BOOL& caseSen,
          FIELDNUMBER *fldArray,
          FIELDNUMBER& indexID)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  lastError = PXKeyQuery((char far *) indexName, fldName,
    &numFields, &caseSen, fldArray, &indexID);

  caseSen = ! caseSen;
  return(lastError);
}

// Given a single field secondary index file name, return 
// information about the field.

Retcode BDatabase::getSKeyInfo (const char *indexName,
          char *fldName,
          BOOL& caseSen,
          FIELDNUMBER& indexID)
{
  int numFields;
  FIELDNUMBER fldArray;
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  lastError = PXKeyQuery((char far *) indexName, fldName,
    &numFields, &caseSen, &fldArray, &indexID);
  caseSen = ! caseSen;
  return(lastError);
}

// Acquire a file lock on the network.

Retcode BDatabase::lockNetFile(const char *fileName, PXLockMode lockMode)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXNetFileLock((char far *) fileName, (int)lockMode));
}

// Release a previously acquired lock on a file.

Retcode BDatabase::unlockNetFile(const char *fileName, PXLockMode lockMode)
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXNetFileUnlock((char far *) fileName, (int)lockMode));
}

// Write the changed record buffers associated with this database to disk.

Retcode BDatabase::forceWrite()
{
  if (! isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  return(lastError = PXSave());
}

//  Return the name of the user causing a network locking error.

char *BDatabase::getNetErrUser() 
{
  dbdef *dob = (dbdef *)dbobj;
  if (! isOpen)
  {
    lastError = PXERR_DBNOTOPEN;
    return(""); 
  }
  lastError = PXNetErrUser(MAXNAMELEN, dob->errUser);
  return(dob->errUser); 
}

// Redefine pure virtuals from the BDbObject class. 

char * BDatabase::nameOf() const 
{
  return("BDatabase"); 
}

void BDatabase::printOn( ostream& os) 
{ 
  os << nameOf() << " { DB Name = Universal, Open Status = " 
     << (int) isOpen << " }\n";
}

// The following two routines are used to maintain a list of databases for 
// the Paradox Engine. The Database Framework does not assume the presense 
// of any Class library (not even Borland's container library Classlib). 
// Consequently, no List class is used. 

Retcode addDatabase(engdef *eng, BDatabase *db)
{
  // Add this database object to the Database vector in the Paradox Engine.

  int i;
  BDatabase **newvec;
  for (i = 0; i < eng->handleCnt; i++)
    if (! eng->dbList[i])                // Determine an empty slot.
    {
      eng->dbList[i] = db;
      return(PXSUCCESS);
    }
  if (! (newvec = new BDatabase *[eng->handleCnt+4]))   // Four more handles.
    return(PXERR_OUTOFMEM);
  for (i = 0; i < eng->handleCnt; i++)
    newvec[i] = eng->dbList[i];
  newvec[i++] = db;
  newvec[i] = newvec[i+1] = newvec[i+2] = 0;
  if (eng->handleCnt)
    delete [] eng->dbList;                             // Delete old vector.
  eng->handleCnt += 4;
  eng->dbList = newvec;
  return(PXSUCCESS);
}

void deleteDatabase(engdef *eng, BDatabase *db)
{
  // Invoke when a Database object's destructor is called.

  for (int i = 0; i < eng->handleCnt; i++)
    if (eng->dbList[i] == db)
    {
      eng->dbList[i] = 0;
      return;
    }
}

// Add key map defined by an application to the Paradox Engine 
// object; the key map results in a compound index's index 
// handle that is valid only within this instance of the Engine.
// Paradox Engine semantics require the key map definition for 
// every session. This information is required for some of the 
// search functions provided in BCursor class.  

Retcode addKeymap(engdef *eng, const char *tableName, int numFields,
          int indexHandle, const int *fldArray) 
{
  int i,j; 
  keyMapdef *newmap; 

  // See if an entry already exists.

  for (i = 0; i < eng->compIdxCnt; i++)
    if (eng->keymap[i].indexId == indexHandle &&
      eng->keymap[i].keyCnt  == numFields   &&
        ! strcmp(eng->keymap[i].tableName, tableName))
      break;
  if (i == eng->compIdxCnt)              // Add a new entry.
  {
    newmap = new keyMapdef[eng->compIdxCnt+1];
    if (! newmap)
      return(PXERR_OUTOFMEM); 
    for (j = 0; j < eng->compIdxCnt; j++)
      newmap[j] = eng->keymap[j];
    if (eng->compIdxCnt)             // Free old structure if 
      delete [] eng->keymap; 	     // this is not the first.
    eng->keymap = newmap;  
    eng->compIdxCnt += 1;
  } 
  else 
  {  
    // Delete allocated memory in old structure for the index.

    delete eng->keymap[i].tableName; 
    delete [] eng->keymap[i].fieldArray; 
  }

  // Add information at index position i. The memory allocated 
  // here will be freed when the engine is closed.  

  eng->keymap[i].indexId = indexHandle;
  eng->keymap[i].keyCnt  = numFields;
  eng->keymap[i].tableName  = new char[strlen(tableName)+1];
  strcpy(eng->keymap[i].tableName,tableName);
  eng->keymap[i].fieldArray = new int[numFields];
  for (j = 0; j < numFields; j++)
    eng->keymap[i].fieldArray[j] = fldArray[j];
  return(PXSUCCESS); 
}

Retcode getDesc(TABLEHANDLE tblH, int& numFields, FieldDesc far *desc)
{
  char typebuf[10];
  for (int i=0; i < numFields; i++)
  {
    desc[i].fldNum = i+1;
    PXFldName(tblH,i+1,sizeof(desc[i].fldName),desc[i].fldName);
    PXFldType(tblH,i+1,10,typebuf);
    switch (typebuf[0])
    {
      case 'D':
        desc[i].fldType = fldDate;
        desc[i].fldSubtype = fldstNone;
        desc[i].fldLen = 0;
        break;
      case 'S':
        desc[i].fldType = fldShort;
        desc[i].fldSubtype = fldstNone;
        desc[i].fldLen = 0;
        break;
      case 'N':
        desc[i].fldType = fldDouble;
        desc[i].fldSubtype = fldstNone; 
        desc[i].fldLen = 0;
        break;
      case '$':
        desc[i].fldType = fldDouble;
        desc[i].fldSubtype = fldstMoney; 
        desc[i].fldLen = 0;
        break;
      case 'A':
        desc[i].fldType = fldChar;
        desc[i].fldSubtype = fldstNone;
        desc[i].fldLen = atoi(typebuf+1); 
        break;
      case 'M':
        desc[i].fldType = fldBlob;
        desc[i].fldSubtype = fldstMemo; 
        desc[i].fldLen = atoi(typebuf+1); 
        break;
      case 'B':
        desc[i].fldType = fldBlob;
        desc[i].fldSubtype = fldstBinary;
        desc[i].fldLen = atoi(typebuf+1); 
        break;
      case 'F':
        desc[i].fldType = fldBlob;
        desc[i].fldSubtype = fldstFmtMemo;
        desc[i].fldLen = atoi(typebuf+1); 
        break;
      case 'O':
        desc[i].fldType = fldBlob;
        desc[i].fldSubtype = fldstOleObj;
        desc[i].fldLen = atoi(typebuf+1); 
        break;
      case 'G':
        desc[i].fldType = fldBlob;
        desc[i].fldSubtype = fldstGraphic;
        desc[i].fldLen = atoi(typebuf+1); 
        break;
    }
  }
  return(PXSUCCESS); 
} 
