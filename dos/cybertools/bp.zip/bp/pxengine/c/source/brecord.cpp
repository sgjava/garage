/*******************************************************************
**
**                          BRECORD.CPP
**
** This file contains the member functions of the BRecord class.
**
*********************************************************************/

#include "envdef.h"
#include "bcursor.h"
#include "brecord.h"
#include "pxengine.h"
#include "intstrct.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include <ctype.h>

#ifdef __DLL__
   #define EXPORT _export
#else
   #define EXPORT
#endif

//
// prototypes for utility functions
//

Retcode EXPORT addRecord(curdef *, BRecord *);
void    EXPORT deleteRecord(curdef *, BRecord *);
Retcode EXPORT addBlob(recdef *, blbdef *);
Retcode EXPORT convertFld(void *, PXFieldType, int,  // Source value
                   void *, PXFieldType, int);        // destination.
Retcode EXPORT strToDate(const char *str, BDate *dt);
Retcode EXPORT dateToStr(const BDate *dt, char *str);

// Constructor for making a generic record object for an open cursor.

BRecord::BRecord(BCursor *cursor)
{
  recdef *ro = new recdef;                // See the INTSTRCT.H file.
  if (! ro)
  {
    lastError = PXERR_OUTOFMEM;
    recH = 0;
    curH = 0;
    return;
  }
  lastError = PXSUCCESS;
  ro->handleCnt = 0;
  recH = 0;
  recobj = (void *)ro;
  curH = cursor;
  if (! cursor)                  // Null cursor ->  unattached record.
    return;
  if (! cursor->isOpen)
    lastError = PXERR_CURSORNOTOPEN;
  else if ((lastError = PXRecBufOpen(cursor->tabH,&recH)) == PXSUCCESS)
    addRecord((curdef *)cursor->curobj, this);
}

// Destructor for BRecord objects.

BRecord::~BRecord()
{
  detach();
  recdef *ro  = (recdef *)recobj;
  if (ro)
  {
    if (ro->handleCnt)
      delete [] ro->recblb;
    delete ro;
  }
}

// Delete the record's association with the cursor.

Retcode BRecord::detach()
{
  curdef *co = (curdef *)curH->curobj;
  recdef *ro = (recdef *) recobj;
  if (! recH)
    return(lastError = PXERR_RECNOTATT);

  // Mark BLOB status as closed. The resources allocated for all
  // BLOBs will be freed by the Paradox Engine with a RecBufClose call.

  for (int i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].blbRecH == recH)
      ro->recblb[i].state = blbClosed;
      deleteRecord(co, this);
    if ((lastError = PXRecBufClose(recH)) != PXSUCCESS)
      return(lastError);
  recH = 0;
  return(lastError);
}

// Attach the record object to an open cursor.

Retcode BRecord::attach(BCursor *cur)
{
  if (recH)
    return(lastError = PXERR_RECALREADYATT);
  if (! cur->isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  curH = cur;
  if ((lastError = PXRecBufOpen(cur->tabH,&recH)) != PXSUCCESS)
    return(lastError);
  addRecord((curdef *)cur->curobj, this);
  return(lastError = PXSUCCESS);
}

// Clear the record buffer and set fields to "empty" values.
// RecBufEmpty will fail if a BLOB is open. This function
// doesn't perform operations on BLOBs.

Retcode BRecord::clear()
{
  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  return(lastError = PXRecBufEmpty(recH));
}

// For the descriptor in use, return the field handle for a
// given name. For generic records, the table descriptor and
// record descriptor are the same.

FIELDNUMBER BRecord::getFieldNumber(const char *fldName)
{
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
  {
    lastError = PXERR_INVRECHANDLE;
    return(0);
  }
  lastError = PXSUCCESS;
  for (int i=0; i < co->fieldCnt; i++)
    if ( ! _fstrcmp(co->desc[i].fldName, (char far *) fldName))
    {
      lastError = PXSUCCESS;
      return(i+1);
    }
  lastError = PXERR_INVFIELDNAME;
  return(0);
}

// Get the table field number for the record. For generic
// records, there is no difference between record and
// table field numbers.

FIELDNUMBER BRecord::getTblFieldNumber(FIELDNUMBER fldnbr)
{
  lastError = PXSUCCESS;
  return(fldnbr);
}

// For the generic table (and record) descriptor in use,
// return its field count.

int BRecord::getFieldCount()
{
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
  {
    lastError = PXERR_INVRECHANDLE;
    return(0);
  }
  lastError = PXSUCCESS;
  return(co->fieldCnt);
}

// Given a field handle, return a field descriptor describing
// the field's name, type, length, and so on. For generic
// records, use the field descriptor in the cursor. (Table and
// record descriptors are the same).

Retcode BRecord::getFieldDesc(FIELDNUMBER fldnbr, FieldDesc& desc)
{
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
  {
    lastError = PXERR_INVRECHANDLE;
    return(lastError);
  }
  if (fldnbr > co->fieldCnt || fldnbr < 1)
  {
    lastError = PXERR_INVFIELDHANDLE;
    return(lastError);
  }
  desc = co->desc[fldnbr-1];
  return(lastError = PXSUCCESS);
}

// This function performs the same operation as the previous
// function except this signature returns the field type,
// subtype, and length.

Retcode BRecord::getFieldDesc(FIELDNUMBER fldnbr,
  PXFieldType &fldType, PXFieldSubtype &fldSubtype, int &fldLen)
{
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
  {
    lastError = PXERR_INVRECHANDLE;
    return(lastError);
  }
  if (fldnbr > co->fieldCnt || fldnbr < 1)
  {
    lastError = PXERR_INVFIELDHANDLE;
    return(lastError);
  }
  fldType    = co->desc[fldnbr-1].fldType;
  fldSubtype = co->desc[fldnbr-1].fldSubtype;
  fldLen     = co->desc[fldnbr-1].fldLen;
  return(lastError = PXSUCCESS);
}

// Copy the contents of a record, one field at a time, to
// compatible fields of another record.

Retcode BRecord::copyTo(BRecord *destRec)
{
  BOOL custom = strcmp(nameOf(),"BRecord") ||
    strcmp(destRec->nameOf(),"BRecord");

  if ((lastError = PXRecBufCopy(recH,
    destRec->recH)) != PXSUCCESS)
    if (! custom)                       // See the BRECORD.H file.
      return(lastError);

  // Register the fact that the BLOBs in the destRec are now closed.

  recdef *ro = (recdef *) destRec->recobj;
  for (int i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].blbRecH == destRec->recH)
      ro->recblb[i].state = blbClosed;

  // If either the source or the destination record is a custom record,
  // transfer values to or from custom record fields, one field at a time.

  if (custom)
  {
    char *buf = new char[256];
    if (! buf)
      return(lastError = PXERR_OUTOFMEM);
    Retcode ret;

    PXFieldType    fldType1, fldType2;
    PXFieldSubtype fldSubtype;
    int            fldLen1, fldLen2;
    BOOL           fNull;

    int cnt = destRec->getFieldCount();
    for (int i=1; i <= cnt; i++)
    {
      if (isNull(i))
      {
        destRec->setNull(i);
        continue;
      }
      destRec->clearNull(i);
      getFieldDesc(i,fldType1,fldSubtype,fldLen1);
      destRec->getFieldDesc(i,fldType2,fldSubtype,fldLen2);
      if (fldType2 == fldBlob)
        continue;                     // BLOB handling is separate.

      if ((ret = getField(i, (void *) buf, 255, fNull)) == PXSUCCESS)
      {
        if (fldType1 != fldType2)
          ret = convertFld((void *)buf,fldType1, fldLen1,
            (void *)buf,fldType2, fldLen2);
        if (! ret)
          ret = destRec->putField(i, (void *) buf);
      }
      if (ret)
      {
        delete buf;
        return(lastError = ret);
      }
    }
    delete buf;
  }
  return(lastError = PXSUCCESS);
}

//  Copy the contents of srcRec, one field at a time, to compatible
//  fields in this record.

Retcode BRecord::copyFrom(BRecord *srcRec)
{
  if (! recH || !srcRec->recH)
    lastError = PXERR_INVRECHANDLE;
  return(lastError = srcRec->copyTo(this));
}

// Obtain values for fields of a generic record; store the
// field as a character string regardless of its base type.

Retcode BRecord::getField(FIELDNUMBER fldnbr,char *buf,
  int bufLen, BOOL& fNull)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  if ((lastError = getField(fldnbr, (void *) buf,
    bufLen, fNull)) != PXSUCCESS)
    return(lastError);
  if (fNull)
    return(lastError = PXSUCCESS);
  getFieldDesc(fldnbr,fldType,fldSubtype,fldLen);
  return(lastError = convertFld((void *)buf,  fldType, fldLen,
    (void *) buf, fldChar, bufLen));
}

// Get the field's value in its native format and return a pointer to
// the value as a void pointer.

Retcode BRecord::getField(FIELDNUMBER fldnbr,void *buf,
  int bufLen,BOOL& fNull)
{
  BDate *dt = (BDate *) buf;
  int m,d,y;
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (fldnbr > co->fieldCnt || fldnbr < 1)
    return(lastError = PXERR_INVFIELDHANDLE);
  FieldDesc far &desc = co->desc[fldnbr-1];
  fNull = FALSE;
  switch (desc.fldType)
  {
    case fldChar:
      lastError = PXGetAlpha(recH, fldnbr, bufLen, (char far *) buf);
      if (ISBLANKALPHA((char *) buf))
        fNull = TRUE;
      return(lastError);
    case fldShort:
      if (bufLen < sizeof(short))
        return(lastError = PXERR_BUFTOOSMALL);
      lastError = PXGetShort(recH, fldnbr, (short far *)buf);
      if (ISBLANKSHORT(*((short *) buf)))
        fNull = TRUE;
      return(lastError);
    case fldDouble:
      if (bufLen < sizeof(double))
        return(lastError = PXERR_BUFTOOSMALL);
      lastError = PXGetDoub(recH, fldnbr, (double far *)buf);
      if (ISBLANKDOUBLE(*((double *)buf)))
        fNull = TRUE;
      return(lastError);
    case fldDate:
      lastError = PXGetDate(recH, fldnbr, (long far *)buf);
      if (ISBLANKDATE(*((long *) buf)))
        fNull = TRUE;
      else if (lastError == PXSUCCESS)
      {
        PXDateDecode(*((long far *)buf), &m,&d,&y);
        dt->month = m;
        dt->day = d;
        dt->year = y;
      }
      return(lastError);
    default:
      return(lastError = PXERR_TYPEMISMATCH);
  }
}

Retcode BRecord::getField(FIELDNUMBER fldnbr, double& val, BOOL& fNull)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if ((lastError = getField(fldnbr, (void *) buf, 30, fNull)) != PXSUCCESS)
    return(lastError);
  if (fNull)
    return(lastError = PXSUCCESS);
  getFieldDesc(fldnbr,fldType,fldSubtype,fldLen);
  return(lastError = convertFld((void *)buf,  fldType,  30,
    (void *) &val, fldDouble, sizeof(double)));
}

Retcode BRecord::getField(FIELDNUMBER fldnbr, INT16& val, BOOL& fNull)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if ((lastError = getField(fldnbr, (void *) buf, 30,fNull)) != PXSUCCESS)
    return(lastError);
  if (fNull)
    return(lastError = PXSUCCESS);
  getFieldDesc(fldnbr,fldType,fldSubtype,fldLen);
  return(lastError = convertFld((void *)buf, fldType, 30,
    (void *) &val, fldShort, sizeof(short)));
}

Retcode BRecord::getField(FIELDNUMBER fldnbr, INT32& val, BOOL& fNull)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if ((lastError = getField(fldnbr, (void *) buf, 30, fNull)) != PXSUCCESS)
    return(lastError);
  if (fNull)
    return(lastError = PXSUCCESS);
  getFieldDesc(fldnbr,fldType,fldSubtype,fldLen);
  return(lastError = convertFld((void *)buf, fldType, 30,
    (void *) &val, fldLong, sizeof(long)));
}

Retcode BRecord::getField(FIELDNUMBER fldnbr, BDate& val, BOOL& fNull)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if ((lastError = getField(fldnbr, (void *) buf, 30, fNull)) != PXSUCCESS)
    return(lastError);
  if (fNull)
    return(lastError = PXSUCCESS);
  getFieldDesc(fldnbr,fldType,fldSubtype,fldLen);
  return(lastError = convertFld((void *)buf, fldType, 30,
    (void *) &val, fldDate, sizeof(BDate)));
}

Retcode BRecord::getField(char *fldName, char *buf, int bufLen, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, buf, bufLen,fNull));
}

Retcode BRecord::getField(char *fldName, void *buf, int bufLen, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, buf, bufLen, fNull));
}

Retcode BRecord::getField(char *fldName, double& val, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, val, fNull));
}

Retcode BRecord::getField(char *fldName, INT16& val, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, val, fNull));
}

Retcode BRecord::getField(char *fldName, INT32& val, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, val, fNull));
}

Retcode BRecord::getField(char *fldName, BDate& val, BOOL& fNull)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(getField(fld, val, fNull));
}

// The following putField functions provide counterpart
// operations to getField functions.

Retcode BRecord::putField(FIELDNUMBER fldnbr, const char *buf)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           tempBuf[31];

  int len = strlen(buf);
  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (getFieldDesc(fldnbr,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if (fldType != fldChar)
  {
    if ((lastError = convertFld((void *)buf,    fldChar, len,
      (void *)tempBuf,fldType, 30)) != PXSUCCESS)
      return(lastError);
    return(lastError = putField(fldnbr, (void *) tempBuf));
  }
  else
    return(lastError = putField(fldnbr, (void *) buf));
}

Retcode BRecord::putField(FIELDNUMBER fldnbr, const void *buf)
{
  BDate *dt = (BDate *) buf;
  curdef *co = (curdef *)curH->curobj;
  long ld;
  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (fldnbr > co->fieldCnt || fldnbr < 1)
    return(lastError = PXERR_INVFIELDHANDLE);
  FieldDesc far &desc = co->desc[fldnbr-1];
  switch (desc.fldType)
  {
    case fldChar:
      return(lastError = PXPutAlpha(recH, fldnbr, (char far *) buf));
    case fldShort:
      return(lastError = PXPutShort(recH, fldnbr, *((short *)buf)));
    case fldDouble:
      return(lastError = PXPutDoub(recH, fldnbr, *((double *)buf)));
    case fldDate:
      if ((lastError = PXDateEncode((int)dt->month, (int)dt->day,
        (int)dt->year,  &ld)) == PXSUCCESS)
          lastError = PXPutDate(recH, fldnbr, ld);
      return(lastError);
    default:
      return(lastError = PXERR_TYPEMISMATCH);
  }
}

Retcode BRecord::putField(FIELDNUMBER fldnbr, double val)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (getFieldDesc(fldnbr,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if ((lastError = convertFld((void *)&val, fldDouble, sizeof(double),
    (void *)buf,fldType, 30)) != PXSUCCESS)
    return(lastError);
  return(lastError = putField(fldnbr, (void *) buf));
}

Retcode BRecord::putField(FIELDNUMBER fldnbr, INT16 val)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (getFieldDesc(fldnbr,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if ((lastError = convertFld((void *)&val, fldShort, sizeof(short),
    (void *)buf,fldType, 30)) != PXSUCCESS)
    return(lastError);
  return(lastError = putField(fldnbr, (void *) buf));
}

Retcode BRecord::putField(FIELDNUMBER fldnbr, INT32 val)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (getFieldDesc(fldnbr,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if ((lastError = convertFld((void *)&val, fldLong, sizeof(long),
    (void *)buf,fldType, 30)) != PXSUCCESS)
    return(lastError);
  return(lastError = putField(fldnbr, (void *) buf));
}

Retcode BRecord::putField(FIELDNUMBER fldnbr, const BDate& val)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;
  char           buf[31];

  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (getFieldDesc(fldnbr,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if ((lastError = convertFld((void *)&val, fldDate, sizeof(BDate),
    (void *)buf,fldType, 30)) != PXSUCCESS)
    return(lastError);
  return(lastError = putField(fldnbr, (void *) buf));
}

Retcode BRecord::putField(char *fldName, const char *buf)
{
  FIELDNUMBER fld;

  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, buf));
}

Retcode BRecord::putField(char *fldName, const void *buf)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, buf));
}

Retcode BRecord::putField(char *fldName, double val)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, val));
}

Retcode BRecord::putField(char *fldName, INT16 val)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, val));
}

Retcode BRecord::putField(char *fldName, INT32 val)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, val));
}

Retcode BRecord::putField(char *fldName, const BDate& val)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(putField(fld, val));
}

// Test if a field is null.

BOOL BRecord::isNull(FIELDNUMBER fldnbr)
{
  BOOL blank;
  if ((lastError = PXFldBlank(recH,fldnbr,&blank)) != PXSUCCESS)
    return(FALSE);
  return(blank);
}

BOOL BRecord::isNull(const char *fldname)
{
  FIELDNUMBER fld;
  if ((fld = getFieldNumber(fldname)) == 0)
    return(FALSE);
  return(isNull(fld));
}

// Set a field to blank.

Retcode BRecord::setNull(FIELDNUMBER fldnbr)
{
  return(lastError = PXPutBlank(recH,fldnbr));
}

Retcode BRecord::setNull(const char *fldName)
{
  FIELDNUMBER fld;

  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(setNull(fld));
}

Retcode BRecord::clearNull(FIELDNUMBER fldnbr)
{
  curdef *co = (curdef *)curH->curobj;
  if (! recH)
    return(lastError = PXERR_INVRECHANDLE);
  if (fldnbr > co->fieldCnt || fldnbr < 1)
    return(lastError = PXERR_INVFIELDHANDLE);
  return(PXERR_NOCLEARNULL);
}

Retcode BRecord::clearNull(const char *fldName)
{
  FIELDNUMBER fld;

  if ((fld = getFieldNumber(fldName)) == 0)
    return(lastError);
  return(clearNull(fld));
}

// Open a BLOB for subsequent read or write operations based on mode.

Retcode BRecord::openBlobRead(FIELDNUMBER fldnbr, BOOL usePrivateCopy)
{
  blbdef blb;

  // Use the field number of the BLOB in the table, not the
  // custom record. That way, this function does not need
  // to be duplicated in custom record classes.

  FIELDNUMBER tblfld = getTblFieldNumber(fldnbr);
  if (usePrivateCopy)
    if ((lastError = PXBlobClone(recH, tblfld)) != PXSUCCESS)
      return(lastError);
  if ((lastError = PXBlobOpenRead(recH,tblfld,&blb.blbH)) != PXSUCCESS)
    return(lastError);
  blb.fldnbr = fldnbr;
  blb.privateBlb = usePrivateCopy;
  blb.state = blbOpenRead;
  blb.blbRecH = recH;
  return(lastError = addBlob((recdef *)recobj, &blb));
}

Retcode BRecord::openBlobWrite(FIELDNUMBER fldnbr, long size, BOOL copyOld)
{
  blbdef blb;
  FIELDNUMBER tblfld = getTblFieldNumber(fldnbr);
  lastError = PXBlobOpenWrite(recH,tblfld,&blb.blbH,size,(int)copyOld);
  if (!lastError)
  {
    blb.fldnbr = fldnbr;
    blb.privateBlb = TRUE;
    blb.state = blbOpenWrite;
    blb.blbRecH = recH;
    lastError = addBlob((recdef *)recobj, &blb);
  }
  return(lastError);
}

// Get a BLOB Header.

Retcode BRecord::getBlobHeader(FIELDNUMBER fldnbr, int size,
  void *buffer, int& bytesRead)
{
 fldnbr = getTblFieldNumber(fldnbr);
 return(lastError = PXBlobQuickGet(recH,fldnbr,size,buffer,&bytesRead));
}

//  Get the size of an open BLOB.

long BRecord::getBlobSize(FIELDNUMBER fld)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;

  if (getFieldDesc(fld,fldType,fldSubtype,fldLen))
  {
    lastError = PXERR_INVFIELDHANDLE;
    return(0);
  }
  if (fldType != fldBlob)
  {
    lastError = PXERR_TYPEMISMATCH;
    return(0);
  }
  recdef *ro = (recdef *) recobj;
  unsigned long size;
  for (int i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].fldnbr == fld && (BOOL) ro->recblb[i].state)
      break;
  if (i == ro->handleCnt)
  {
    lastError = PXERR_BLOBNOTOPEN;
    return(0);
  }
  if ((lastError = PXBlobGetSize(ro->recblb[i].blbH, &size)) != PXSUCCESS)
    return(0);
  return(size);
}

// Read a segment of an open BLOB.

Retcode BRecord::getBlob(FIELDNUMBER fld, unsigned int size,
  long offset, void far *buffer)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;

  if (getFieldDesc(fld,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if (fldType != fldBlob)
    return(lastError = PXERR_TYPEMISMATCH);
  recdef *ro = (recdef *) recobj;
  for (int i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].fldnbr == fld && (int) ro->recblb[i].state)
      break;
  if (i == ro->handleCnt)
    return(lastError = PXERR_BLOBNOTOPEN);
  return(lastError = PXBlobGet(ro->recblb[i].blbH,size,offset,buffer));
}

// Close an open BLOB handle; closes both private and public BLOBs.
// For a field, at most, one BLOB can be open at any time.

Retcode BRecord::closeBlob(FIELDNUMBER fld, BOOL accept)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;

  if (getFieldDesc(fld,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if (fldType != fldBlob)
    return(lastError = PXERR_TYPEMISMATCH);
  recdef *ro = (recdef *) recobj;
  for (int i=0; i < ro->handleCnt; i++)
    if (ro->recblb[i].fldnbr == fld && (int) ro->recblb[i].state)
      break;
  if (i == ro->handleCnt)
    return(lastError = PXERR_BLOBNOTOPEN);
  lastError = PXBlobClose(ro->recblb[i].blbH, accept);
  ro->recblb[i].state = blbClosed;
  ro->recblb[i].privateBlb = FALSE;
  return(lastError);
}

// Write a segment of an open BLOB.

Retcode BRecord::putBlob(FIELDNUMBER fld, unsigned int size,
  long offset, void far *buffer)
{
  PXFieldType    fldType;
  PXFieldSubtype fldSubtype;
  int            fldLen;

  if (getFieldDesc(fld,fldType,fldSubtype,fldLen))
    return(lastError = PXERR_INVFIELDHANDLE);
  if (fldType != fldBlob)
    return(lastError = PXERR_TYPEMISMATCH);
  recdef *ro = (recdef *) recobj;
  for (int i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].fldnbr == fld && (int) ro->recblb[i].state)
      break;
  if (i == ro->handleCnt)
    return(lastError = PXERR_BLOBNOTOPEN);
  if ((lastError = PXBlobPut(ro->recblb[i].blbH, size,
    offset, buffer)) != PXSUCCESS)
    return(lastError);
  clearNull(fld);                // Clear the null bit in Custom records.
  return(lastError = PXSUCCESS); // Ignore clearNull error for generic
                                 // records.
}

// Drop a BLOB field from a record.

Retcode BRecord::dropBlob(FIELDNUMBER fldnbr)
{
  return(lastError = PXBlobDrop(recH, fldnbr));
}

// This function provides a place holder for preprocessing
// routines.

Retcode BRecord::preprocess()
{
  return(lastError = PXSUCCESS);
}

// This function provides a place holder for postprocessing
// routines.

Retcode BRecord::postprocess()
{
  return(lastError = PXSUCCESS);
}

// Redefine pure virtuals from the BDbObject class.

char * BRecord::nameOf() const
{
  return("BRecord");
}

void BRecord::printOn( ostream& os)
{
  FieldDesc  desc;
  char *buf = new char[256];
  BOOL fNull;
  if (! buf)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  }
  int cnt = getFieldCount();
  os << nameOf() << " { \n";
  for (int i=1; i <= cnt; i++)
  {
    getFieldDesc(i, desc);
    getField(i, buf, 256, fNull);
    os << "     " << desc.fldName << " = ";
    if (desc.fldType == fldBlob)
      os << "Blob Field";
    else if (fNull)
      os << "Null" ;
    else
      os << buf ;
    os << "\n";
  }
  os << "}\n";
  delete buf;
}

// The following two routines are used to maintain a list of records
// for a cursor. The Database Framework does not assume the presence
// of any Class library (not even Borland's container library Classlib).
// Consequently, no List class is used.

Retcode addRecord(curdef *cur, BRecord *rec)
{
  // Add this record object to the record vector in the cursor.

  int i;
  BRecord **newvec;
  for (i = 0; i < cur->handleCnt; i++)
    if (! cur->recList[i])            // empty slot ?
    {
      cur->recList[i] = rec;
      return(PXSUCCESS);
    }
  if (! (newvec = new BRecord *[cur->handleCnt+4]) )    // Four more handles.
    return(PXERR_OUTOFMEM);
  for (i = 0; i < cur->handleCnt; i++)
    newvec[i] = cur->recList[i];
  newvec[i++] = rec;
  newvec[i] = newvec[i+1] = newvec[i+2] = 0;
  if (cur->handleCnt)
    delete [] cur->recList;
  cur->handleCnt += 4;
  cur->recList = newvec;
  return(PXSUCCESS);
}

// Delete the record from the Open Record list of its cursor.

void deleteRecord(curdef *cur, BRecord *rec)
{
  for (int i = 0; i < cur->handleCnt; i++)
    if (cur->recList[i] == rec)
    {
      cur->recList[i] = 0;
      return;
    }
}

// Add the BLOB to the Open BLOB list of its record.

Retcode addBlob(recdef *rec, blbdef *blb)
{
  // Add this BLOB definition to the Record object.

  int i;
  blbdef *newvec;
  for (i = 0; i < rec->handleCnt; i++)
    if (rec->recblb[i].fldnbr == blb->fldnbr)  // BLOB field already has
    {                                          // a slot.
      rec->recblb[i] = *blb;
      return(PXSUCCESS);
    }
  if (! (newvec = new blbdef[rec->handleCnt+1]) )   // One more handle.
    return(PXERR_OUTOFMEM);
  for (i = 0; i < rec->handleCnt; i++)
    newvec[i] = rec->recblb[i];
  newvec[i] = *blb;
  if (rec->handleCnt)
    delete [] rec->recblb;
  rec->handleCnt += 1;
  rec->recblb = newvec;
  return(PXSUCCESS);
}

// Convert value in source pointed to by srcPtr and leave
// the result in destPtr;

Retcode convertFld(void *srcPtr, PXFieldType srcType, int srcLen,
     void *destPtr, PXFieldType destType, int destLen)
{
   char buf[31];
   BDate dt;
   long ld;
   double db;
   Retcode ret = 0;
   switch(destType)
   {
     case fldChar:
       switch(srcType)
       {
         case fldChar:
           if (srcPtr == destPtr)            // Nothing to copy.
             return(ret);
           break;
         case fldShort:
           srcLen = sprintf(buf,"%d",*((short *) srcPtr));
           srcPtr = buf;
           break;
         case fldLong:
           srcLen = sprintf(buf,"%ld",*((long *) srcPtr));
           srcPtr = buf;
           break;
         case fldDouble:
           srcLen = sprintf(buf,"%G",*((double *) srcPtr));
           srcPtr = buf;
           break;
         case fldDate:
           dateToStr((BDate *) srcPtr, buf);
           srcPtr = buf;
           break;
         default:
           return(PXERR_INVFIELDTYPE);
       }
       if (srcLen > destLen && strlen((char *) srcPtr) > destLen)
       {
         ret = PXERR_BUFTOOSMALL;
         strncpy((char *) destPtr, (char *) srcPtr, destLen);
       }
       else
         strcpy((char *) destPtr, (char *) srcPtr);
       break;

     case fldShort:
       switch(srcType)
       {
         case fldChar:
           if (sscanf((char *) srcPtr,"%lf",&db) < 1)
             ret = PXERR_DATACONV;
           if (db < SHRT_MIN || db > SHRT_MAX)
             ret = PXERR_OUTOFRANGE;
           *((short *) destPtr) = (short) db;
           break;
         case fldShort:
           *((short *) destPtr) = *((short *) srcPtr);
           break;
         case fldLong:
           ld = *((long *) srcPtr);
           if (ld < SHRT_MIN || ld > SHRT_MAX)
             ret = PXERR_OUTOFRANGE;
           *((short *) destPtr) = (short) ld;
           break;
         case fldDouble:
           db = *((double *) srcPtr);
           if (ISBLANKDOUBLE(db))
             ret = PXERR_DATACONV;
           else if (db < SHRT_MIN || db > SHRT_MAX)
             ret = PXERR_OUTOFRANGE;
           else
             *((short *) destPtr) = (short) db;
           break;
         case fldDate:
           ret = PXERR_TYPEMISMATCH;
           break;
         default:
           ret = PXERR_INVFIELDTYPE;
           break;
       }
       break;

     case fldDouble:
       switch(srcType)
       {
         case fldChar:
           if (sscanf((char *) srcPtr,"%lf",&db) < 1)
             ret = PXERR_DATACONV;
           *((double *) destPtr) = db;
           break;
         case fldShort:
           *((double *) destPtr) = *((short *) srcPtr);
           break;
         case fldLong:
           *((double *) destPtr) = *((long *) srcPtr);
           break;
         case fldDouble:
           *((double *) destPtr) = *((double *) srcPtr);
           break;
         case fldDate:
           ret = PXERR_TYPEMISMATCH;
           break;
         default:
           ret = PXERR_INVFIELDTYPE;
           break;
       }
       break;

     case fldLong:
       switch(srcType)
       {
         case fldChar:
           if (sscanf((char *) srcPtr,"%lf",&db) < 1)
             ret = PXERR_DATACONV;
           if (db < LONG_MIN || db > LONG_MAX)
             ret = PXERR_OUTOFRANGE;
           *((long *) destPtr) = (long) db;
           break;
         case fldShort:
           *((long *) destPtr) = *((short *) srcPtr);
           break;
         case fldLong:
           *((long *) destPtr) = *((long *) srcPtr);
           break;
         case fldDouble:
           db = *((double *) srcPtr);
           if (ISBLANKDOUBLE(db))
             ret = PXERR_DATACONV;
           else if (db < LONG_MIN || db > LONG_MAX)
             ret = PXERR_OUTOFRANGE;
           else
             *((long *) destPtr) = (long) db;
           break;
         case fldDate:
           ret = PXERR_TYPEMISMATCH;
           break;
         default:
           ret = PXERR_INVFIELDTYPE;
           break;
       }
       break;

     case fldDate:
       switch(srcType)
       {
         case fldChar:
           ret = strToDate((char *) srcPtr, &dt);
           *((BDate *) destPtr) = dt;
           break;
         case fldShort:
         case fldLong:
         case fldDouble:
           ret = PXERR_TYPEMISMATCH;
           break;
         case fldDate:
           *((BDate *) destPtr) = *((BDate *) srcPtr);
           break;
         default:
           ret = PXERR_INVFIELDTYPE;
           break;
       }
       break;

     default:
       ret = PXERR_INVFIELDTYPE;
       break;
   }
   return(ret);
}

//  Convert String to Date. The string must be in the format
//  MM/DD/YYYY. You may rewrite this function to handle a
//  variety of different Date formats.

Retcode strToDate(const char *str, BDate *dt)
{
  int  i;
  long ld;

  if (! isdigit(*str))
    return(PXERR_INVDATE);
  dt->month = *str++ - '0';
  if (isdigit(*str))
    dt->month = dt->month * 10 + (*str++ - '0');     // 2-digit month.
  if (*str++ != '/')
    return(PXERR_INVDATE);
  if (! isdigit(*str))
    return(PXERR_INVDATE);
  dt->day = *str++ - '0';
  if (isdigit(*str))
    dt->day = dt->day * 10 + (*str++ - '0');         // 2-digit day.
  if (*str++ != '/')
    return(PXERR_INVDATE);
  if (! isdigit(*str))
    return(PXERR_INVDATE);
  i = *str++ - '0';
  if (! isdigit(*str))
    return(PXERR_INVDATE);
  i = i * 10 + (*str++ - '0');
  if (! *str)                                        // 2-digit year.
    i += 1900;
  else
  {
    if (! isdigit(*str))
      return(PXERR_INVDATE);
    i = i * 10 + *str++ - '0';
    if (! isdigit(*str))
      return(PXERR_INVDATE);
    i = i * 10 + (*str++ - '0');                     // 4-digit year.
    if (*str)
      return(PXERR_INVDATE);
  }
  dt->year = i;
  return(PXDateEncode(dt->month,dt->day,dt->year,&ld));
}



// Convert Date to String. The string will be output in the format
// MM/DD/YYYY. You may rewrite this function to handle a variety of
// different Date formats.

Retcode dateToStr(const BDate *dt, char *str)
{
  sprintf(str,"%02d/%02d/%04d",(int) dt->month,(int) dt->day,
    (int) dt->year); return(PXSUCCESS);
}
