/*********************************************************************
**
**                          BCURSOR.CPP
**
** This file contains member functions of the BCursor class.
**  
**
*********************************************************************/

#include "envdef.h"
#include "bcursor.h"
#include "bengine.h"
#include "bdatabas.h"
#include "brecord.h"
#include "pxengine.h"
#include "intstrct.h"
#include <string.h>
#include <stdarg.h>
#include <malloc.h> 

#ifdef __DLL__
   #define EXPORT _export
#else
   #define EXPORT
#endif

Retcode EXPORT addCursor(dbdef *, BCursor *);    // Prototype for utility 
                                                 // function.

void EXPORT deleteCursor(dbdef *, BCursor *);    // Prototype for utility 
                                                 // function.

Retcode getDesc(TABLEHANDLE,int&,FieldDesc far *);  // Prototype utility 
                                                    // function in BDatabas.

Retcode EXPORT convertFld(void *, PXFieldType, int,  // Source value.
                   void *, PXFieldType, int);        // Destination.

int getPdxRecSize(FieldDesc far *desc, int numFields);

// Make only the object, not any Paradox cursors.

BCursor::BCursor()
{
  genericRec = 0; 
  curdef *co = new curdef;       // See the INTSTRCT.H file.
  if (! co)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  }
  lastError = PXSUCCESS;
  co->handleCnt = 0;
  co->fieldCnt = 0;
  co->recList = 0;
  curobj = (void *)co;
  co->dbH = 0;
  isOpen = FALSE;
  curStatus = atBegin;
}

// Create the object and open a Paradox cursor.

BCursor::BCursor(BDatabase *db,
                 const char *tableName,
                 int indexID,
                 BOOL saveEveryChange)
{
  curdef *co = new curdef; 	    // See the INTSTRCT.H file.
  if (! co)
  {
    lastError = PXERR_OUTOFMEM;
    return;
  }
  co->handleCnt = 0;
  co->recList = 0;
  co->indexID = indexID;
  co->fieldCnt = 0;
  co->saveEveryChange = saveEveryChange;
  curobj = (void *)co;
  isOpen = FALSE;
  curStatus = atBegin;
  co->dbH = 0;
  if (! db->isOpen)
  {
    lastError = PXERR_DBNOTOPEN;
    return;
  }
  if ((lastError = PXTblOpen((char far *) tableName, &tabH,
    indexID, (int)saveEveryChange)) != PXSUCCESS)
    return;
  isOpen = TRUE;
  tabname = new char[strlen(tableName)+1];
  strcpy(tabname,tableName);

  // Allocate descriptors, add this cursor to the database, and create a 
  // generic record. If any of these result in error, close the cursor 
  // and return an error. 

  if (!(genericRec = new BRecord(this))) 
    lastError = PXERR_OUTOFMEM;
  else if (genericRec->lastError != PXSUCCESS) 
  { 
    lastError = genericRec->lastError;  
    delete genericRec; 
    genericRec = 0;
  } 
  else if ((lastError = addCursor((dbdef *)db->dbobj, this)) == PXSUCCESS)
  {
    co->dbH = db;
    PXRecNFlds(tabH,&co->fieldCnt);
    co->desc = (FieldDesc far *) _fmalloc(sizeof(FieldDesc) * co->fieldCnt);
    if (! co->desc)
      lastError = PXERR_OUTOFMEM; 
    else  
      lastError = getDesc(tabH, co->fieldCnt, co->desc);
  }; 
  if (lastError)
  {
    PXTblClose(tabH);
    delete tabname; 
    isOpen = FALSE;
  }
}

// Destructor that closes the cursor if it's open.

BCursor::~BCursor() 
{
  if (isOpen)
    close();
  curdef *co  = (curdef *)curobj;
  if (co) 
  {
    if (co->handleCnt) 
      delete [] co->recList;    // Delete the array of record handles.

    if (co->dbH)                // If database object exists, disconnect 
      deleteCursor((dbdef *)	// cursor from the database. 
        co->dbH->dbobj, this);  
      delete co;
  }
}

// Open a cursor on the specified table. indexID specifies the index to use,
// with 0 representing the primary index.

Retcode BCursor::open(BDatabase *db,
                      const char *tableName,
                      int indexID,
                      BOOL saveEveryChange)
{
  if (isOpen)
    return(lastError = PXERR_CURSORALREADYOPEN);
  if (! db->isOpen)
    return(lastError = PXERR_DBNOTOPEN);
  if ((lastError = PXTblOpen((char far *)tableName, &tabH, indexID,
    (int)saveEveryChange)) != PXSUCCESS)
    return(lastError);
  isOpen = TRUE;
  curStatus = atBegin;
  curdef *co = (curdef *)curobj;    
  if (co->dbH != db) 
  {
    // If the database for the cursor is changed, delete old context
    // and add the new one.  

    if (co->dbH)                             // If database object exists,
      deleteCursor((dbdef *) 		     // delete cursor from list.
        co->dbH->dbobj, this); 
    addCursor((dbdef *) db->dbobj, this);
  }
  co->dbH = db;
  co->indexID = indexID;
  co->saveEveryChange = saveEveryChange;
  tabname = new char[strlen(tableName)+1];
  strcpy(tabname,tableName);

  // Create generic record and store the table description
  // with every open cursor so that:
  //
  // 1. All records for a cursor share the same table description.
  //
  // 2. The Paradox Engine is not called for the type of a field
  //    with every Get and Put field operation performed on generic
  //    and custom records.

  if (! (genericRec = new BRecord(this)))  
    lastError = PXERR_OUTOFMEM; 
  else if (genericRec->lastError != PXSUCCESS) 
  { 
    lastError = genericRec->lastError;  
    delete genericRec; 
    genericRec = 0; 
  } 
  else
  {
    PXRecNFlds(tabH,&co->fieldCnt);
    co->desc = (FieldDesc far *) _fmalloc(sizeof(FieldDesc) * co->fieldCnt);
    if (! co->desc)
      lastError = PXERR_OUTOFMEM; 
    else  
      lastError = getDesc(tabH, co->fieldCnt, co->desc);
  }; 
  if (lastError)
  { 
    PXTblClose(tabH);
    delete tabname; 
    isOpen = FALSE;
  }
  return(lastError);
}

// Closes the cursor if it's open.

Retcode BCursor::close()
{
  int i;
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  curdef *co = (curdef *) curobj;
  for (i=0; i < co->handleCnt; i++)
    if (co->recList[i])
      co->recList[i]->detach();
  if ((lastError = PXTblClose(tabH)) != PXSUCCESS)
    return(lastError);
  isOpen = FALSE;
  curStatus = atEnd;
  tabH = 0;
  delete genericRec; 
  genericRec = 0; 
  if (co->fieldCnt != 0)
  {
    _ffree(co->desc);   // Delete previous descriptor.
    co->fieldCnt = 0; 
  }
  delete tabname;
  tabname = 0; 
  return(lastError);
}


//  Append a record to the end of the table using regular and raw I/O.

Retcode BCursor::appendRec(BRecord *rec)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if ((lastError = rec->preprocess()) != PXSUCCESS)
    return(lastError); 

  // Transfer field values from custom fields if this is a custom record. 

  if (strcmp(rec->nameOf(),"BRecord"))
  {
    // Transfer data to custom record's fields.

    char *buf = new char[256];
    if (! buf) 
      return(lastError = PXERR_OUTOFMEM); 

    PXFieldType    fldType1, fldType2;

    PXFieldSubtype fldSubtype; 
    int            fldLen1, fldLen2;  
    int            tblFld;
    BOOL           fNull; 

    int cnt = rec->getFieldCount();
    for (int i=1; i <= cnt; i++)
      if ((tblFld = rec->getTblFieldNumber(i)) > 0)
      {
        if (rec->isNull(i))
        {
          lastError = rec->BRecord::setNull(tblFld);
          continue;
	}

       // Get Paradox table generic record and custom descriptors.  

        rec->BRecord::getFieldDesc(tblFld,fldType2,fldSubtype,fldLen2);
        rec->getFieldDesc(i,fldType1,fldSubtype,fldLen1); 

        if (fldType1 == fldBlob)   
          continue;                      // BLOB handling is separate.
              
        // To transfer values from a custom record to Paradox, the 
	// record handle associated with the BRecord class is used
        // rather than the genericRec of Cursor. This is done because
        // any BLOBs that were constructed for the record are 
        // associated with BRecord's record handle.  

        if ((lastError = rec->getField(i,(void *) buf, 255, fNull))==PXSUCCESS)
        {
          if (fldType1 != fldType2)
            lastError = convertFld((void *)buf,fldType1,fldLen1,
                (void *)buf,fldType2,fldLen2);
          if (! lastError)
	    lastError = rec->BRecord::putField(tblFld, (void *) buf);
        }
        if (lastError)
        {
           delete buf;
           return(lastError);
        }
      }
    delete buf;
  }
  if ((lastError = PXRecAppend(tabH, rec->recH)) == PXSUCCESS) 
    curStatus = atRecord;
  return(lastError); 
}

Retcode BCursor::appendRec(const void far *buffer, int size)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);

  if ((lastError = PXRawPut(genericRec->recH,
    (void far *) buffer, size)) != PXSUCCESS)
    return(lastError);
  if ((lastError = PXRecAppend(tabH, genericRec->recH)) == PXSUCCESS) 
    curStatus = atRecord; 
  return(lastError); 
}


// Insert a record to the table using regular and raw I/O.

Retcode BCursor::insertRec(BRecord *rec)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus == atBegin && getRecCount() > 0)
  {
    if ((lastError = PXRecFirst(tabH)) != PXSUCCESS)
      return(lastError);
  }
  if ((lastError = rec->preprocess()) != PXSUCCESS)
    return(lastError); 

  // Transfer field values from custom fields if this is a custom record.

  if (strcmp(rec->nameOf(),"BRecord"))
  {  
    // Transfer data to the custom record's fields.

    char *buf = new char[256];
    if (! buf) 
      return(lastError = PXERR_OUTOFMEM); 

    PXFieldType    fldType1, fldType2;
    PXFieldSubtype fldSubtype; 
    int            fldLen1, fldLen2;
    int            tblFld;
    BOOL           fNull; 

    int cnt = rec->getFieldCount();
    for (int i=1; i <= cnt; i++)
      if ((tblFld = rec->getTblFieldNumber(i)) > 0)
      {
        if (rec->isNull(i))
        {
            lastError = rec->BRecord::setNull(tblFld);
	  continue;
        }
   // Get the Paradox table generic record and custom descriptors.  

        rec->BRecord::getFieldDesc(tblFld,fldType2,fldSubtype,fldLen2);
        rec->getFieldDesc(i,fldType1,fldSubtype,fldLen1); 
        if (fldType1 == fldBlob)   
          continue;                  // BLOB handling is separate.
              
        // To transfer values from a custom record to Paradox, we use 
        // the record handle associated with the BRecord class rather 
	// than the genericRec of Cursor. This is done because any BLOBs
        // that were constructed for the record are associated with 
        // BRecord's record handle.  

        if ((lastError = rec->getField(i,(void *) buf,
          255, fNull))==PXSUCCESS)
        {
          if (fldType1 != fldType2)
            lastError = convertFld((void *)buf,fldType1,fldLen1,
                 (void *)buf,fldType2,fldLen2);
          if (! lastError)
	    lastError = rec->BRecord::putField(tblFld, (void *) buf);
        }
        if (lastError)
        {
           delete buf;
           return(lastError);
        }
      }
    delete buf;
  }
  if (curStatus == atEnd) 
    lastError = PXRecAppend(tabH, rec->recH);
  else 
    lastError = PXRecInsert(tabH, rec->recH);
  if (lastError == PXSUCCESS) 
    curStatus = atRecord;
  return(lastError); 
}

Retcode BCursor::insertRec(const void far *buffer, int size)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus == atBegin && getRecCount() > 0)
  {
    if ((lastError = PXRecFirst(tabH)) != PXSUCCESS)
     return(lastError);
  }
  if ((lastError = PXRawPut(genericRec->recH,
    (void far *) buffer, size)) != PXSUCCESS)
    return(lastError);
  if (curStatus == atEnd) 
    lastError = PXRecAppend(tabH, genericRec->recH); 
  else
    lastError = PXRecInsert(tabH, genericRec->recH);
  if (lastError == PXSUCCESS) 
    curStatus = atRecord;
  return(lastError); 
}

// Delete the current record of the cursor.

Retcode BCursor::deleteRec()
{
  PXCursorStatus cs; 
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus != atRecord)
    return(lastError = PXERR_INVCURRRECORD);
  if (getRecCount() == getCurRecNum()) 	      // Last record ?
    cs = atEnd;
  else 
    cs = atCrack; 
  if ((lastError = PXRecDelete(tabH)) == PXSUCCESS)
    curStatus = cs;
  return(lastError); 
}

// Update the current record of the cursor using regular and raw I/O.

Retcode BCursor::updateRec(BRecord *rec)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus != atRecord)
    return(lastError = PXERR_INVCURRRECORD);
  if ((lastError = rec->preprocess()) != PXSUCCESS)
    return(lastError); 

  // Transfer field values from custom fields if this is a custom record.

  if (strcmp(rec->nameOf(),"BRecord"))
  {
    // Transfer data to the custom record's fields.

    char *buf = new char[256];
    if (! buf) 
      return(lastError = PXERR_OUTOFMEM); 

    PXFieldType    fldType1, fldType2;
    PXFieldSubtype fldSubtype; 
    int            fldLen1, fldLen2;  
    int            tblFld;
    BOOL           fNull; 

    int cnt = rec->getFieldCount();
    for (int i=1; i <= cnt; i++)
      if ((tblFld = rec->getTblFieldNumber(i)) > 0)
      {
        if (rec->isNull(i))
        {
          lastError = rec->BRecord::setNull(tblFld);
          continue;
	}

        // Get the Paradox table generic record and custom descriptors.  

        rec->BRecord::getFieldDesc(tblFld,fldType2,fldSubtype,fldLen2);
        rec->getFieldDesc(i,fldType1,fldSubtype,fldLen1);  
        if (fldType1 == fldBlob)   
          continue;                  // BLOB handling is separate.
              
        // To transfer values from a custom record to Paradox, the  
        // record handle associated with the BRecord class is used rather 
	// than the genericRec of Cursor. This is done because any BLOBs
        // that were constructed for the record are associated with 
        // BRecord's record handle.  

        if ((lastError= rec->getField(i, (void *) buf, 255, fNull))==PXSUCCESS)
        {
          if (fldType1 != fldType2)
            lastError = convertFld((void *)buf,fldType1,fldLen1,
                 (void *)buf,fldType2,fldLen2);
          if (! lastError)
            lastError = rec->BRecord::putField(tblFld, (void *) buf); 
	}
        if (lastError)
        {
           delete buf;
                 return(lastError);
        }
      }
    delete buf;
  }
  return(lastError = PXRecUpdate(tabH, rec->recH));
}

Retcode BCursor::updateRec(const void far *buffer, int size)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus != atRecord)
    return(lastError = PXERR_INVCURRRECORD);
  if ((lastError = PXRawPut(genericRec->recH,
    (void far *) buffer, size)) != PXSUCCESS)
    return(lastError);
  return(lastError = PXRecUpdate(tabH, genericRec->recH));
}

// Position before the first record of the table. This function 
// is provided, instead of gotoFirst, to maintain compatibility 
// with future Borland database products. 

Retcode BCursor::gotoBegin()
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  curStatus = atBegin;
  return(lastError = PXSUCCESS);
}

// Go to the end of the table.

Retcode BCursor::gotoEnd()
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  curStatus = atEnd;
  return(lastError = PXSUCCESS);
}
       
// Go to a specific record number in the table.

Retcode BCursor::gotoRec(RECORDNUMBER recNum)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if ((lastError = PXRecGoto(tabH,recNum)) == PXSUCCESS)  
    curStatus = atRecord;
  return(lastError); 
}

// Go to the next record of the table.

Retcode BCursor::gotoNext()
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN); 
  if (curStatus == atBegin)
  {
    if ((lastError = PXRecFirst(tabH)) == PXSUCCESS)
      curStatus = atRecord;
    return(lastError); 
  }
  if (curStatus == atEnd)
    return(lastError = PXERR_ENDOFTABLE); 

  // Paradox Engine positions the cursor on a new record after 
  // Delete. You do not need to fetch the next record to
  // move to the next record. 
 
  if (curStatus == atCrack)
  {
    curStatus = atRecord;
    return(lastError = PXSUCCESS);           
  }
  return(lastError = PXRecNext(tabH));     // Go to the next record.
}

// Go to the previous record of the table.

Retcode BCursor::gotoPrev()
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN); 
  if (curStatus == atEnd)
  {
    if ((lastError = PXRecLast(tabH)) == PXSUCCESS)
      curStatus = atRecord;
    return(lastError); 
  }
  if (curStatus == atBegin)
    return(lastError = PXERR_STARTOFTABLE);
  if ((lastError = PXRecPrev(tabH)) == PXSUCCESS)
    curStatus = atRecord;
  return(lastError); 
}

// Get the record number of the current record. 

RECORDNUMBER BCursor::getCurRecNum()
{
  RECORDNUMBER recNum = 0;
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN;
    return(0);
  }
  if (curStatus != atRecord)
  {
    lastError = PXERR_INVCURRRECORD; 
    return(0);
  }
  lastError = PXRecNum(tabH, &recNum);
  return(recNum);   
} 

// Get the current record of the cursor. The three different
// signatures of the getRecord function are the following:
//
//   1. User-supplied record object.
//
//   2. Cursor's generic record object.
// 
//   3. Raw I/O.

Retcode BCursor::getRecord(BRecord *rec)
{
  int i; 
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus != atRecord)
    return(lastError = PXERR_INVCURRRECORD);
  if ((lastError = PXRecGet(tabH, rec->recH)) != PXSUCCESS)
    return(lastError);

  // Register the fact that the BLOBs in the record are now closed.

  recdef *ro = (recdef *) rec->recobj;
  for (i=0;i < ro->handleCnt; i++)
    if (ro->recblb[i].blbRecH == rec->recH)
      ro->recblb[i].state = blbClosed;

  if (! strcmp(rec->nameOf(),"BRecord"))     // Nothing else to do 
    return(lastError = rec->postprocess());  // for generic records.

  // Transfer data to the custom record's fields.

  char *buf = new char[256];
  if (! buf)
    return(lastError = PXERR_OUTOFMEM); 

  PXFieldType    fldType1, fldType2;
  PXFieldSubtype fldSubtype; 
  int            fldLen1, fldLen2;  
  int            tblFld;
  BOOL           fNull; 

  int cnt = rec->getFieldCount();
  for (i=1; i <= cnt; i++)
    if ((tblFld = rec->getTblFieldNumber(i)) > 0)
    {
      // Force getField to get data by calling the Paradox Engine.

      if (rec->BRecord::isNull(tblFld))
      {
        rec->setNull(i);
        continue; 
      }
      rec->clearNull(i);

      // Get the Paradox table generic record and custom descriptors.

      rec->BRecord::getFieldDesc(tblFld,fldType2,fldSubtype,fldLen2);
      rec->getFieldDesc(i,fldType1,fldSubtype,fldLen1);
      if (fldType1 == fldBlob)   
        continue;                             // BLOB handling is separate.

      if ((lastError = rec->BRecord::getField(tblFld, (void *) buf, 
        255, fNull)) == PXSUCCESS)
      {
        if (fldType1 != fldType2)
	  lastError = convertFld((void *)buf,fldType2,fldLen2,
               (void *)buf,fldType1,fldLen1);
          if (! lastError)
            lastError = rec->putField(i, (void *) buf); 
      }
      if (lastError)
      {
         delete buf;
         return(lastError);
      }
    }
    delete buf;
    return(lastError = rec->postprocess());
}

Retcode BCursor::getRecord()
{
  return(getRecord(genericRec));
}

Retcode BCursor::getRecord(void far *buffer, int size)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (curStatus != atRecord)
    return(lastError = PXERR_INVCURRRECORD);
  if ((lastError = PXRecGet(tabH, genericRec->recH)) != PXSUCCESS)
    return(lastError);
  return(lastError = PXRawGet(genericRec->recH, buffer, size));
}

// Lock the table in a shared environment by calling PXNetTblLock.

Retcode BCursor::lockTable(PXLockMode lockMode)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN); 
  return(lastError = PXNetTblLock(tabH,(int)lockMode));
}

// Release a previously acquired lock on a table.

Retcode BCursor::unlockTable(PXLockMode lockMode)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN); 
  return(lastError = PXNetTblUnlock(tabH,(int)lockMode));
}  

// Get a lock for the current record of the cursor.

LOCKHANDLE BCursor::lockRecord()
{
  LOCKHANDLE lckH = 0;
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN;
    return(0);
  }
  if (curStatus != atRecord)
  {   
    lastError = PXERR_INVCURRRECORD;
    return(0);
  }
  if ((lastError = PXNetRecLock(tabH, &lckH)) != PXSUCCESS)
    return(0);
  else
    return(lckH);
}

// Release the previously acquired lock on a record.

Retcode BCursor::unlockRecord(LOCKHANDLE lckH)
{
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  return(lastError = PXNetRecUnlock(tabH, lckH));
}

// Determine whether the current record of the cursor is 
// locked by another user.

BOOL BCursor::isLocked()
{   
  int locked = 0;
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN; 
    return(FALSE);
  }
  if (curStatus != atRecord)
  {   
    lastError = PXERR_INVCURRRECORD;
    return(FALSE);
  }
  lastError = PXNetRecLocked(tabH,&locked); 
  return((BOOL) locked);    
}

// Determine if the cursor table has been changed by any other user.

BOOL BCursor::hasChanged()
{
  int changed = 0; 
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN; 
    return(FALSE);
  }
  lastError = PXNetTblChanged(tabH,&changed);
  return((BOOL) changed);
} 

// Refresh the cursor's buffer to reflect changes.

Retcode BCursor::refresh()
{ 
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN); 
  return(lastError = PXNetTblRefresh(tabH));
}

// Find the number of records in the cursor (or table).

long BCursor::getRecCount()
{
  RECORDNUMBER nRecs = 0;
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN;
    return(0);
  }
  lastError = PXTblNRecs(tabH,&nRecs);
  return((long) nRecs);
}

/***********************************************************************
  The following four functions are used instead of the Paradox Engine's 
  search functions and reflect the direction of new Borland database 
  products.  
*********************************************************************/

//  Clones the cursor with its associated properties.

BCursor * BCursor::clone(BOOL stayCurrent)
{
  RECORDNUMBER recNum;
  if (! isOpen)
  {
    lastError = PXERR_CURSORNOTOPEN;
    return(0);
  }
  curdef *co = (curdef *)curobj;
  BCursor *newcur = new BCursor(co->dbH, tabname,
    co->indexID, co->saveEveryChange);
  if (! newcur)
  {
    lastError = PXERR_OUTOFMEM;
    return(newcur);
  }
  if ((lastError = newcur->lastError) != PXSUCCESS) 
  {
    delete newcur;
    return(0);
  }

  if (curStatus == atBegin || ! stayCurrent) 
    newcur->curStatus = atBegin;
  else if (curStatus == atEnd)
    newcur->curStatus = atEnd;
  else
  {
    // Since both cursors have the same index, they can be set 
    // based on record number, rather than key values. 

    PXRecNum(tabH, &recNum);
    PXRecGoto(newcur->tabH, recNum);
    newcur->curStatus = curStatus;
  }
  return(newcur);
}

//  Position the cursor on the same record as the current record
//  of another cursor.

Retcode BCursor::setToCursor(BCursor *otherCursor)
{
  RECORDNUMBER recNum;
  int          numKeys = 0; 
  int          eqlSize, bufSize;
  BOOL         found = FALSE; 
  char        *rawBuf1, *rawBuf2;
  curdef *co = (curdef *)curobj;
  curdef *co2 = (curdef *) otherCursor->curobj;

  if (! otherCursor->isOpen || ! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (strcmp(tabname,otherCursor->tabname)) 
    return(lastError = PXERR_TABLESDIFFER);

  if (otherCursor->curStatus == atBegin || otherCursor->curStatus == atEnd) 
  {
    curStatus = otherCursor->curStatus;
    return(lastError = PXSUCCESS);
  }

  // Handle the case when both cursors have no index or they have the 
  // same index; use the record number for positioning.  

  if (co->indexID == co2->indexID)
  {
    // Both cursors have no index or same index; use the record number 
    // for positioning. 

    if ((lastError = PXRecNum(otherCursor->tabH, &recNum)) != PXSUCCESS)
      return(lastError);
    if ((lastError = PXRecGoto(tabH, recNum)) == PXSUCCESS)
      curStatus = otherCursor->curStatus;
    return(lastError); 
  }   

  // Get the source record. 

  if ((lastError=otherCursor->getRecord(otherCursor->genericRec)) != PXSUCCESS) 
    return(lastError); 

  // Handle the case when a primary index is used on this (target) record.  
  // Position the cursor based on values from otherCursor. 

  PXKeyNFlds(tabH,&numKeys); 
  if (co->indexID == 0 && numKeys > 0)
  {
    if ((lastError=searchIndex(otherCursor->genericRec,
      pxSearchFirst,numKeys)) == PXSUCCESS)
      curStatus = otherCursor->curStatus;
    return(lastError);
  }

  // Now handle the Secondary index and no index cases. Position based on 
  // the current record of otherCursor. Also, handle duplicate values.   

  if (co->indexID > 0)
  {
    if ((lastError=searchIndex(otherCursor->genericRec,
      pxSearchFirst,numKeys)) != PXSUCCESS)
      return(lastError); 
  } 
  else if ((lastError = PXRecFirst(tabH)) != PXSUCCESS)
    return(lastError); 
  curStatus = otherCursor->curStatus;

  bufSize = getPdxRecSize(co->desc, genericRec->getFieldCount()) + 1; 
  if (numKeys) 
    eqlSize = getPdxRecSize(co->desc, numKeys);        // compare first
  else 						       // numKeys fields
    eqlSize = bufSize; // compare all the fields 
  if ((rawBuf1 = new char[bufSize]) == 0) 
    return(lastError = PXERR_OUTOFMEM);   
  if ((rawBuf2 = new char[bufSize]) == 0) 
  {
    delete rawBuf1; 
    return(lastError = PXERR_OUTOFMEM);   
  } 
  PXRawGet(otherCursor->genericRec->recH, (void far *) rawBuf2, bufSize);      

  while (! found)
  { 
    PXRecGet(tabH,genericRec->recH);                  // Get current record.
    PXRawGet(genericRec->recH, (void far *) rawBuf1, bufSize);       
    if (memcmp(rawBuf1,rawBuf2,eqlSize) == 0) 
      found = TRUE;
    else if (PXRecNext(tabH))  
      break; 
  }
  if (! found)
    lastError = PXERR_RECDELETED;             // Only way to lose the record.
  delete rawBuf1;
  delete rawBuf2;
  return(lastError); 
}


// Search the table for the record that matches key values in keyRec; use
// the currently open index.

Retcode BCursor::searchIndex(const BRecord *keyRec,
			     PXSearchMode mode,
                             int fldCnt)
{
  BRecord *rec = (BRecord *) keyRec;
  curdef *co = (curdef *)curobj;

  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (strcmp(rec->nameOf(),"BRecord"))
  {
    // Transfer data from the custom record's fields to record buffer.

    char *buf = new char[256];
    BOOL           fNull; 

    if (! buf) 
      return(lastError = PXERR_OUTOFMEM); 
    int tblFld, i = 1, lastFld = 0;
    if (co->indexID == 0)
      PXKeyNFlds(tabH,&lastFld);
    else if (co->indexID <= 255)
      i = lastFld = co->indexID;
    if (! lastFld)
      lastFld = rec->getFieldCount();
    for (; i <= lastFld; i++)
      if ((tblFld = rec->getTblFieldNumber(i)) > 0)
      {
        // Force getField to get data by calling the Paradox Engine.

        if (rec->isNull(i))
          lastError = genericRec->setNull(tblFld);
        else if ((lastError = rec->getField(i, (void *) buf,
          255, fNull)) == PXSUCCESS)
	lastError = genericRec->putField(tblFld, (void *) buf);
      }
    delete buf;
    rec = genericRec;
  }

  if (curStatus == atBegin && mode == pxSearchNext)
    mode = pxSearchFirst; 
  else if (curStatus == atEnd)
    if ((lastError = PXRecLast(tabH)) != PXSUCCESS)
      return(lastError); 
  if (co->indexID == 0)          // Primary key or no key.

    lastError = PXSrchKey(tabH, rec->recH, fldCnt, (int) mode);
  else 
    lastError = PXSrchFld(tabH, rec->recH, co->indexID, (int) mode);
  if (! lastError || (mode==pxClosestRecord && lastError==PXERR_RECNOTFOUND))
    curStatus = atRecord;
  return(lastError); 
}

// Search the table for a record that matches key values specified in the
// variable count argument list. Otherwise, its operation is the same
// as other search methods.

Retcode BCursor::searchIndex(PXSearchMode mode, int fldCnt, ...)
{
  int startFld, ind, fld;
  BDate dt;
  long longDate;
  va_list ap;
  va_start(ap, fldCnt);

  curdef *co = (curdef *)curobj;
  engdef *eo = (engdef *) ((((dbdef *)co->dbH->dbobj)->engH)->engobj);

  lastError = PXSUCCESS; 
  if (! isOpen)
    return(lastError = PXERR_CURSORNOTOPEN);
  if (fldCnt < 1)
    return(lastError = PXERR_INVKEYCOUNT);
  if (co->indexID == 0)
    startFld = 1;
  else if (co->indexID <= 255)
  {
    startFld = co->indexID;           // Single field secondary index.
    if (fldCnt > 1)
      return(lastError = PXERR_INVKEYCOUNT);
  }
  else
  {
    for (ind = 0; ind < eo->compIdxCnt; ind++)
      if (eo->keymap[ind].indexId == co->indexID &&
        ! strcmp(eo->keymap[ind].tableName,tabname))
        break;
    if (! eo->compIdxCnt || ind == eo->compIdxCnt)
      return(lastError = PXERR_NOKEYMAP); 
    if (fldCnt < 1 || fldCnt > eo->keymap[ind].keyCnt)
      return(lastError = PXERR_INVKEYCOUNT);
  }

  for (int i=0; i < fldCnt; i++)
  {
    if (co->indexID <= 255)
      fld = startFld;
    else
      fld = eo->keymap[ind].fieldArray[i];
    switch (co->desc[fld-1].fldType)
    {
      case fldChar:
        lastError = PXPutAlpha(genericRec->recH,fld,
          (char far *) va_arg(ap,char *)); 
        break; 
      case fldShort:
        lastError = PXPutShort(genericRec->recH,fld,(short) va_arg(ap,short)); 
        break;
      case fldDouble:
	lastError = PXPutDoub(genericRec->recH,fld,(double) va_arg(ap,double));
        break;
      case fldDate:

        #ifdef _MSC_VER                      // Microsoft C++.
           dt =  va_arg(ap, BDate);
        #else 
           dt =  (BDate) va_arg(ap, BDate);
        #endif 

        if ((lastError = PXDateEncode((int)dt.month, (int)dt.day,
	  dt.year,  &longDate)) == PXSUCCESS)
        lastError = PXPutDate(genericRec->recH,fld,longDate);
        break;
    }
    startFld += 1;
  }
  va_end(ap);

  if (lastError)
    return(lastError);
  return(searchIndex(genericRec, mode, fldCnt));
}

/* Redefine pure virtuals from the BDbObject class.
*/ 
char * BCursor::nameOf() const 
{   
  return("BCursor");
}
 
void BCursor::printOn( ostream& os)  
{
  os << nameOf() << "{ Table Name = " << tabname
     << ", Open Status = " << (int) isOpen << "}\n";
}


// The following two routines are used to maintain a list of cursors for 
// a database. The Database Framework layer does not assume the presence 
// of any Class library (not even Borland's container Classlib). 
// Consequently, no List class is used. 

Retcode addCursor(dbdef *db, BCursor *cur)
{
  // Add this Cursor object to the Cursor vector in the Database.

  int i;
  BCursor **newvec;
  for (i = 0; i < db->handleCnt; i++)
    if (! db->curList[i])     // empty slot ?
    {
      db->curList[i] = cur;
      return(PXSUCCESS);
    }
  if (! (newvec = new BCursor *[db->handleCnt+4]) ) // 4 more handles
    return(PXERR_OUTOFMEM);
  for (i = 0; i < db->handleCnt; i++)
    newvec[i] = db->curList[i];
  newvec[i++] = cur;  
  newvec[i] = newvec[i+1] = newvec[i+2] = 0;
  if (db->handleCnt) 
    delete [] db->curList;     // Delete old vector.
  db->handleCnt += 4;
  db->curList = newvec;
  return(PXSUCCESS);
}

// Delete the cursor object from the known cursor list in its database. 

void deleteCursor(dbdef *db, BCursor *cur)
{
  for (int i = 0; i < db->handleCnt; i++)
    if (db->curList[i] == cur)
    {
      db->curList[i] = 0;
      return;
    }
}                   


// Compute the total size of first numFields of the descriptor. 

int getPdxRecSize(FieldDesc far *desc, int numFields)
{
  int size = 0;
  for (int i = 0; i < numFields; i++)
    if  (desc[i].fldType == fldBlob)
      size += desc[i].fldLen + 10;   // BLOB field in Paradox is 10 + header.
    else if  (desc[i].fldType == fldShort)
      size += 2; 
    else if  (desc[i].fldType == fldDate)
      size += 4; 
    else if  (desc[i].fldType == fldDouble)
      size += 8; 
    else
      size += desc[i].fldLen;
  return(size);
}

