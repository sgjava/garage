/*********************************************************************
**
**                          BCURSOR.H
**
** This file defines the interface to the BCursor class. This class
** encapsulates the notion of a table cursor, an active connection
** to a Paradox table that allows iteration through its records.
** More than one cursor can be open on a table at the same time. 	     	
**
*********************************************************************/

#ifndef BCURSOR_H 
#define BCURSOR_H

#include "envdef.h"
#include "bdbobjec.h"

class BCursor : public BDbObject {

  friend class BDatabase;
  friend class BRecord;

public:

  // Generic Record for this cursor used internally for some custom record
  // transfer operations. Application programs are free to use this object 
  // for the cursor's current record operations.   

  BRecord *genericRec;
  Retcode lastError;
  BOOL    isOpen;

public:

  // Constructor. Make a BCursor object without opening any Paradox tables.

  BCursor();

  // Constructor; make a BCursor object and open the specified Paradox table. 

  BCursor(BDatabase *db,
    const char *tableName,
    int indexID = 0, 
    BOOL saveEveryChange = FALSE);  

  // Destructor; closes the engine if it's open.

  virtual ~BCursor();


  // Open a cursor on the specified table. indexID specifies the 
  // index to use.

  virtual Retcode open(BDatabase *db,
             const char *tableName,
             int indexID = 0,
             BOOL saveEveryChange = 0);

  // Close the cursor if it's open.

  virtual Retcode close();

  // Append a record to the end of table. The record can be a 
  // generic or custom record.

  virtual Retcode appendRec(BRecord *rec);

  // Append a record to the end of table using raw I/O mode 
  // the Paradox Engine. 
  
  virtual Retcode appendRec(const void far *buffer, int size);

  // Insert a record at the current cursor position. The record
  // can be a generic or custom record.

  virtual Retcode insertRec(BRecord *rec);

  // Insert a record at the current cursor position using raw I/O. 

  virtual Retcode insertRec(const void far *buffer, int size);

  // Delete the current record of the cursor.

  virtual Retcode deleteRec();

  // Update the current record of the cursor. The record can be 
  // a generic or custom record.

  virtual Retcode updateRec(BRecord *rec);

  // Update the current of the cursor using the Paradox
  // Engine's raw I/O mode.

  virtual Retcode updateRec(const void far *buffer, int size);

  // Position the cursor before the first record of the table.

  virtual Retcode gotoBegin();

  // Position past the last record of the table.

  virtual Retcode gotoEnd();

  // Go to a specific record number in the table.

  virtual Retcode gotoRec(RECORDNUMBER recNum);

  // Go to the next record of the table.

  virtual Retcode gotoNext();

  // Go to the previous record of the table.

  virtual Retcode gotoPrev();

  // Get the record number of the current record. 

  virtual RECORDNUMBER getCurRecNum();

  // Get the current record of the cursor, which can be a generic 
  // record or a custom record.

  virtual Retcode getRecord(BRecord *rec);

  // Get the current record of the cursor in its genericRec record variable. 

  virtual Retcode getRecord();

  // Get the current record of the cursor using raw I/O.

  virtual Retcode getRecord(void far *buffer, int size);

  // Lock the table in a shared environment in the requested lock mode.  

  virtual Retcode lockTable(PXLockMode lockMode);

  // Release a previously acquired lock on a table.

  virtual Retcode unlockTable(PXLockMode lockMode);

  // Get a lock for the current record of the cursor. 

  virtual LOCKHANDLE lockRecord();

  // Release the previously acquired lock on a record.

  virtual Retcode unlockRecord(LOCKHANDLE lckH);

  // Determine whether the current record is locked by another user.

  virtual BOOL isLocked();

  // Determine if the table of the cursor was changed by another 
  // user on the network since the last refresh of the buffers.

  virtual BOOL hasChanged();
   
  // Refresh the cursor's buffer to reflect changes that 
  // may have occurred. 

  virtual Retcode refresh();

  // Find the number of records in the cursor (or table).

  virtual long getRecCount();

  //  Clone a cursor with its associated properties and return 
  //  the new cursor.

  virtual BCursor *clone(BOOL stayCurrent = TRUE);

  // Position the cursor on the same record as the current record
  // of another cursor on the same table.

  virtual Retcode setToCursor(BCursor *otherCursor);

  // Search the table for the record that matches key values in keyRec. 
  // The currently open index determines the order of records for the search. 

  virtual Retcode searchIndex(const BRecord *keyRec,
            PXSearchMode mode, int fldCnt = 1);  

  // Search the table for a record that matches key values supplied as 
  // parameters in the argument list. 

  virtual Retcode searchIndex(PXSearchMode mode, int fldCnt, ...);

  // Redefine pure virtuals from the BDbObject class. 

  virtual char *nameOf() const; 
  virtual void printOn( ostream& os);

protected:
  char              *tabname;
  TABLEHANDLE       tabH;              // Table handle for cursor.
  PXCursorStatus    curStatus;         // At Begin, End, Crack, or 
                                       // on a record.
private:
  void            *curobj;             // Variable used to keep track of
                                       // cursor's objects.
};

#endif

