/**********************************************************************
**
**                          BDATABASE.H
**
** This file defines the interface for the BDatabase class. This 
** class encapsulates the concept of a Database and defines
** database-level functions that operate on a defined collection 
** of persistent objects like tables, indexes, and so on. 
**
**********************************************************************/

#ifndef BDATABASE_H
#define BDATABASE_H

#include "envdef.h"
#include "bdbobjec.h"

class BDatabase : public BDbObject {

  friend class BEngine;
  friend class BCursor;

public:
  Retcode lastError;
  BOOL    isOpen;

public:

  // Constructor that initializes fields and opens the universal database.

  BDatabase(BEngine *eng);

  // Destructor that closes a database if open. 

  virtual ~BDatabase();

  // Open the database.

  virtual Retcode open(); 

  // Close the database. 

  virtual Retcode close();

  // See if a table exists in the database. 

  virtual BOOL tableExists(const char *tableName);

  // Create a table from the table descriptor(number of fields and the 
  // field descriptor array). 

  virtual Retcode createTable(const char *tableName,
    int numFields, const FieldDesc *desc);

  // Copy one table family to another.

  virtual Retcode copyTable(const char *srcTable, const char *destTable);
    
  // Append records of the source table to the destination table.   

  virtual Retcode appendTable(const char *srcTableName,
    const char *destTableName);

  // Rename a table and its family members.

  virtual Retcode renameTable(const char *oldName, const char *newName);

  // Delete a table and its family.

  virtual Retcode deleteTable(const char *tableName);

  // Encrypt a table based on a supplied password.

  virtual Retcode encryptTable(const char *tableName, const char *password);

  // Decrypt a table using a password.

  virtual Retcode decryptTable(const char *tableName);

  // Empty a table by deleting all its records. 

  virtual Retcode emptyTable(const char *tableName);

  // Upgrade the table from Paradox 3.5 to Paradox 4.0 format. 

  virtual Retcode upgradeTable(const char *tableName);

  // Find out if the table is protected; if it is, return TRUE. 
  // In all other cases, return FALSE.

  virtual BOOL isProtected(const char *tableName);

  // Return the number of fields (columns) in the table. Return
  // zero if not successful. 

  virtual int getFieldCount(const char *tableName);

  // Given a table, return the number of fields and an array of  
  // its field descriptors. The caller is responsible for 
  // deleting the free store memory allocated for the field 
  // descriptors. Descriptors are always allocated in the far
  // heap, even under Windows medium memory model.    

  virtual Retcode getDescVector(char *tableName, 
    int& numFields, FieldDesc *&desc);

  // Given an ordered list of fields in the table, establish a
  // key map as a composite of these fields. 

  virtual Retcode defineCompoundKey (const char *tableName,
    int numFields, const FIELDNUMBER *fldArray, const char *indexName, 
    BOOL caseSen, FIELDNUMBER& outH);                                                      

  // Create a secondary index on the table. If the field handle 
  // passed is greater than 255, it must be a number obtained 
  // from the defineCompoundKey function.

  virtual Retcode createSIndex (const char *tableName,
    FIELDNUMBER fieldH, PXKeyCrtMode keyMode);

  // Create a primary key on the table using the first numFields 
  // fields as the key.

  virtual Retcode createPIndex(const char *tableName, int numFields);

  // Delete an index on the table. indexID must be zero for the 
  // primary key. 

  virtual Retcode dropIndex(const char *tableName, FIELDNUMBER indexID);

  // Return the number of primary key fields for the table; if a primary
  // key does not exist or under all other circumstances, returns zero.

  virtual int getNumPFields(const char *tableName);
    
  // Given the name of a composite secondary index, return information 
  // about it.  

  virtual Retcode getSKeyInfo (const char *indexName,
    char *fldName, int& numFields, BOOL& caseSen, 
    FIELDNUMBER *fldArray, FIELDNUMBER& indexID); 

  // Return information on a single field secondary index.

  virtual Retcode getSKeyInfo (const char *indexName,
    char *fldName, BOOL& caseSen, FIELDNUMBER& indexID);  

  // Acquire a file name lock on the network; File need not 
  // physically exist. 

  virtual Retcode lockNetFile(const char *fileName, PXLockMode lockMode);

  // Release a previously acquired lock on a file.

  virtual Retcode unlockNetFile(const char *fileName, PXLockMode lockMode);

  // Write the changed record buffers associated with this 
  // Engine instance to be written to disk.

  virtual Retcode forceWrite();  
  
  // Return the name of the user causing a locking error. 

  virtual char  *getNetErrUser();

  // Redefine pure virtuals from the BDbObject class. 

  virtual char *nameOf() const; 
  virtual void printOn( ostream& os);

private:
  void     *dbobj;             // Tracks objects of the database. 
};

#endif 

