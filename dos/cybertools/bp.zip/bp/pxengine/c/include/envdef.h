/***********************************************************************
**                            ENVDEF.H
** This file contains structure, type and error definitions used 
** throughout the object layer. 
**
***********************************************************************/
  
#if !defined( ENVDEF_H )
#define ENVDEF_H
#include <string.h>

#ifdef _MSC_VER
  #define _CLASSTYPE
#endif

// Global defines. 

#define MAXNAMELEN      31        // Name limit for tables, fields, etc.)
#define MAXPATHLEN      81        // Length of DOS path.

#ifndef BOOL
typedef int BOOL;
#endif

#ifndef INT16
typedef int INT16;
#endif

#ifndef INT32
typedef long INT32;
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif
  
// Engine type for Paradox -- Local, Network or Windows.  

enum BEngineType {pxLocal=1, pxNet=2, pxWin=3};

// File Share mode for the DOS Paradox Engine (local or network).

// NetShare to share only network files; LocalShare to share lock local 
// and network files; with NoShare, neither local or network files 
// will be shared. 

enum PXDosShare {pxLocalShare=0, pxNetShare, pxNoShare}; 

// Lock mode for the Windows Paradox Engine; With SingleClient,
// no locking. 

enum PXWinShare {pxShared=0, pxSingleClient=1, pxExclusive=2};


// Sort order for the Paradox Engine;  

enum PXSortOrder {pxAscii=1,pxIntl,pxNorDan,pxNorDan4,pxSwedFin}; 

enum PXTabCrtMode {px35Fmt=1,px40Fmt=2};
                                                            
// Table lock mode for the Paradox Engine.

enum PXTblLckMode {px40Lck=0,px35Lck=1};

// Modes for creating a new index on a table.

enum PXKeyCrtMode {pxPrimary=0, pxSecondary, pxIncSecondary};

// Modes for Paradox locks.

enum PXLockMode {pxFL=1, pxWL, pxPWL, pxPFL};

// Modes for Paradox searches.

enum PXSearchMode {pxSearchFirst=0, pxSearchNext=1, pxClosestRecord=2};

// Modes for BLOB open.

enum PXBlobOpenMode {pxBlobRead = 0, pxBlobWrite};

// Values for a cursor's status.  

enum PXCursorStatus {atRecord = 0, atBegin, atEnd, atCrack}; 

// Environment structure for specifying engine's parameters.   

class _CLASSTYPE BEnv { 
public:
  BEngineType    engineType;
  int            bufSize;
  int            maxTables;
  int            maxRecBufs;
  int            maxLocks;
  int            maxFiles;       
  PXSortOrder    sortOrder;
  PXTabCrtMode   tabCrtMode;  
                 
  // Fields relevant for Engine operation in network mode.
         
  PXDosShare     dosShare;
  char           netNamePath[MAXPATHLEN+1];
  char           userName[MAXNAMELEN+1]; 
  PXTblLckMode   tabLckMode;

  // Fields relevant for the Windows Paradox Engine.

  PXWinShare     winShare;
  char           clientName[MAXNAMELEN+1];

  char           reserved[32];       // Reserved for future use.

  BEnv() { memset(this,0,sizeof(BEnv)); }    // initialize to zeros 
  
  };
                  

// Error code returned by most functions.

typedef int Retcode;

typedef unsigned  FIELDNUMBER;            // Field number; 1 .. N   
typedef unsigned  TABLEHANDLE;            // Table handle
typedef int       LOCKHANDLE;             // Lock handle
typedef long      RECORDNUMBER;           // Record number; 1 .. N  
typedef unsigned  RECORDHANDLE;           // Record handle
typedef int       BLOBHANDLE;             // BLOB handle


// Field Description Structure.

enum PXFieldType { fldChar=9, fldShort=5, fldDouble=7,
  fldDate=2, fldBlob=3, fldLong=6};

enum PXFieldSubtype {fldstNone = 0, fldstMoney=21, fldstMemo=22,
     fldstBinary=23,  fldstFmtMemo=24, fldstOleObj=25, fldstGraphic=26};

typedef struct {
  FIELDNUMBER    fldNum;                // Field number (1..n).
  char           fldName[MAXNAMELEN+1]; // Null-terminated field name.
  PXFieldType    fldType;               // Field type.
  PXFieldSubtype fldSubtype;            // Field Subtype.
  int            fldLen;                // Field Length; for BLOBs;
                                        // the header length.
  char           reserved[20];          // For future use.
  } FieldDesc;


// A custom record's field and map definition structure. Used in custom
// record subclasses of BRecord.    

typedef struct 
  { 
  int           useCnt;      // Number of instances using this descriptor.          
  int           fieldCnt;    // Count of fields in the custom record.
  FieldDesc     far *desc;   // Descriptor array for custom record's fields 
  FIELDNUMBER  *tblFldNbr;   // Array maps custom record field numbers 
                             // to table's fields. Elements that don't  
                             // have a corresponding table field must 
                             // be set to 0.                                                                               
  } CRFldMapdef; 


// Default Date structure.
typedef struct  {
  int     year;   
  char    month;  
  char    day;    
} BDate; 

// the _CLASSTYPE macro is Borland C++ specific. It ensures
// proper declaration of the DBF classes for use in a DLL.
// For Microsoft C++, it is #defined to nothing at the top
// of this header file.

class _CLASSTYPE BDbObject;
class _CLASSTYPE BEngine;
class _CLASSTYPE BDatabase;
class _CLASSTYPE BCursor;
class _CLASSTYPE BRecord;

// The following error definitions are copied from PXENGINE.H. They
// are included here so that the Database Framework programmer does 
// not have to include PXENGINE.H. 

#ifndef PXSUCCESS
#define PXSUCCESS 0 

// initialization errors

#define PXERR_NOTINITERR        78   // Engine not initialized
#define PXERR_ALREADYINIT       82   // Engine already initialized
#define PXERR_NOTLOGGEDIN       98   // Could not login on network (to PARADOX.NET)
#define PXERR_NONETINIT        107   // Engine not initialized with PXNetInit
#define PXERR_NETMULTIPLE       15   // multiple PARADOX.NET files
#define PXERR_CANTSHAREPDOXNET 134   // can't lock PARADOX.NET -- is SHARE.EXE loaded?
#define PXERR_WINDOWSREALMODE  135   // can't run Engine in Windows real mode


// hardware related errors

#define PXERR_DRIVENOTREADY     1    // Drive not ready
#define PXERR_DISKWRITEPRO      124  // Disk is write protected
#define PXERR_GENERALFAILURE    126  // General hardware error


// directory reg error codes

#define PXERR_DIRNOTFOUND       2    // Directory not found
#define PXERR_DIRBUSY           10   // Sharing violation
#define PXERR_DIRLOCKED         11   // Sharing violation
#define PXERR_DIRNOACCESS       12   // No access to directory
#define PXERR_DIRNOTPRIVATE     14   // Single user, but directory is shared


// file oriented errors

#define PXERR_FILEBUSY          3    // File is busy
#define PXERR_FILELOCKED        4    // File is locked
#define PXERR_FILENOTFOUND      5    // Could not find file


// table oriented errors

#define PXERR_TABLEBUSY        118   // Table is busy
#define PXERR_TABLELOCKED      119   // Table is locked
#define PXERR_TABLENOTFOUND    120   // Table was not found
#define PXERR_TABLEOPEN         83   // Unable to perform operation on open table
#define PXERR_TABLEINDEXED      94   // Table is indexed
#define PXERR_TABLENOTINDEXED   95   // Table is not indexed
#define PXERR_TABLEEMPTY       105   // Operation on empty table
#define PXERR_TABLEWRITEPRO     22   // Table is write protected
#define PXERR_TABLEPRE40        93   // Feature not available for pre Paradox 4.0 tables

#define PXERR_TABLECORRUPTED     6   // Table is corrupted
#define PXERR_TABLEFULL         128  // Table is full
#define PXERR_TABLESQL          130  // Table is SQL replica
#define PXERR_INSUFRIGHTS       21   // Insufficient password rights
#define PXERR_CANTUPGRADE       92   // Table too old to upgrade, or
                                     // existing table header too small.
#define PXERR_LOCKTIMEOUT       137  // Timed out trying to achieve a lock.


// index oriented errors

#define PXERR_XCORRUPTED        7    // Primary index is corrupted
#define PXERR_XOUTOFDATE        8    // Primary index is out of date
#define PXERR_XSORTVERSION      13   // Sort for index different from table

#define PXERR_SXCORRUPTED       122  // Secondary index is corrupted
#define PXERR_SXOUTOFDATE       96   // Secondary index is out of date
#define PXERR_SXNOTFOUND        121  // Secondary index was not found
#define PXERR_SXOPEN            123  // Not used-here for backwards compatability
#define PXERR_SXCANTUPDATE      136  // Can't update table open on non-maintained secondary

#define PXERR_RECTOOBIG         125  // Record too big for index


// record oriented errors

#define PXERR_RECDELETED        50   // Another user deleted record
#define PXERR_RECLOCKED          9   // Record is locked
#define PXERR_RECNOTFOUND       89   // Record was not found
#define PXERR_KEYVIOL           97   // Key violation

#define PXERR_ENDOFTABLE       101   // End of table
#define PXERR_STARTOFTABLE     102   // Start of table


// errors specific for Windows Engine DLL

#define PXERR_TOOMANYCLIENTS   131
#define PXERR_EXCEEDSCONFIGLIMITS 132
#define PXERR_CANTREMAPFILEHANDLE 133


// resource errors

#define PXERR_OUTOFMEM          40   // Not enough memory to complete operation
#define PXERR_OUTOFDISK         41   // Not enough disk space to complete operation
#define PXERR_OUTOFSTACK        127  // Not enough stack space to complete operation
#define PXERR_OUTOFSWAPBUF      129  // Not enough swap buffer space to complete operation

#define PXERR_OUTOFFILEHANDLES  70   // No more file handles available
#define PXERR_OUTOFTABLEHANDLES 72   // No more table handles available
#define PXERR_OUTOFRECHANDLES  103   // No more record handles available
#define PXERR_OUTOFLOCKHANDLES 111   // Too many locks on table

#define PXERR_NOMORETMPNAMES    86   // No more temporary names available
#define PXERR_TOOMANYPASSW     115   // Too many passwords specified


// invalid parameters to functions

#define PXERR_TYPEMISMATCH      30   // Data type mismatch
#define PXERR_OUTOFRANGE        31   // Argument out of range
#define PXERR_INVPARAMETER      33   // Invalid argument
#define PXERR_INVDATE           73   // Invalid date given

#define PXERR_INVFIELDHANDLE    75   // Invalid field handle
#define PXERR_INVRECHANDLE     104   // Invalid record handle
#define PXERR_INVTABLEHANDLE    76   // Invalid table handle
#define PXERR_INVLOCKHANDLE    110   // Invalid lock handle

#define PXERR_INVDIRNAME       114   // Invalid directory name
#define PXERR_INVFILENAME      108   // Invalid file name
#define PXERR_INVTABLENAME      99   // Invalid table name
#define PXERR_INVFIELDNAME      74   // Invalid field name

#define PXERR_INVLOCKCODE      106   // Invalid lock code
#define PXERR_INVUNLOCK        109   // Invalid unlock
#define PXERR_INVSORTORDER     112   // Invalid sort order table
#define PXERR_INVPASSW         116   // Invalid password
#define PXERR_INVNETTYPE       113   // Invalid net type (PXNetInit)
#define PXERR_BUFTOOSMALL      117   // Buffer too small for result

#define PXERR_STRUCTDIFFER      81   // Table structures are different

#define PXERR_INVENGINESTATE    79   // Previous fatal error; cannot proceed


// Blob error codes

#define PXERR_BLOBMODE           51     // Operation not applicable for Blob's
                                        // open mode.
#define PXERR_BLOBOPEN           52     // Blob already open.
#define PXERR_BLOBINVOFFSET      53     // Invalid offset into Blob.
#define PXERR_BLOBINVSIZE        54     // Invalid size for Blob.
#define PXERR_BLOBMODIFIED       55     // Another user modified Blob.
#define PXERR_BLOBCORRUPT        56     // Blob file corrupted.
#define PXERR_BLOBNOINDEX        57     // Cannot index on a Blob.
#define PXERR_BLOBINVHANDLE      59     // Invalid Blob handle.
#define PXERR_BLOBNOSEARCH       60     // Can't search on a Blob field.


// Locking related error codes

#define PXERR_INUSEBYPDOX35      16     // Directory is in use by Paradox 3.5
                                        // or Paradox Engine 2.0

#endif 

// Database Framework function that returns the error message 
// corresponding to an error number.

char far *pascal far PXOopErrMsg(int errCode);

// Database Framework errors.

#define PXERR_INVENGINETYPE     400
#define PXERR_ENGINEOPEN        401
#define PXERR_ENGINENOTOPEN     402
#define PXERR_DBALREADYOPEN     403
#define PXERR_DBNOTOPEN         404
#define PXERR_CURSORALREADYOPEN 405
#define PXERR_CURSORNOTOPEN     406
#define PXERR_RECALREADYATT     407
#define PXERR_RECNOTATT         408
#define PXERR_INVFIELDTYPE      409   
#define PXERR_INVCURRRECORD     410
#define PXERR_TABLESDIFFER      411
#define PXERR_INVKEYCOUNT       412  
#define PXERR_NOKEYMAP          413 
#define PXERR_NOCLEARNULL       414 
#define PXERR_DATACONV          415 
#define PXERR_BLOBNOTOPEN       416 

// GENERATE Utility Errors 

#define PXERR_INCOMPLETESPEC    501 
#define PXERR_NOSPECFILE        502
#define PXERR_INVOPTION         503
#define PXERR_CANTCREATEFILE    504
#define PXERR_NOLEFTPAREN       505
#define PXERR_NOCOMMAORRP       506 
#define PXERR_INVCHARLEN        507 
#define PXERR_INVTYPEWARN       508 

#endif
