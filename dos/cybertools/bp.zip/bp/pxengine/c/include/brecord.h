/*********************************************************************
**
**                          BRECORD.H                                        
**
** This file defines the interface for the BRecord class. This class 
** encapsulates the notion of a generic table's record. A record
** is created in the context of a cursor; multiple record objects 
** can exist in memory corresponding to one or more records of the 
** cursor table.
**
*********************************************************************/

#ifndef BRECORD_H 
#define BRECORD_H 

#include "envdef.h" 
#include "bdbobjec.h"

class BRecord : public BDbObject {

  friend class BCursor; 

public: 

  Retcode lastError;

  // Constructor for making a generic record object for an open cursor.

  BRecord(BCursor *cursor = 0);      

  // Destructor; will close the record buffer associated with the record.   

  virtual ~BRecord();  

  // Close the record buffer associated with the object and delete the  
  // record's association with its cursor.  

  virtual Retcode detach(); 

  // Establish an association with an open cursor.

  virtual Retcode attach(BCursor *cur); 

  // Clear the record buffer; set fields to "empty" values.

  virtual Retcode clear(); 

  // Return the field number for a given field name.   

  virtual FIELDNUMBER getFieldNumber(const char *fldName); 

  // For a given field number in the record, return the field number in 
  // the table it is derived from. For generic records, both these numbers
  // will be the same. For custom records they can be different.

  virtual FIELDNUMBER getTblFieldNumber(FIELDNUMBER fldnbr) ;

  // Return the count of fields in the record. 

  virtual int getFieldCount(); 

  // Given a field number, return its field descriptor.

  virtual Retcode getFieldDesc(FIELDNUMBER fldnbr, FieldDesc& desc);  

  // Given a field number, return its type, subtype and length. 
  virtual Retcode getFieldDesc(FIELDNUMBER fldnbr, 
    PXFieldType &fldType, PXFieldSubtype &fldSubtype, int &fldLen);

  // Copy the contents of the record one field at a time in an assignment
  // compatible way to another record.

  virtual Retcode copyTo(BRecord *destRec);

  // Copy the contents of srcRec one field at a time in an assignment 
  // compatible way to this record. 

  virtual Retcode copyFrom(BRecord *srcRec); 

  // Obtaining values for a given field in the record, specified by number
  // or name. Data conversion will be applied as is necessary. Void pointer
  // returns value in a format native to the field type in the table.    

  virtual Retcode getField(FIELDNUMBER fldnbr, char *buf, 
    int bufLen, BOOL& fNull); 

  virtual Retcode getField(FIELDNUMBER fldnbr, void *buf, 
    int bufLen, BOOL& fNull); 

  virtual Retcode getField(FIELDNUMBER fldnbr, double& val, BOOL& fNull);

  virtual Retcode getField(FIELDNUMBER fldnbr, INT16& val, BOOL& fNull);

  virtual Retcode getField(FIELDNUMBER fldnbr, INT32& val, BOOL& fNull);

  virtual Retcode getField(FIELDNUMBER fldnbr, BDate& val, BOOL& fNull);

  virtual Retcode getField(char *fldName, char *buf, 
    int bufLen, BOOL& fNull);

  virtual Retcode getField(char *fldName, void *buf, int bufLen, 
    BOOL& fNull);

  virtual Retcode getField(char *fldName, double& val, BOOL& fNull);

  virtual Retcode getField(char *fldName, INT16& val, BOOL& fNull);

  virtual Retcode getField(char *fldName, INT32& val, BOOL& fNull);

  virtual Retcode getField(char *fldName, BDate& val, BOOL& fNull);


  // Put field values in a record, providing the counterpart
  // operations of getField functions. 

  virtual Retcode putField(FIELDNUMBER fldnbr, const char *buf);

  virtual Retcode putField(FIELDNUMBER fldnbr, const void *buf);

  virtual Retcode putField(FIELDNUMBER fldnbr, double val);

  virtual Retcode putField(FIELDNUMBER fldnbr, INT16 val);

  virtual Retcode putField(FIELDNUMBER fldnbr, INT32 val);

  virtual Retcode putField(FIELDNUMBER fldnbr, const BDate& val);

  virtual Retcode putField(char *fldName, const char *buf);

  virtual Retcode putField(char *fldName, const void *buf);

  virtual Retcode putField(char *fldName, double val);

  virtual Retcode putField(char *fldName, INT16 val);

  virtual Retcode putField(char *fldName, INT32 val);

  virtual Retcode putField(char *fldName, const BDate& val);


  // Test if the field specified by number is null.

  virtual BOOL isNull(FIELDNUMBER fldnbr);

  // Test if the field specified by name is null.

  virtual BOOL isNull(const char *fldname);

  // Set the field specified by number to null.

  virtual Retcode setNull(FIELDNUMBER fldnbr); 

  // Set the field specified by name to null.

  virtual Retcode setNull(const char *fldName); 

  // Clear the field's null flag; used in custom records only.

  virtual Retcode clearNull(FIELDNUMBER fldnbr); 

  // Clear the field's null flag; used in custom records only.

  virtual Retcode clearNull(const char *fldName); 

  // Open a Blob field for subsequent read operations. 

  virtual Retcode openBlobRead(FIELDNUMBER fldnbr, 
    BOOL usePrivateCopy = FALSE);

  // Open a Blob field for subsequent write operations. Retain the first   
  // size bytes of the current BLOB. 

  virtual Retcode openBlobWrite(FIELDNUMBER fldnbr, 
    long size, BOOL copyOld); 

  // Get the header of the BLOB field. 

  virtual Retcode getBlobHeader(FIELDNUMBER fldnbr, int size, 
    void *buffer, int& bytesRead);

  // Get the size of an open BLOB. 

  virtual long getBlobSize(FIELDNUMBER fldnbr); 

  // Read a segment of an open BLOB.

  virtual Retcode getBlob(FIELDNUMBER fldnbr, unsigned int size, 
    long offset, void far *buffer);

  // Close an open BLOB.

  virtual Retcode closeBlob(FIELDNUMBER fldnbr, BOOL accept = TRUE);

  // Write a segment into an open BLOB.

  virtual Retcode putBlob(FIELDNUMBER fldnbr, unsigned int size, 
    long offset, void far *buffer);

  // Drop a Blob field from a Record.

  virtual Retcode dropBlob(FIELDNUMBER fldnbr);

  // Place holder for user-defined preprocessing routine in a 
  // custom record. Insert, update, and append routines will 
  // call this routine before calling the Paradox Engine. 

  virtual Retcode preprocess(); 

  // Place holder for user-defined postprocessing routine in 
  // a custom record and called by getCurrent function after 
  // fetching a record from a Paradox table. 

  virtual Retcode postprocess();

  // Redefine pure virtuals from the BDbObject class. 

  virtual char *nameOf() const; 
  virtual void printOn( ostream& os);

protected:
  BCursor     *curH;                 // Cursor for this record.
  RECORDHANDLE recH;                 // Paradox record handle.

private:
  void        *recobj;          // Variable used to keep track of
                                // a record's objects.
};

#endif

