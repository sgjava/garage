/*********************************************************************
**
**                          BENGINE.H
**
** This file defines the interface of the BEngine class. 
** This class contains methods for connecting to the Paradox
** engine and performing engine-level operations.
**
*********************************************************************/

#ifndef BENGINE_H
#define BENGINE_H

#include "envdef.h"
#include "bdbobjec.h"

class BEngine : public BDbObject {

  friend class BDatabase;
  friend class BCursor;

public:
  Retcode     lastError;
  BOOL        isOpen;
  BEngineType engineType;

  // This constructor makes a C++ BEngine object without actually opening
  // the Paradox engine. 
  BEngine();


  // This constructor makes a C++ BEngine object and actually opens the
  // Paradox engine in the requested mode using default parameters.  
  BEngine(BEngineType eType);


  // This constructor makes a C++ BEngine object and actually opens the
  // Paradox engine in the requested mode using suppiled parameters.  
  BEngine(const BEnv& env);


  // Destructor; Closes the engine if it's open.
  virtual ~BEngine();


   // Sets the engine type and various other parameters. 
  virtual Retcode setDefaults(const BEnv& env);


  // Open the Paradox Engine based on a previously set  environment.
  virtual Retcode open();


  // Close the currently open engine. 
  virtual Retcode close();


  // Get the current values of all engine configuration parameters.
  virtual void getDefaults(BEnv& env) const;


  // Enable or Disable the internal harware error handler.
  virtual Retcode setHWHandler(BOOL ehEnable);


  // Add a password to the engine's password list. 
  virtual Retcode addPassword(char *password);


  // Set the maximum size of for tables created with this engine.
  virtual Retcode setMaxTblSize(int maxSize);


  // Set the table create mode for the engine (3.5 or 4.0 file format).
  virtual Retcode setTblCreateMode(PXTabCrtMode crtMode);


  // Delete a previously entered password.
  virtual Retcode deletePassword(char *password);


  // Find the name of the current user in the shared environment. 
  virtual char *getUsername();


  // Get the error message corresponding to a error number.
  virtual char far *getErrorMessage(int errnbr);

  // pure virtuals from the BDbObject class.
  virtual char *nameOf() const;
  virtual void printOn( ostream& os);

private:
  void  *engobj;	        // variable used to keep track of
				// engine's objects.
};

#endif

