/****************************************************************************
*                                                                           
* FILE: FAVREST.CPP
*
* DESCRIPTION:  This file contains the member functions for the class
*               FavoriteRestaurant used in the sample program for the   
*               C++ Database Framework.
*               
*
****************************************************************************/

#ifdef _MSC_VER
#include <memory.h>
#else
#include <mem.h>
#endif
#include <string.h>
#include "demo.h"

/****************************************************************************
*          
* CLASS:  FavoriteRestaurant
*                                                                
* MEMBER FUNCTION: FavoriteRestaurant (constructor)
*
* DESCRIPTION:  This function creates an instance of the FavoriteRestaurant
*               class.
*               
* RETURNS: NONE
*
****************************************************************************/

// the code for the constructor is inline and may be found in DEMO.H

/****************************************************************************
*          
* CLASS:  FavoriteRestaurant
*                                                                
* MEMBER FUNCTION: getRecord
*
* DESCRIPTION:  This function gets the current record from the database
*               and assigns the field values to the data members in the
*               class.
* 
*    NOTE:
*
*    Since BLOB fields are not stored in the table's .DB file, getting the
*    record does not get the BLOB field's contents. Two functions are needed
*    to get a record and a BLOB field. First, one must get the record and
*    then the BLOB fields must be retrieved. Between the call to getRecord()
*    and openBlobRead() the BLOBs record could be deleted, or the BLOB could
*    be changed. If this happens, openBlobRead() will return 
*    PXERR_BLOBMODIFIED.  To prevent updates to BLOBs while the record is
*    being read, you can lock the record prior to calling getRecord() 
*    and release the lock after getting the BLOB fields.  
*
*    RETURNS: PXERR_, if one occurs.
*
****************************************************************************/
Retcode FavoriteRestaurant::getRecord()
{
  BRecord     *currentRecord;
  LOCKHANDLE  recordLockHandle;
  BOOL        isBlank;      

  //
  // See if the table was opened.
  //
  if(!isOpen)
  {
     return(lastError = ERROR_TABLENOTOPEN);
  }
  //
  // If the application is running in a multiuser environment, check to 
  // see if another user has changed the table.
  //
  if(cursorPtr->hasChanged() == TRUE)
  {
    //
    // Refresh the table's buffers.
    //
    cursorPtr->refresh();
  }
  //
  // Reduce the amount of pointer dereference.
  //
  currentRecord = cursorPtr->genericRec;
  //
  // Close any BLOB fields that might be open in this table.
  //
  currentRecord->closeBlob(FAV_MENU_FIELD, FALSE);  
  // 
  // Lock the record.
  //
  recordLockHandle = cursorPtr->lockRecord();

  //
  // Check if the record is locked and the network is initialized. 
  //
  if((cursorPtr->lastError != PXSUCCESS) &&
    (cursorPtr->lastError != PXERR_NONETINIT))
  {
    //
    // Return any errors that occurred. 
    //
    return(lastError = cursorPtr->lastError);
  }

  lastError = AbstractRestaurant::getRecord();
  //
  // Check if successful. 
  //
  if (lastError == PXSUCCESS)
  {
    //
    // Use the BCursor gereric record to extract fields from the record.
    //
    currentRecord->getField(FAV_NAME_FIELD, name, MAX_NAME_LEN + 1, isBlank); 
    currentRecord->getField(FAV_TYPE_FIELD, type, MAX_TYPE_LEN + 1, isBlank); 

    //
    // Create PRIVATE BLOBs for the memo field.  This will prevent
    // other users from changing the BLOB or deleting the 
    // record with which the BLOB is associated.
    //
    currentRecord->openBlobRead(FAV_MENU_FIELD, TRUE);

  }
  //
  // Unlock the record.
  //
  cursorPtr->unlockRecord(recordLockHandle);

  return(lastError);
}

/****************************************************************************
*          
* CLASS:  FavoriteRestaurant
*                                                                
* MEMBER FUNCTION: getMenu
*
* DESCRIPTION:  This function retrieves the menu field from the table.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode FavoriteRestaurant::getMenu(char *buffer, unsigned int sizeOfBuffer, 
  long offset, unsigned int &bytesRead) 
{
  //
  // Specify a particular field and use the generic getBlobField function.
  //
  lastError = getBlobField(FAV_MENU_FIELD, buffer, sizeOfBuffer, offset,
    bytesRead);

  return(lastError);
}

/****************************************************************************
*          
* CLASS: FavoriteRestaurant
*                                                                
* MEMBER FUNCTION: sizeOfMenuBlob
*
* DESCRIPTION: This function returns the size of the Menu memo field.
*               
* RETURNS: Number of bytes in the Menu memo field.
*
****************************************************************************/

long FavoriteRestaurant::sizeOfMenuBlob()
{
  //
  // Return the BLOB size. Error checking is done in base function.
  //
  return(getBlobSize(FAV_MENU_FIELD));

}

