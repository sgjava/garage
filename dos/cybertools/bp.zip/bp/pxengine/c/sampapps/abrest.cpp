/***************************************************************************
*                                                                           
* FILE: ABREST.CPP
*
* DESCRIPTION:  This file contains the member functions for the class
*               AbstractRestaurant used in the sample program for the   
*               C++ Database Framework.
*               
*
****************************************************************************/

#include <string.h>
#include "demo.h"

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: AbstractRestaurant (constructor)
*
* DESCRIPTION:  This is the constructor for the Abstract restaurant class.
*               It creates a class of this type and associates it with
*               a database.  
*               
* RETURNS: NONE              
*
****************************************************************************/

AbstractRestaurant::AbstractRestaurant(BDatabase *db)
{
  //
  // Create a cursor for the table to be opened later. 
  //
  cursorPtr = new BCursor();
  //
  //
  // Set all the data members to their initial condition.
  //
  isOpen = FALSE;
  lastError = PXSUCCESS;
  //
  //
  // Set a pointer to the database object.
  //
  dataBase = db;
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: ~AbstractRestaurant (destructor)
*
* DESCRIPTION:  This is the destructor for the Abstract restaurant class.
*               It will properly close a class of this type.
*               
* RETURNS: NONE              
*
****************************************************************************/

AbstractRestaurant::~AbstractRestaurant()
{
  //
  // Determine if the database was ever opened.
  //
  if(isOpen == TRUE)
  {
    //
    // Call the close() member function to free up any memory storage
    // and resources the class instance is using.
    //
    close();
  }
  //
  // Delete the BCursor object in the class.
  //
  delete cursorPtr;
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: up
*
* DESCRIPTION: This function moves to the previous record in the database. 
*              This is similiar to the C Engine PXRecPrev() function call.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::up()
{
  //
  // Check to see that the database has been opened before moving to  
  // a different record. 
  //
  if(isOpen != TRUE)
  {
    //
    // It was not open, so return one of the special restaurant errors.
    //
    lastError = ERROR_TABLENOTOPEN;
  }
  else
  {
    //
    // Call the gotoPrev member function of the open cursor for the database
    // and save its error condition.
    //
    lastError = cursorPtr->gotoPrev();
  }
  //
  // Return any error.
  //
  return(lastError);
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: down
*
* DESCRIPTION: This function moves to the next record in the database. 
*              This is similiar to C Engine PXRecNext() function. 
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::down()
{
  //
  // Check to see that the database has been opened before moving to 
  // another record. 
  //
  if(isOpen != TRUE)
  {
    //
    // It was not open, so return one of the special restaurant errors.
    //
    lastError = ERROR_TABLENOTOPEN;
  }
  else
  {
    //
    // Call the gotoNext member function of the open cursor for the database
    // and save its error condition.
    //
    lastError = cursorPtr->gotoNext();
  }
  //
  // Return any error.
  //
  return(lastError);
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: home
*
* DESCRIPTION: This function moves to the first record in the database. This
*              is similiar to C Engine PXRecFirst() function. 
*
* NOTE: The Database Framework does not have a function that moves to the
*       first record in the table. This function must use the BCursor
*       functions gotoBegin() and gotoNext() to move the record pointer to 
*       the first record in the database.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::home()
{
  //
  // Check to see that the database has been opened before moving to 
  // another record. 
  //
  if(isOpen != TRUE)
  {
    //
    // It was not open, so return one of the special restaurant errors.
    //
    lastError = ERROR_TABLENOTOPEN;
  }
  else
  {
    //
    // Call the gotoBegin member function to move the current record pointer
    // to a position in front of the first record.
    //
    lastError = cursorPtr->gotoBegin();
    //
    // Check if an error occurred.
    //
    if(lastError == PXSUCCESS)
    {
      //
      // Move to the first record in the table.
      //
      lastError = cursorPtr->gotoNext();
    }
  }
  //
  // Return any error that occurred.
  //
  return(lastError);
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: end
*
* DESCRIPTION: This function moves to the last record in the database. This
*              is similiar to C Engine PXRecLast() function. 
*               
* NOTE: The Database Framework does not have a function that moves to the
*       last record in the table. This function must use the BCursor 
*       functions gotoEnd() and gotoPrev() to move the record pointer to
*       the last record in the database.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::end()
{
  //
  // Check to see that the database has been opened before moving to 
  // another record. 
  //
  if(isOpen != TRUE)
  {
    //
    // It was not open, so return one of the special restaurant errors.
    //
    lastError = ERROR_TABLENOTOPEN;
  }
  else
  {
    //
    // Call the gotoEnd member function of the open cursor for the database
    // and save its error condition.
    //
    lastError = cursorPtr->gotoEnd();
    //
    // Check if an error occurred. 
    //
    if(lastError == PXSUCCESS)
    {
      //
      // Moving to the previous record places the record pointer at the
      // first record in the table.
      //
      lastError = cursorPtr->gotoPrev();
    }
  }
  //
  // Return any error.
  //
  return(lastError);
}

/****************************************************************************
*          
* CLASS:  AbstractRestaurant
*                                                                
* MEMBER FUNCTION: open
*
* DESCRIPTION:  This function opens a given table name and assigns it
*               to the BCursor data member in the class.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::open(char *tableName)
{
  //
  // Check to see if the table is already open.
  //
  if (isOpen == TRUE)
  {
    return(lastError = PXERR_TABLEOPEN);
  }
  //
  // Try to open the table.
  //
  lastError = cursorPtr->open(dataBase, tableName, 0, 0);
  //
  // Check if the table was successfully opened.
  //
  if (lastError == PXSUCCESS) 
  {
    //
    // Table successfully opened.
    //
    isOpen = TRUE;
  }

  return(lastError);
}

/****************************************************************************
*          
* CLASS:  AbstractRestaurant
*                                                                
* MEMBER FUNCTION:  close
*
* DESCRIPTION:  This function closes an open restaurant table.
*               
* RETURNS:  PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::close()
{
  //
  // Check to see if the table has been opened.
  //
  if (!isOpen) 
  {
     return(lastError = ERROR_TABLENOTOPEN);
  }
  //
  // Flush and close the table.
  //
  lastError = cursorPtr->close();
  if(lastError == PXSUCCESS)
  {
     isOpen = FALSE;
  }
  return(lastError);
}

/****************************************************************************
*          
* CLASS:  AbstractRestaurant
*                                                                
* MEMBER FUNCTION: getRecord
*
* DESCRIPTION:  This function retrieves the current record from a table
*               and places it in the generic record associated with
*               th BCursor object.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::getRecord()
{
  //
  // Retrieve a record using the member function getRecord() in
  // the BCursor class.
  //
  lastError = cursorPtr->getRecord();
  return(lastError);
}

/****************************************************************************
*          
* CLASS:  AbstractRestaurant
*                                                                
* MEMBER FUNCTION: getBlobField
*
* DESCRIPTION:  This function retrieves part of the contents of a memo
*               field and places it in buffer. sizeOfBuffer is the size
*               of this buffer in bytes, including the NULL terminator.
*               The function will read up to sizeOfBuffer - 1 bytes from
*               the BLOB field.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::getBlobField(FIELDNUMBER blobField, char *buffer, 
  unsigned int sizeOfBuffer, long offset, unsigned int &bytesRead)
{
  BRecord *curRecord;
  //
  // To be safe, set the buffer to ensure it is NULL terminated.
  // When dealing with memo fields, the buffer is filled with the length 
  // requested, without regard for a NULL terminator.
  //  
  //
  memset(buffer, 0, sizeOfBuffer);

  //
  // Determine if the table was opened.
  //
  if(!isOpen)
  {
     return(lastError = ERROR_TABLENOTOPEN);
  }
  //
  // Used to reduce pointer dereference.
  //
  curRecord = cursorPtr->genericRec;

  //
  // Set the length to read from the memo field. 
  //
  lastError = fixReadLength(blobField, sizeOfBuffer, offset, bytesRead);

  if(lastError == PXSUCCESS)
  {
    //
    // Get string, but leave room for the null terminator <bytesRead>.
    //
    lastError = curRecord->getBlob(blobField, bytesRead, offset, buffer);
  }
  return(lastError);
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: getQuickBlob
*
* DESCRIPTION: This function retrieves a header from a BLOB field. 
*               
* RETURNS: PXERR_, if one occurs. 
*
****************************************************************************/

Retcode AbstractRestaurant::getQuickBlob(FIELDNUMBER blobField, char *buffer, 
  int length, int &bytesRead)
{
  BRecord *curRecord;
  //
  // To be safe, set the buffer to ensure it is NULL-terminated.
  // When dealing with memo fields, the buffer is filled with the length 
  // requested, without regard for a NULL terminator.
  //  
  memset(buffer, 0, length);
  //
  // Determine if the table was opened.
  //
  if(!isOpen)
  {
     return(lastError = ERROR_TABLENOTOPEN);
  }
  //
  // Reduce pointer dereference. 
  //
  curRecord = cursorPtr->genericRec;

  //
  // Call the Paradox Engine to get the header of the memo field.
  //
  lastError = curRecord->getBlobHeader(blobField, length, buffer, bytesRead);

  return(lastError);
}

/****************************************************************************
*          
* CLASS:  AbstractRestaurant
*                                                                
* MEMBER FUNCTION: fixReadLength
*
* DESCRIPTION:  This function adjusts the length of the read request
*               of a BLOB field if the current position is less than 
*               sizeOfBuffer bytes from the end of the memo field.
*               
* RETURNS: PXERR_, if one occurs.
*
****************************************************************************/

Retcode AbstractRestaurant::fixReadLength(FIELDNUMBER blobField, 
  unsigned int sizeOfBuffer, long offset, unsigned int &readLength)
{
  BRecord *curRecord;
  long lengthOfBlob;

  //
  // Reduce pointer dereference.
  //
  curRecord = cursorPtr->genericRec;

  //
  // Get the length of the memo field.
  //
  lengthOfBlob = curRecord->getBlobSize(blobField);

  //
  // Determine if current length will read past the end of the BLOB data.
  //
  if(offset > lengthOfBlob)
  { 
    //
    // Sufficient BLOB data remains. 
    //
    readLength = 0L;
    return(PXERR_BLOBINVOFFSET);
  }
  //
  // Determine if read will occur past the end of the BLOB data.
  //
  if((offset + sizeOfBuffer - 1) > lengthOfBlob)
  {
    //
    // Adjust the amount of data to read.
    //
    readLength = (unsigned int)(lengthOfBlob - offset);
  }
  else
  {
    //
    // Read is not attempting to read past the length of the BLOB data.
    //
    readLength = sizeOfBuffer - 1;
  }
  return(PXSUCCESS);
}

/****************************************************************************
*          
* CLASS: AbstractRestaurant
*                                                                
* MEMBER FUNCTION: getBlobSize
*
* DESCRIPTION: This function returns the size of the memo BLOB field. 
*               
* RETURNS: Number of bytes in the memo field.
*
****************************************************************************/

long AbstractRestaurant::getBlobSize(FIELDNUMBER blobField)
{    
  BRecord *curRecord;
  long lengthOfBlob;

  lengthOfBlob = 0;
  //
  // Determine if the table was opened.
  //
  if(!isOpen)
  {
     lastError = ERROR_TABLENOTOPEN;
     return(lengthOfBlob);
  }
  //
  // Reduce pointer dereference. 
  //
  curRecord = cursorPtr->genericRec;
  //
  // Call member function getBlobSize of class BRecord.
  //
  lengthOfBlob = curRecord->getBlobSize(blobField);
  //
  // Get the error code from the cursor.
  //
  lastError = curRecord->lastError;

  return(lengthOfBlob);

}




