/*  Copyright (c) 1990, 1992 by Borland International, Inc.  */

#include <stdio.h>
#include <pxengine.h>
#include <string.h>
#define SEARCHMAIN
#define CASESENSITIVE 1
#define NETDIR ""
#define NETTYPE NOTONNET

/* prototypes for functions */

int pxPartialSearch(TABLEHANDLE tblHandle, char *SearchString,
      FIELDHANDLE fldHandle, int mode, int Case);

#ifdef SEARCHMAIN
int AddRecords(char *TblName);
void main(void);
#endif

/*
**  Function:       pxPartialSearch
**
**  Parameters: tblHandle        Table to search.
**              SearchString     String to locate.
**              fldHandle        Field to search.
**              mode             SEARCHFIRST or SEARCHNEXT.
**              case             CASESENSITIVE or !CASESENSITIVE.
**
**   Returns: PXSUCCESS          If record found.
**            PXERR_RECNOTFOUND  If record not found.
**
*/
int pxPartialSearch(TABLEHANDLE tblHandle,char *SearchString, 
  FIELDHANDLE fldHandle,int mode,int Case) 
{ 
  int pxErr; 
  char buf[BUFSIZ]; 
  char buf2[BUFSIZ]; 
  RECORDHANDLE recHandle; 
  LOCKHANDLE lckHandle; 
  int found = 0;

  /* Make a copy of the search string, switch to uppercase if 
     case-insensitive search. */

  strcpy(buf,SearchString);
  if (Case != CASESENSITIVE)
    strupr(buf);

  /* Lock the table so no changes can occur during the search. */

  if ((pxErr = PXNetTblLock(tblHandle,WL)) != PXSUCCESS)
    return(pxErr);

  /* Save current record in case string not found. */

  if ((pxErr = PXNetRecLock(tblHandle,&lckHandle)) == PXSUCCESS)
  {
    if (mode == SEARCHFIRST)
      pxErr = PXRecFirst(tblHandle);
    else
      pxErr = PXRecNext(tblHandle);
  }

  if (pxErr == PXSUCCESS)
    if ((pxErr = PXRecBufOpen(tblHandle,&recHandle)) == PXSUCCESS)
      do
      {
        if ((pxErr =PXRecGet(tblHandle,recHandle)) == PXSUCCESS)
          if ((pxErr = PXGetAlpha(recHandle,fldHandle,BUFSIZ,buf2)) 
            == PXSUCCESS)
          {
            if (Case != CASESENSITIVE)
              strupr(buf2);

            if (strstr(buf2,buf))
              found = 1;
            else
              pxErr = PXRecNext(tblHandle);
          }
      }
      while (!found && pxErr == PXSUCCESS);

      if (!found)  /* Move to original position. */
        PXNetRecGotoLock(tblHandle,lckHandle);

      PXNetRecUnlock(tblHandle,lckHandle);
      PXNetTblUnlock(tblHandle,WL);

      if (found)
        return(PXSUCCESS);
      else
        return(pxErr == PXERR_ENDOFTABLE ? PXERR_RECNOTFOUND : pxErr);
}


#ifdef SEARCHMAIN
char *Data[] = {"Paradox","Engine","leveraging","the", 
  "Power","of","Paradox!"}; 

#define NUMBEROFELEMENTS sizeof(Data)/sizeof(char*)

/*
**  Function: AddRecords
**
**  Parameters:  TblName    Name of table to append records to.
**
**  Return Value:  PXSUCCESS            If successful.
**                Appropriate PXERR_... If unsuccessful.
*/
int AddRecords(char *TblName)
{
  TABLEHANDLE tblHandle;
  RECORDHANDLE recHandle;
  int pxErr;
  int i;

  if ((pxErr = PXTblOpen(TblName,&tblHandle,0,0)) == PXSUCCESS)
    if ((pxErr = PXRecBufOpen(tblHandle,&recHandle)) == PXSUCCESS)
      for (i=0;i<NUMBEROFELEMENTS && pxErr == PXSUCCESS;++i)
        if ((pxErr = PXPutAlpha(recHandle,1,Data[i])) == PXSUCCESS)
          pxErr = PXRecAppend(tblHandle,recHandle);

  if (pxErr == PXSUCCESS)
    if ((pxErr = PXRecBufClose(recHandle)) == PXSUCCESS)
      pxErr = PXTblClose(tblHandle);
  return(pxErr);
}

char *fields[] = {"Field 1","Field 2"};
char *types[] = {"A20","A20"};
#define TblSize sizeof(fields)/sizeof(char *)
FIELDHANDLE f[] = {1};

/*
**  Function:    MakeTable
**
**  Parameters: TblName    Name of table to create.
**
**  Return Value: PXSUCCESS              If successful.
**                Appropriate PXERR_...  if unsuccessful.
*/
int MakeTable(char *TblName)
{
  int pxErr;

  if ((pxErr = PXTblCreate(TblName,TblSize,fields,types)) == PXSUCCESS)
    if ((pxErr = PXKeyAdd(TblName,1,f,PRIMARY)) == PXSUCCESS)
      pxErr = AddRecords(TblName);

  return(pxErr);
}
void main(void)
{
  TABLEHANDLE tblHandle;
  RECORDHANDLE recHandle;
  char buf[BUFSIZ];
  int pxErr;

  if ( (pxErr = PXNetInit(NETDIR,NETTYPE,DEFUSERNAME)) == PXSUCCESS)
    if ( (pxErr = MakeTable("TABLE")) == PXSUCCESS)
      if ((pxErr = PXTblOpen("TABLE",&tblHandle,0,0)) == PXSUCCESS)
        pxErr = PXRecBufOpen(tblHandle,&recHandle);
  if (pxErr)
  {
    printf("Error: %s\n",PXErrMsg(pxErr));
    return;
  }

  if ((pxErr = pxPartialSearch(tblHandle,"aging",1,SEARCHFIRST, 
    CASESENSITIVE)) == PXSUCCESS)
  {
    PXRecGet(tblHandle,recHandle);
    PXGetAlpha(recHandle,1,BUFSIZ,buf);
    printf("Found [%s]\n",buf);
  }
  else
    printf("SEARCH: %s\n",PXErrMsg(pxErr));
}
#endif

