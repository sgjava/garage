/****************************************************************************
*                                                                           
* FILE: DEMO.H
*
* DESCRIPTION:  This file contains the class definitions for the Restaurant
*               sample program.  
*
*  NOTES:    The sample program provides basic functions that are
*            relevant to most applications. The program provides 
*            functions for searching, retrieving and copying data. It 
*            also provides basic database operations such as opening,   
*            and closing database tables, and using cursors.
* 
*            The Restaurant application uses a single database 
*            consisting of two tables. The first table, EATS, contains 
*            data on individual restaurants; name, address, how they 
*            are rated, a review, and a menu for each restaurant. The 
*            EATS table acts as a glossary for all restaurants. The
*            second table, FAVEATS, provides a list of favorite 
*            restaurants that have been copied from the EATS table and 
*            used as a reference for those restaurants that the user
*            has patronized. 
*
*            The database is initialized by user-defined types provided
*            by C++ classes. A list of these types are BEngine, BDatabase,
*            Main Restaurant, and FavoriteRestaurant. Each table in the 
*            database is opened and closed by member functions provided 
*            by the MainRestaurant and FavoriteRestaurant instances. These
*            two types of instances are the two objects in the application
*            corresponding to the two tables in the database. The user 
*            manipulates the tables in the database through member
*            functions (for example, open and close) provided by each 
*            object.
*
*            Movement between records in the tables are provide by
*            member functions Home, End, Up and Down. The cursor acts as
*            a pointer to records in each table. Through the cursor, a
*            user can access data in a particular record. Home sets 
*            the cursor to the first record in the table and End sets 
*            the cursor to the last record in the table. Up sets the
*            cursor to the previous record and Down sets the cursor to
*            the next record in the table.
*
*            Access of data in a record is provided by member functions
*            getRecord, getQuickReview, getReview, and getMenu. Except
*            for getRecord, the other data access functions deal with
*            with retrieving data from BLOB fields. getRecord accesses
*            the current record and retrieve all field values except 
*            BLOBs, and assign variables within the object for the
*            field values retrieved. The user can then reference 
*            these variables. getQuickReview, getReview, and getMenu 
*            retrieve the current records individual BLOB fields. 
*            The EATS table contains two BLOB fields , Review and
*            Menu. The FAVEATS tables contains one BLOB field named
*            Menu. sizeOfMenuBlob and sizeOfReviewBlob are additional 
*            functions provide for accessing these BLOB fields. 
*
*            Two member functions provide searching methods for the
*            EATS table.  findRatingType and findCityType define
*            two searches to locate a restaurant, the first searching 
*            restaurants by rating and type. The second function searches 
*            based on city and type. Each search function can declare its
*            search method to search for the first occurrence of specified
*            field values or search for the next occurrence after a
*            successful search has occurred.
*
*            To copy all relevant data from the EATS table to the
*            FAVREST table, a user can call the copyToFavorite member
*            function. This function provides all record locking, handles
*            concurrency issues and access to both tables to perform a 
*            copy of the current record from the EATS table to the 
*            FAVREST table.
*
*
****************************************************************************/
//
// include files
//
#include <bengine.h>
#include <bdatabas.h>
#include <bcursor.h>
#include <brecord.h>

#ifdef _MSC_VER
#include <memory.h>
#else
#include <mem.h>
#endif

//
// Defines for field lengths.
//
#define MAX_NAME_LEN      50
#define MAX_TYPE_LEN      15
#define MAX_STREET_LEN    50
#define MAX_CITY_LEN      50
#define MAX_STATE_LEN     20
#define MAX_ZIP_LEN       10
#define MAX_TELEPHONE_LEN 14

//
// Define a buffer size to copy BLOBs.
//
#define BLOB_COPY_LEN 255

//
// Defines for field handles to the main table.
//
#define MAIN_NAME_FIELD       1
#define MAIN_STREET_FIELD     2
#define MAIN_CITY_FIELD       3
#define MAIN_STATE_FIELD      4
#define MAIN_ZIP_FIELD        5
#define MAIN_TELEPHONE_FIELD  6
#define MAIN_TYPE_FIELD       7
#define MAIN_RATING_FIELD     8
#define MAIN_REVIEW_FIELD     9
#define MAIN_MENU_FIELD       10

//
// Defines for field handles to the Favorite table.
//
#define FAV_NAME_FIELD    1
#define FAV_TYPE_FIELD    2
#define FAV_MENU_FIELD    3

//
// Quick review data size.
//
#define MAX_REVIEW_SIZE 80

//
// Some special errors returned by the restaurant classes.
//
#define ERROR_TABLENOTOPEN   -1

//
// Define the name of the composite indexes for the main table.
//
#define RATING_TYPE_INDEX "rating/type"
#define CITY_TYPE_INDEX   "city/type"

//
// Define the number of fields in the secondary indexes.
//
#define RATING_TYPE_FLDCOUNT  2
#define CITY_TYPE_FLDCOUNT    2


/****************************************************************************
*
* This is the base class for the different restaurant tables that will be
* used in the program.
*
****************************************************************************/

class AbstractRestaurant {

protected:

  //
  // Flag to identify if the table is open.
  // 
  int isOpen;
  //
  // Pointer to the table's BCursor class instance.
  //
  BCursor *cursorPtr;

  //
  // Pointer to the active database.
  //
  BDatabase *dataBase;

  //
  // Fix the length to read from the memo field (so user does not pass EOF).
  //
  virtual Retcode fixReadLength(FIELDNUMBER blobField, 
    unsigned int sizeOfBuffer, long offset, unsigned int& readLength);

  //
  // Get the BLOB field but also null terminate the string
  // and adjust the size so the user will not read past the EOF.
  //
  virtual Retcode getBlobField(FIELDNUMBER blobField,char *buffer,
    unsigned int sizeOfBuffer, long offset, unsigned int &bytesRead); 

  //
  // Get only the BLOB header.
  //
  virtual Retcode getQuickBlob(FIELDNUMBER blobField, char *buffer, 
    int length, int &bytesRead);
  //
  // Find the length of a BLOB field.
  //
  virtual long getBlobSize(FIELDNUMBER blobField);

public:
  //
  // Last error that member functions returned.
  //
  Retcode lastError;

  //
  // Constructor and destructor.
  //
  AbstractRestaurant(BDatabase *db);
  virtual ~AbstractRestaurant();

  //
  // Opens the table and allocates cursorPtr if successful.
  //
  virtual Retcode open(char *tableName);
  virtual Retcode close();

  //
  // Some basic browse functions.
  //
  virtual Retcode up();
  virtual Retcode down();
  virtual Retcode home();
  virtual Retcode end();

  //
  // Retrieves parts of the MEMO field menu.
  //
  virtual Retcode getMenu(char *buffer, unsigned length, long offset, 
    unsigned int &bytesRead) = 0;
  //
  // Get the size of the BLOB fields.
  //
  virtual long sizeOfMenuBlob() = 0;
  //
  // This function retrieves the current record from the database and 
  // assigns the field values to BCursor's generic record buffer.
  //
  virtual Retcode getRecord();

};

/****************************************************************************
*
* This class encapsulates the master restaurant database.
*
****************************************************************************/

class MainRestaurant : public AbstractRestaurant {

  friend class FavoriteRestaurant;

  //
  // Since the Database Framework does not provide a function like 
  // PXSrchFld(), you must open up secondary indexes for the particular 
  // fields you want to search. Use the member function setToCursor() to 
  // sync the match found in a secondary index with the primary index view. 

private:

  BCursor *ratingTypeIndex;
  BCursor *cityTypeIndex;

public:

  //
  // Specific variables used to store column values for this table.
  //
  char  name[MAX_NAME_LEN + 1];
  char  type[MAX_TYPE_LEN + 1];
  char  street[MAX_STREET_LEN + 1];
  char  city[MAX_CITY_LEN + 1];
  char  state[MAX_STATE_LEN + 1];
  char  zip[MAX_ZIP_LEN + 1];
  char  telephone[MAX_TELEPHONE_LEN + 1];
  INT16 rating;

  //
  // Constructor.
  //
  MainRestaurant(BDatabase *db);
  //
  // Destructor.
  //
  virtual ~MainRestaurant();
  //
  // Redefine the open and close functions for this class.
  //
  virtual Retcode open(char *tableName);
  virtual Retcode close();

  //
  // BLOB retrieval functions.
  //
  Retcode getQuickReview(char *buffer, int sizeOfBuffer, 
    int &bytesRead);

  Retcode getReview(char *buffer, unsigned int length, long offset, 
    unsigned int &bytesRead);

  virtual Retcode getMenu(char *buffer, unsigned int length, long offset, 
    unsigned int &bytesRead);
  //
  // BLOB size functions.
  //
  long sizeOfReviewBlob();
  virtual long sizeOfMenuBlob();
  //
  // This function copies the current record in the main database to the
  // favorite restuarant database.
  //
  Retcode copyToFavorite(FavoriteRestaurant &placeHere);

  //
  // This function locates a restaurant by rating and type using a composite
  // index.
  //
  Retcode findRatingType(int ratingToFind, char *typeToFind, 
    PXSearchMode searchMode);
  //
  // This function uses a composite index to locate a restaurant by city 
  // and type.
  //
  Retcode findCityType(char *cityToFind, char *typeToFind, 
    PXSearchMode searchMode);
  //
  // Get the current record from the table.
  //
  virtual Retcode getRecord();

};

/****************************************************************************
*
* This class encapsulates the favorite restaurant database.
*
****************************************************************************/

class FavoriteRestaurant : public AbstractRestaurant {

  friend class MainRestaurant;

public:
  //
  // Specific variables used to store column values for this table.
  //
  char name[MAX_NAME_LEN + 1];
  char type[MAX_TYPE_LEN + 1];
  //
  // Constructor.
  //
  FavoriteRestaurant(BDatabase *db) : AbstractRestaurant(db)
  {
          memset(name,0, MAX_NAME_LEN + 1);
          memset(type,0, MAX_TYPE_LEN + 1);
  }

  //
  // BLOB retrieval functions.
  //
  virtual Retcode getMenu(char *buffer, unsigned int length, long offset, 
    unsigned int &bytesRead);
  //
  // BLOB size functions.
  //
  virtual long sizeOfMenuBlob();
  //
  // Get the current record from the table.
  //
  virtual Retcode getRecord();
     
};





