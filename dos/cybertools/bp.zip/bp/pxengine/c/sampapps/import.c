/* Copyright (c) 1990, 1992 by Borland International, Inc. */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "pxengine.h"

/*
 *  IMPORT.C  File Translation Example
 *
 *  Description: This sample program demonstrates how to translate
 *               an ASCII file into an indexed Paradox table.
 *
 *  ASCII files are expected to be in the following format:
 *
 *    Customer Number:     8 characters.
 *    Part Number:         8 characters.
 *    Quantity:            Integer.
 *    Date:                10 characters, format: MM/DD/YYYY.
 *
 *    Each field within the ASCII record should be separated by
 *    a space. Each record within the ASCII file should be separated 
 *    by a newline.
 *
 *  Compilation: To compile and link the sample program, make sure that
 *               your C compiler has been correctly installed. Compile
 *               the program using the Large memory model specifications:
 *               
 *                 Turbo C:      Option -ml
 *                 Microsoft:    Option /AL
 *
 *  Execution: To run the sample program, enter the following command:
 *
 *                import <ascii_file> <paradox_table>
 *
 *  Where:
 * 
 *  <ascii_file>     Is the name of an existing ASCII input file.
 *
 *  <Paradox_table>  Is the name of a Paradox table that is created
 *                   by the sample program.  Note that the sample
 *                   program checks to make sure that this table does
 *                   not yet exist.
 */

/* If you are running on a network, uncomment the following statement
 * and also check the network-specific information (such as NETPATH,
 * NETUSERNAME, and NETTYPE).

#define NETWORK */

#ifdef NETWORK
#define NETUSERNAME    "username"    /* network username */
#define NETPATH        ""            /* .net directory   */
#define NETTYPE        NOTONNET      /* network type     */
#endif

/* Field handles of Paradox table.  */

FIELDHANDLE FieldPartNbr,          /* Part Number     */
            FieldCustNbr,          /* Customer Number */
            FieldQuantity,         /* Quantity        */   
            FieldDate;             /* Date            */

/* Sizes of ASCII table fields. */

#define ASCIISIZECUSTNBR   9       /* Customer Number Length */
#define ASCIISIZEPARTNBR   9       /* Part Number Length     */
#define ASCIISIZEDATE      11      /* Date Length            */


/* Function returns. */

#define SUCCESS      0       /* function succeeded */
#define FAIL        -1       /* function failed    */

/* Structure for an ASCII fixed-length record. */

typedef struct
{
  char CustNbr[ASCIISIZECUSTNBR];     /* customer number */
  char PartNbr[ASCIISIZEPARTNBR];     /* part number     */
  int quantity;                       /* quantity        */
  char date[ASCIISIZEDATE];           /* date            */
} AsciiRecord;

/* Field names of Paradox table. */

char *FieldNames[] =  {"Part Number", "Cust Number", "Quantity","Date" };

/* Field types of Paradox table. */

char *FieldTypes[] = {"A8", "A8", "N", "D" };

#define NBRFIELDS    (sizeof(FieldNames) / sizeof(char *))
#define NBRKEYS      2


/* Function Prototypes. */

int main(int, char**);
int OpenFiles(char**,TABLEHANDLE *, FILE **);
int OpenAsciiFile(char *,FILE **);
int CreateParadoxFile(char *);
int translate(TABLEHANDLE, FILE *);
int TranslateBuffer(AsciiRecord *, RECORDHANDLE);
void CloseFiles(TABLEHANDLE, FILE *);
int InitFields(TABLEHANDLE);
int Error(int);

/*
 *  Function: main
 *
 *  Arguments: int argc      Number of arguments on command line.
 *             char **argv   Pointer to command line arguments.
 *
 *  Description: The following steps accomplish file translation:
 *
 *                  1.    Initialize the Engine.
 *                  2.    Open the ASCII data file.
 *                  3.    Create and open the Paradox table.
 *                  4.    Translate the data.
 *                  5.    Close all files.
 *                  6.    Exit the Engine.
 *
 *  Returns: None
 */

int main(int argc, char **argv)
{
  FILE * fpAscii;                   /* file pointer to ASCII file */
  TABLEHANDLE tblHandle;            /* table handle to Paradox table */

  /* Expect two file names on the command line. */

  if (argc != 3)
  {
    printf("Usage: IMPORT <ascii_file> <paradox_file>\n");
    return(FAIL);
  }

  /* Initialize the Engine. */

  #ifndef NETWORK
    if (Error(PXInit()))
  #else
    if (Error(PXNetInit(NETPATH, NETTYPE, NETUSERNAME)))
  #endif
    exit(1);

  if (CreateParadoxFile(argv[2]) == FAIL)
    exit(1);

  /* Open ASCII file and Paradox table. */

  if (OpenFiles(argv,&tblHandle,&fpAscii) == SUCCESS)
  {
    translate(tblHandle,fpAscii);
    CloseFiles(tblHandle,fpAscii);
  }
  return(Error(PXExit()));
}
/*
 *    Function: OpenFiles
 *
 *    Arguments: argv            Pointer to command line arguments
 *                               containing file names.
 *               tblHandlePtr    Pointer to a Paradox table handle.
 *               fpAscii         Pointer to a file pointer.
 *
 *    Description: OpenFiles verifies the existence of two command line
 *                 arguments expected to be file names. It then attempts to
 *                 open the ASCII file as well as the Paradox table.
 *
 *    Returns: SUCCESS    Files opened.
 *             FAIL       Error has occured.
 *
 */
int OpenFiles(char **argv,TABLEHANDLE *tblHandlePtr, FILE **fpAscii)
{
  if (OpenAsciiFile(argv[1],fpAscii) == FAIL)
    return(FAIL);

  /* Open the Paradox table. */

  if (Error(PXTblOpen(argv[2],tblHandlePtr,0,0)))
    return(FAIL);
  if (InitFields(*tblHandlePtr) == FAIL)
    return(FAIL);

  return(SUCCESS);
}

/*
 *    Function: OpenAsciiFile
 *
 *    Arguments: fileName    Pointer to ASCII input file.
 *               fpAscii     Pointer to a file pointer.
 *
 *    Description: Attempts to open the ASCII file for reading its data.
 *
 *    Returns: SUCCESS    File was opened.
 *             FAIL       Could not open file.
 */
int OpenAsciiFile(char *fileName, FILE **fpAscii)
{
  if ((*fpAscii = fopen(fileName, "r")) == NULL)
  {
    perror(fileName);
    return(FAIL);
  }
  else
    return(SUCCESS);
}

/*
 *    Function: CreateParadoxFile
 *
 *    Arguments: fileName   Pointer to Paradox file names.
 *
 *    Description: CreateParadoxFile performs three steps:
 *
 *                 1. Make sure the file doesn't already exist.
 *                 2. Create the file.
 *                 3. Create a primary index file.
 * 
 *    Returns: FAIL       Error has occured.
 *             SUCCESS    File create successful.
 */
int CreateParadoxFile(char *fileName)
{
  int exist,i;
  FIELDHANDLE keys[NBRFIELDS];

  /* Do not create the Paradox table if it already exists. */

  if (Error(PXTblExist(fileName, &exist)))
    return(FAIL);
 
  if (exist)
  {
    printf("IMPORT: Table %s already exists.\n", fileName);
    return(FAIL);
  }

  /* Now attempt to create the table. */

  if (Error(PXTblCreate(fileName, NBRFIELDS, FieldNames, FieldTypes)))
    return(FAIL);

  /* Add first two fields as primary key. */

  for (i=0;i<NBRKEYS;i++)
    keys[i] = i + 1;
  if (Error(PXKeyAdd(fileName, NBRKEYS, keys, PRIMARY)))
    return(FAIL);

  return(SUCCESS);
}

/*
 *    Function: translate
 *
 *    Arguments: tblHandle    Handle to a Paradox table.
 *               fpAscii      File pointer to ASCII input file.
 *
 *    Description: Translate is the translation driver. While there is 
 *                 still data in the ASCII input file, the function reads 
 *                 data from the file, translates it into Paradox 
 *                 records, and writes the translated record out 
 *                 to the Paradox table.
 *
 *    Returns: SUCCESS   Translation successful.
 *             FAIL      Error in translation.
 */
int translate(TABLEHANDLE tblHandle, FILE *fpAscii)
{
  AsciiRecord asciiBuf;
  RECORDHANDLE recHandle;

  /* Set up a record handle. */

  if (Error(PXRecBufOpen(tblHandle, &recHandle)))
    return(FAIL);

  /* Read records until the end of ASCII file is reached. */

  while (! feof(fpAscii))
  {
    /* Read the buffer and check for an unexpected end-of-file. */

    if (fscanf(fpAscii, "%s %s %d %s", asciiBuf.PartNbr, asciiBuf.CustNbr,
      &asciiBuf.quantity, asciiBuf.date) != NBRFIELDS)
      break;

    if (TranslateBuffer(&asciiBuf, recHandle) == FAIL)
      return(FAIL);

    /* Write the buffer to the Paradox table. */

    if (Error(PXRecAppend(tblHandle, recHandle)))
      return(FAIL);
  }

  /* After buffer is translated, close the record buffer. */

  if (Error(PXRecBufClose(recHandle)))
    return(FAIL);

  return(SUCCESS);
}


/*
 *    Function: TranslateBuffer
 *
 *    Arguments: buf        Pointer to an AsciiRecord buffer.
 *               recHandle  Paradox record handle.
 *
 *    Description: Translates a single ASCII table record into a Paradox
 *                 record buffer.
 *
 *    Returns: SUCCESS     Translation successful.
 *             FAIL        Translation failed.
 */
int TranslateBuffer(AsciiRecord * buf, RECORDHANDLE recHandle)
{
  long PXDate;
  int month, day, year;

  /* First, translate the Customer Number. */

  if (Error(PXPutAlpha(recHandle, FieldCustNbr, buf->CustNbr)))
    return(FAIL);

  /* Next, translate the Part Number. */

  if (Error(PXPutAlpha(recHandle, FieldPartNbr, buf->PartNbr)))
    return(FAIL);

  /* Translate the Quantity. */

  if (Error(PXPutDoub(recHandle, FieldQuantity, (double) buf->quantity)))
    return(FAIL);

  /* To translate the date, first get month, day, and year from buffer
     and then use PXEncode to translate it into a Paradox date format. */

  sscanf(buf->date, "%2d/%2d/%4d", &month, &day, &year);

  if (Error(PXDateEncode(month, day, year, &PXDate)))
    return(FAIL);

  /* Now put the date into the record buffer. */

  if (Error(PXPutDate(recHandle, FieldDate, PXDate)))
    return(FAIL);

  return(SUCCESS);
}
/*
 *    Function: CloseFiles
 *
 *    Arguments: None
 *
 *    Description: Closes ASCII and Paradox files. CloseFiles indicates 
 *                 any problems by reporting an error condition.
 *
 *    Returns: None
 */
void CloseFiles(TABLEHANDLE tblHandle, FILE *fpAscii)
{

  if (fclose(fpAscii) == EOF)
    fprintf(stderr, "Cannot close ASCII file\n");

  Error(PXTblClose(tblHandle));
}

/*
 *    Function: InitFields
 *
 *    Arguments: tblHandle       Paradox table handle.
 *
 *    Description: Initializes global variables representing the correct
 *                 field handles for the corresponding fields.
 *
 *    Returns: Current error code
 */
int InitFields(TABLEHANDLE tblHandle)
{
  if (Error(PXFldHandle(tblHandle,"Part Number",&FieldPartNbr)))
    return(FAIL);
  if (Error(PXFldHandle(tblHandle,"Cust Number",&FieldCustNbr)))
    return(FAIL);
  if (Error(PXFldHandle(tblHandle,"Quantity",&FieldQuantity)))
    return(FAIL);
  if (Error(PXFldHandle(tblHandle,"Date",&FieldDate)))
    return(FAIL);

  return(SUCCESS);
}

/*
 *    Function: Error
 *
 *    Arguments: rc      Return code from a PX... function.
 *
 *    Description: Prints error message if an error has occured.
 *
 *    Returns: Current error code
 */
int Error(int rc)
{

  if (rc != PXSUCCESS)
    printf("IMPORT: %s\n",PXErrMsg(rc));

  return rc;
}
