/****************************************************************************
*                                                                           
* FILE: TESTREST.CPP
*
* DESCRIPTION:  This program demonstrates how to use the restaurant        
*               classes for the C++ Database Framework. 
*            
*               
*
****************************************************************************/

// Increase the stack size. For Microsoft C++, stack size is set through
// the linker option /STACK. If you use the supplied makefile, REST.MAK,
// the stack size will be set to 8K.

#ifndef _MSC_VER
extern unsigned _stklen = 8192U;
#endif

#include  <iostream.h>
#include  <conio.h>
#include  <stdio.h>
#include  <string.h>
#include  <stdlib.h>
#ifdef _MSC_VER
#include  <malloc.h>
#include  <graph.h>
#else
#include  <alloc.h>
#endif
#include  <ctype.h>
#include "demo.h"

#ifdef _MSC_VER

void clrscr()
{
        _clearscreen(_GWINDOW);
        _settextposition(0,0);
}

#endif

/****************************************************************************
*                                                                           
* FUNCTION: showFavoriteOptions
*
* DESCRIPTION: Menu for selecting operations on the favoriteTable object.     
*        
*
****************************************************************************/

void showFavoriteOptions()
{
  clrscr();
  cout << "+-------------------------------------------------------------+\n";
  cout << "|               FAVORITE RESTAURANTS MENU                     |\n";     
  cout << "|                                                             |\n";     
  cout << "|      [PgUp]  Previous Record   [Home]  First Record         |\n";
  cout << "|      [PgDn]  Next Record       [End]   Last Record          |\n";
  cout << "|                                                             |\n";     
  cout << "|      [M]  Menu                 [X]  Exit to Main Menu       |\n";
  cout << "+-------------------------------------------------------------+\n";
  cout << "\n\n";
  cout.flush();
}



/****************************************************************************
*                                                                           
* FUNCTION: showSearchOptions
*
* DESCRIPTION: menu for selecting search conditions on the mainTable object.     
*        
*            
*               
*
****************************************************************************/
void showSearchOptions()
{

  clrscr();

  cout << "+-------------------------------------------------------------+\n";
  cout << "|                       SEARCH MENU                           |\n";     
  cout << "|                                                             |\n";     
  cout << "|      [C]  Locate by City/Type  [R]  Locate by Rating/Type   |\n";
  cout << "|                                                             |\n";
  cout << "|                Press any other key to exit.                 |\n";     
  cout << "+-------------------------------------------------------------+\n";
  cout << "\n\n";
  cout.flush();
}



/****************************************************************************
*                                                                           
* FUNCTION: showMainOptions
*
* DESCRIPTION: Menu for selecting operations on the mainTable object.     
*        
*
****************************************************************************/
void showMainOptions()
{
  clrscr();

  cout << "+-------------------------------------------------------------+\n";
  cout << "|                        MAIN MENU                            |\n";     
  cout << "|                                                             |\n";     
  cout << "|      [PgUp]  Previous Record   [Home]  First Record         |\n";
  cout << "|      [PgDn]  Next Record       [End]   Last Record          |\n";
  cout << "|                                                             |\n";     
  cout << "|      [M]  Menu                                              |\n";
  cout << "|      [F]  Find a Restaurant                                 |\n";
  cout << "|      [R]  Enter a review                                    |\n";
  cout << "|      [C]  Copy to Favorite Restaurant table                 |\n";
  cout << "|      [V]  View Favorite Restaurants                         |\n";     
  cout << "|      [X]  Exit to DOS                                       |\n";
  cout << "+-------------------------------------------------------------+\n";
  cout.flush();

}


/****************************************************************************
*                                                                           
* FUNCTION: errorMsg 
*
* DESCRIPTION: Displays an error message and error code.     
*        
*
****************************************************************************/

void errorMsg(char *message, int errorCode)
{
  cout << "\n\n" << message << errorCode << "\n";
  cout.flush();
}

/****************************************************************************
*                                                                           
* FUNCTION:  showFavoriteMenu
*
* DESCRIPTION: Shows the entire Menu memo field for the favoriteTable object
*              and then waits for a user response to continue.
*            
*
****************************************************************************/

void showFavoriteMenu(FavoriteRestaurant &favoriteTable)
{
  long sizeOfMenu;    
  long menuOffset;    
  unsigned int bytesRead; 
  char buffer [BLOB_COPY_LEN + 1];    

  //
  // Determine the size of the Menu memo field.
  //
  sizeOfMenu = favoriteTable.sizeOfMenuBlob();

  clrscr();

  cout << "Here is the menu:\n";
  cout.flush();

  //
  //  Read and then display BLOB_COPY_LEN bytes until the entire 
  //  memo is read.
  //
  for(menuOffset = 0; menuOffset < sizeOfMenu; 
      menuOffset += BLOB_COPY_LEN)
  {
    favoriteTable.getMenu(buffer, BLOB_COPY_LEN + 1, menuOffset, bytesRead);

    //
    // Check if memo data was read. 
    //
    if(bytesRead > 0)
    {
      cout << buffer;
      cout.flush();
    }
  }
  //
  //  Wait for the user to continue.
  //
  cout << "\n\n PRESS ANY KEY TO CONTINUE\n";
  cout.flush();
  getch();
  clrscr();

}


/****************************************************************************
*                                                                           
* FUNCTION:  showFavoriteRecord
*
* DESCRIPTION: Shows all field values of the current record for the 
*              favoriteTable object except for contents of memo fields.
*              
*
****************************************************************************/

void showFavoriteRecord(FavoriteRestaurant &favoriteTable)
{
  Retcode retVal;

  //
  // Get the record from the Favorite table and show the field values.
  //
  retVal = favoriteTable.getRecord();
  if(retVal == PXSUCCESS)
  {
    cout << "NAME:    " << favoriteTable.name << "\n";
    cout.flush();
    cout << "TYPE:    " << favoriteTable.type << "\n";
    cout.flush();
  }
  else
  {
    errorMsg("Error getting favorite record: ",(int)retVal);
  }  

}

/****************************************************************************
*                                                                           
* FUNCTION:  viewFavoriteTable
*
* DESCRIPTION: Shows all field values of the current record for the 
*              favoriteTable object except for memo fields, displays the
*              the favoriteTable options menu, then waits for user 
*              response to selections and handles the request. 
*
****************************************************************************/

void viewFavoriteTable(FavoriteRestaurant &favoriteTable)
{
  int done;
  int keyPress ;

  //
  // Process user input to the new menu options.
  //
  done = FALSE;
  while(!done)
  {
    //
    // Show the menu options and display a record from the table.
    //
    showFavoriteOptions();
    showFavoriteRecord(favoriteTable);

    //
    // Accept user input.
    //
    int origKey = getch();
    keyPress = toupper(origKey);

    clrscr();

    //
    // Handle the user's request.
    //
    switch(keyPress)
    {
      #ifdef _MSC_VER
      case 0:
      case 0xE0:
      #else
      case 0:
      #endif
        //
        // Check for PgUp, PgDn, Home, and End keys.
        //
        keyPress = getch();

        switch(keyPress)
        {
          case 73:                // PgUp key.
            favoriteTable.up();
            break;
                                  // PgDn key.
          case 81:
            favoriteTable.down();
            break;

          case 71:                // Home key.
            favoriteTable.home();
            break;

          case 79:                // End key.
            favoriteTable.end();
            break;
        }
        break;

      case 'X': 
        done = TRUE;
        break;

      case 'M': 
        showFavoriteMenu(favoriteTable);
        break;
    }
  }
}

/****************************************************************************
*                                                                           
* FUNCTION: copyMainToFavorite 
*
* DESCRIPTION: Copies the current record of the mainTable object,
*              including BLOB fields, to the favoriteTable object.
*            
*
****************************************************************************/

void copyMainToFavorite(MainRestaurant &mainTable, 
  FavoriteRestaurant &favoriteTable)
{
  Retcode retVal;

  //
  // Copy the current mainTable record and append it to favoriteTable.
  //
  retVal = mainTable.copyToFavorite(favoriteTable);
  if( retVal != PXSUCCESS)
  {
    errorMsg("Record was not copied to favorite table: ",retVal);
    cout << "\n\n PRESS ANY KEY TO CONTINUE\n";
    cout.flush();
    getch();
  }
}

/****************************************************************************
*                                                                           
* FUNCTION:  searchMainTable
*
* DESCRIPTION: Shows the search method options menu, allows the user to
*              select an option and processes the request, reporting an
*              error if the search failed.
*               
*
****************************************************************************/
void searchMainTable(MainRestaurant &mainTable)
{
  Retcode retVal;
  int     keyPress;
  short   rating;
  char    temp_buffer[5];
  char    city[MAX_CITY_LEN + 1];
  char    type[MAX_TYPE_LEN + 1];

    //
    // In case, search is not executed. 
    //
    retVal = PXSUCCESS;

    //
    // Show the search options menu and wait for user input.
    //
    showSearchOptions();
    keyPress = toupper(getch());

    //
    // Handle the user's request.
    //
    switch(keyPress) 
    {
      case 'C': 
        //
        // Get the user input.
        //
        cout << "City to find: ";
        cout.flush();
        cin.getline(city, sizeof(city));

        cout << "\nType to find: ";
        cout.flush();
        cin.getline(type, sizeof(type));

        //
        // Attempt to find a match.
        //
        retVal = mainTable.findCityType(city, type, pxSearchFirst);
        break;

      case 'R': 
        //
        // Get the user input.
        //
        cout << "Rating to find: ";
        cout.flush();
        cin.getline(temp_buffer, sizeof(temp_buffer));
        rating = atoi(temp_buffer);

        cout << "\nType to find: ";
        cout.flush();
        cin.getline(type, sizeof(type));

        //
        // Attempt to find a match.
        //
        retVal = mainTable.findRatingType(rating, type, pxSearchFirst);
        break;
    } 
    //
    // If a search was attempted, check if it was successful.
    //
    if(retVal != PXSUCCESS)
    {
      errorMsg("\nNo match found! Error code: ", retVal);
      cout << "\n\nPRESS ANY KEY TO CONTINUE";
      cout.flush();
      getch();
    }
    clrscr();
}

/****************************************************************************
*                                                                           
* FUNCTION: showMainReview
*
* DESCRIPTION: Shows the entire Review memo field for the mainTable object     
*              and then processes the user's response.
*            
*
****************************************************************************/

void showMainReview(MainRestaurant &mainTable)
{
  long sizeOfReview;    
  long reviewOffset;    
  unsigned int  bytesRead; 
  char buffer [BLOB_COPY_LEN + 1];    

  //
  // Find the size of the Review memo field.
  //
  sizeOfReview = mainTable.sizeOfReviewBlob();

  clrscr();
  cout << "Here is the complete review:\n\n";
  cout.flush();

  //
  //  Read and display up to BLOB_COPY_LEN + 1 bytes until the entire 
  //  memo is read.
  //
  for(reviewOffset = 0; reviewOffset < sizeOfReview; 
    reviewOffset += BLOB_COPY_LEN)
  {
    mainTable.getReview(buffer, BLOB_COPY_LEN + 1, reviewOffset, bytesRead);

    //
    // Check if any memo data was read.
    //
    if(bytesRead > 0)
    {
      cout << buffer;
      cout.flush();
    }
  }
  //
  //  Wait for the user to press any key. 
  //
  cout << "\n\nPRESS ANY KEY TO CONTINUE";
  cout.flush();
  getch();
  clrscr();
}

/****************************************************************************
*                                                                           
* FUNCTION: showMainMenu
*
* DESCRIPTION: shows the entire Menu memo field for the mainTable object     
*              and then processes the user's response.
*            
*
****************************************************************************/

void showMainMenu(MainRestaurant &mainTable)
{
  long sizeOfMenu;    
  long menuOffset;    
  unsigned int bytesRead; 
  char buffer [BLOB_COPY_LEN + 1];    

  //
  // Find the size of the Menu memo field.
  //
  sizeOfMenu = mainTable.sizeOfMenuBlob();

  clrscr();
  cout << "\n\nHere is the menu:\n";
  cout.flush();

  //
  //  Read up to BLOB_COPY_LEN + 1 bytes until the entire memo is read.
  //
  for(menuOffset = 0; menuOffset < sizeOfMenu; menuOffset += BLOB_COPY_LEN)
  {
    mainTable.getMenu(buffer, BLOB_COPY_LEN + 1, menuOffset, bytesRead);

    //
    // Check if any memo data was read.
    //
    if(bytesRead > 0)
    {
      cout << buffer;
      cout.flush();
    }
  }
  //
  //  Wait for the user to press any key.
  //
  cout << "\n\nPRESS ANY KEY TO CONTINUE";
  cout.flush();
  getch();
  clrscr();

}

/****************************************************************************
*                                                                           
* FUNCTION: showMainRecord 
*
* DESCRIPTION: Shows the current record for the mainTable object, including     
*              the header portion of the Review memo field. 
*           
*
****************************************************************************/

void showMainRecord(MainRestaurant &mainTable)
{
  Retcode retVal;
  int  bytesRead;

  //
  // A buffer used to store the header of the Review BLOB.
  //
  char quickReviewBuffer[MAX_REVIEW_SIZE + 1];

  //
  // Get the record from the main table.
  //
  retVal = mainTable.getRecord();
  if(retVal == PXSUCCESS)
  {
    //
    // For now, display a small portion of the current restaurant's review. 
    //
    retVal = mainTable.getQuickReview(quickReviewBuffer, MAX_REVIEW_SIZE + 1, 
      bytesRead);

    //
    //  If OK, show the field values for this record.
    //
    if(retVal == PXSUCCESS)
    {
      cout << "NAME:    " << mainTable.name      << "\n";
      cout << "STREET:  " << mainTable.street    << "\n";
      cout << "CITY:    " << mainTable.city      << "\n";
      cout << "STATE:   " << mainTable.state     << "\n";
      cout << "ZIP:     " << mainTable.zip       << "\n";
      cout << "PHONE:   " << mainTable.telephone << "\n";
      cout << "TYPE:    " << mainTable.type      << "\n";
      cout << "RATING:  " << mainTable.rating    << "\n";
      cout << "QUICK REVIEW:\n\n";
      cout << quickReviewBuffer;
      cout.flush();
    }
    else
    {
      errorMsg("Error getting quick review: ",(int)retVal);
    }
  }
  else
  {
    errorMsg("Error getting record: ",(int)retVal);
  }  
}

/****************************************************************************
*                                                                           
* FUNCTION:  MAIN
*
* DESCRIPTION: Initializes all objects and opens database tables. 
*              Processes user request for selection of main menu 
*              options while displaying the menu options and the 
*              current record of the mainTable object.
*
****************************************************************************/
main()
{
  //
  //  Declaration of local variables.
  //
  int keyPress;
  int done;
  Retcode retVal;

  #ifdef _MSC_VER
  _setvideomode(_TEXTC80);
  #endif

  //
  //  The objects in the application are initialized here.
  //

  // initialize Paradox Engine, being careful of errors

  BEngine eng(pxNet);
  retVal = eng.lastError;
  if (retVal != PXSUCCESS)
  {
       errorMsg("Could not initialize the Engine. Error code:",retVal);
       return(-1);
  }

  // open the universal database, watching for possible errors

  BDatabase db(&eng);
  retVal = db.lastError;
  if (retVal != PXSUCCESS)
  {
       errorMsg("Could not open the Database. Error code:",retVal);
       return(-1);
  }

  MainRestaurant mainTable(&db);
  FavoriteRestaurant favoriteTable(&db);

  clrscr();

  //
  //  Open the main table containing all the restaurant reviews.

  //  (i.e. PXTblOpen() )
  //
  retVal = mainTable.open("EATS");
  if(retVal != PXSUCCESS)
  {
    //
    // If a fatal application error occurs, return early.
    //
    errorMsg("Could not open the MAIN table. Error code:",retVal);
    return(-1);
  }
  //
  //  Open the Favorite table containing all of the user's favorite 
  //  restaurant menus. 
  //
  retVal = favoriteTable.open("FAVEATS");
  if(retVal != PXSUCCESS)
  {
    //
    // If a fatal application error occurs, clean up and return.
    //
    mainTable.close();
    errorMsg("Could not open the FAVORITE table. Error code:",retVal);
    return(-1);
  }

  //
  // Move to the first record. 
  //
  mainTable.home();
  favoriteTable.home();

  //
  // Process user input and selection of menu options.
  //
  done = FALSE;
  while(!done)
  {
    //
    // Display the main menu options and a main table record.
    //
    showMainOptions();
    showMainRecord(mainTable);

    //
    // Accept user input.
    //
    int origKey = getch();
    keyPress = toupper(origKey);

    //
    // Handle the user's request.
    //
    switch(keyPress)
    {
      #ifdef _MSC_VER
      case 0xE0:
      case 0:
      #else
      case 0:
      #endif

        //
        // Check for PgUp, PgDn, Home, and End keys.
        //
        keyPress = getch();

        switch(keyPress)
        {
          case 73:            // PgUp key.
            mainTable.up();
            break;
                              // PgDn key.
          case 81:
            mainTable.down();
            break;

          case 71:            // Home key.
            mainTable.home();
            break;

          case 79:            // End key.
            mainTable.end();
            break;
        }
        break;

      case 'X': 
        done = TRUE;
        break;


      case 'R':
        showMainReview(mainTable);
        break;

      case 'M':
        showMainMenu(mainTable);
        break;

      case 'C':
        copyMainToFavorite(mainTable, favoriteTable);
        break;

      case 'F':
        searchMainTable(mainTable);
        break;

      case 'V':
        viewFavoriteTable(favoriteTable);
        break;

    }
  }
  //
  // Application ended. Close tables and return. 
  //
  mainTable.close();
  favoriteTable.close();
  return(PXSUCCESS);
}

    



           

