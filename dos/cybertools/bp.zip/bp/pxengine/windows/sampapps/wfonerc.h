#ifndef __WFONERC_H
#define __WFONERC_H


#define IDD_NEWRECORD       100
#define IDD_DELETE          101
#define IDD_UPDATE          102
#define IDD_EMPTYTABLE      103
#define IDD_HOME            104
#define IDD_PRIOR           105
#define IDD_NEXT            106
#define IDD_END             107
#define IDD_SEARCH          108
#define IDD_AUTOUPDATE      109
#define IDD_QUIT            110

#define IDD_OK              111
#define IDD_CANCEL          112

#define IDD_LASTNAMEEDIT    113
#define IDD_FIRSTNAMEEDIT   114
#define IDD_ADDRESSEDIT     115
#define IDD_CITYEDIT        116
#define IDD_STATEEDIT       117
#define IDD_ZIPEDIT         118
#define IDD_PHONEEDIT       119
#define IDD_DATEEDIT        120
#define IDD_NOTESEDIT       121

#define IDD_SEARCHFIRST     122
#define IDD_SEARCHNEXT      123
#define IDD_CONTINUESEARCH  124
#define IDD_SEARCHSTRINGEDIT 125

#define IDM_ABOUT           126

/*
   Make sure that the macro IDs, which correspond to the fields of the
   array 'names', are defined sequentially, so that subtracting IDD_FIRST 
   from the ID provides the appropriate index into 'names'. IDD_FIRST 
   should correspond to the first item in 'names'.
*/

#define IDD_FIRST           IDD_LASTNAMEEDIT

#endif
