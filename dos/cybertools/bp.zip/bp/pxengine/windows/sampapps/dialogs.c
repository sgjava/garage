#include "wfonedex.h"
#include "pxengine.h"

#include <stdlib.h>

/*****************************************************************

Function:  BOOL FAR PASCAL FonedexDlgProc( HWND hDlg, unsigned iMessage, 
                      WORD wParam, LONG lParam );

Arguments: hDlg         HWND dialogbox handle.
           iMessage     Unsigned (type of message).
           wParam       WORD parameter.
           lParam       LONG parameter.

Description: Processes messages for dialog box. The user can add, 
             delete, update, and search for items in the phone database.

Returns: TRUE        Returned to Windows if it processes a message.
         FALSE (0)   Returned if DefDlgProc should handle the message.

******************************************************************/

BOOL FAR PASCAL FonedexDlgProc( HWND hDlg, unsigned iMessage, 
                  WORD wParam, LONG lParam )
{
  char Buffer[MAXFIELDSIZE];
  HCURSOR hCursor;

  FARPROC lpfnAboutDlgProc;
  static FARPROC lpfnSearchDlgProc;
  static int bAutoUpdate = FALSE;  /* At start, Auto-update is turned off. */

  /* nCurrentField is the ID of the most recently selected field of the    */
  /* FONDEX form; nCurrentField - IDD_FIRST is the index into the array    */
  /* NAMES that is the name of the field.                                  */

  static WORD nCurrentField = IDD_LASTNAMEEDIT;

  switch (iMessage)
  {
    case WM_INITDIALOG:

      lpfnSearchDlgProc = MakeProcInstance(SearchDlgProc, hInst);

      /* Exit if the initialization fails. */

      if (Init()) {
        SendMessage(hDlg, WM_CLOSE, 0, 0L);
        break;
      }

      /* If the table is not empty, display first record. */

      if (PXRecFirst(tblHandle) == PXERR_TABLEEMPTY)
        break;
      bAutoUpdate = FALSE;
      PostMessage(hDlg, WM_COMMAND, IDD_HOME, 0L);

      break;

    case WM_COMMAND:
      switch (wParam)
      {
        case IDD_LASTNAMEEDIT:
        case IDD_FIRSTNAMEEDIT:
        case IDD_ADDRESSEDIT:
        case IDD_CITYEDIT:
        case IDD_STATEEDIT:
        case IDD_ZIPEDIT:
        case IDD_PHONEEDIT:
        case IDD_DATEEDIT:
        case IDD_NOTESEDIT:

          /* Set field for search. */

          if (HIWORD(lParam) == EN_SETFOCUS)
            nCurrentField = wParam;
          break;

        case IDD_NEWRECORD:

          /* Before creating a new record, save the current record */
          /* if necessary.                                         */

          if (bAutoUpdate)
            ProcessRecord();
          GetDlgItemText(hDlg, nCurrentField, Buffer, MAXFIELDSIZE);

          /* Display a blank record and append a new record with
             blank fields to the FONEDEX table. */

          BlankDisplayedRecord();
          SetRecord();

          /* If the new record could not be added to the table  */
          /* (e.g., if there already is a record with blank     */
          /* and first name fields), display record that was    */
          /* current before attempt to append occured.          */

          if (Error(PXRecAppend(tblHandle, recHandle)))
            DisplayRecord();
          Error(PXRecGet(tblHandle, recHandle));
          Error(PXRecBufCopy(recHandle, SaveRecHandle));
          SetFocus(GetDlgItem(hDlg, IDD_LASTNAMEEDIT));
          break;

        case IDD_UPDATE:

          ProcessRecord();
          break;

        case IDD_DELETE:

          if (MessageBox(hDlg, "Are you sure you want to \
            delete the current record from the Fonedex?", 
            "Delete Current Record", MB_OKCANCEL | MB_DEFBUTTON2 ) != IDOK)
          break;
          Error(PXRecDelete(tblHandle));
          DisplayRecord();

          break;

        case IDD_EMPTYTABLE:

          if (MessageBox(hDlg,
            "Are you sure you want to empty the FONEDEX table?", 
            "Empty Table", MB_OKCANCEL | MB_DEFBUTTON2 ) != IDOK)
             break;

          hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));

          /* The table must be closed before it can be emptied. */

          if(CloseFonedex() == FALSE)
          {
            Message("Table could not be emptied.");
          }

          /* Remove all records from the table. */

          Error(PXTblEmpty(DATAFILE));

          /* Reopen the (now empty) table. */

          OpenFonedex();

          BlankDisplayedRecord();

          SetCursor(hCursor);

          break;

        case IDD_SEARCH:

          /* Refresh table in a multi-user environment. */

          PXNetTblRefresh(tblHandle);

          /* Before performing search, save current record if necessary. */

          if (bAutoUpdate)
            ProcessRecord();
          DialogBox(hInst, "Search", hDlg, lpfnSearchDlgProc);
          break;

        case IDD_AUTOUPDATE:

          bAutoUpdate = !bAutoUpdate;
          CheckDlgButton(hDlg, IDD_AUTOUPDATE, bAutoUpdate);
          break;

        case IDD_HOME:

          /* Refresh table in a multi-user environment. */

          PXNetTblRefresh(tblHandle);
 
          /* Before changing record, save current record if necessary. */

          if (bAutoUpdate)
            ProcessRecord();

          /* Move to the first record of the table. */

          if (Error(PXRecFirst(tblHandle)))
            break;
          DisplayRecord();
          break;

        case IDD_PRIOR:
                    
          PXNetTblRefresh(tblHandle);
          if (bAutoUpdate)
            ProcessRecord();

          /* Move to the previous record of the table. */

          if (Error(PXRecPrev(tblHandle)))
            break;
          DisplayRecord();
          break;

        case IDD_NEXT:

          PXNetTblRefresh(tblHandle);
          if (bAutoUpdate)
            ProcessRecord();

          /* Move to the next record of the table. */

          if (Error(PXRecNext(tblHandle)))
            break;
          DisplayRecord();
          break;

        case IDD_END:

          PXNetTblRefresh(tblHandle);
          if (bAutoUpdate) 
            ProcessRecord();

          /* Move to the last record of the table. */

          if (Error(PXRecLast(tblHandle)))
            break;
          DisplayRecord();
          break;

        case IDD_QUIT:

          /* Before exiting, save current record. */
  
          if (bAutoUpdate)
            ProcessRecord();
          SendMessage(hDlg, WM_CLOSE, 0, 0L);
          break;

        default:

          return FALSE;
      }
      break;

    case WM_SYSCOMMAND:

      switch (wParam)
      {
        case IDM_ABOUT:

          lpfnAboutDlgProc = MakeProcInstance(AboutDlgProc, hInst);
          DialogBox(hInst, "About", hDlg, lpfnAboutDlgProc);
          FreeProcInstance(lpfnAboutDlgProc);
          break;

        default:
          return FALSE;
      }
      break;

    case WM_CLOSE:

      FreeProcInstance(lpfnSearchDlgProc);
 
      /* If the table is open, close it and free the record buffer. */

      if (TableIsOpen)
        CloseFonedex();

      /* Terminate the engine. */

      Error(PXExit());

      /* Send a WM_DESTROY message. */

      DestroyWindow(hDlg);
      hDlgModeless = 0;
      break;

    case WM_DESTROY:

      PostQuitMessage(0);
      break;

      default:

      return FALSE;
    }
  return FALSE;
}


/*********************************************************************

Function: BOOL FAR PASCAL SearchDlgProc(HWND hDlg, unsigned iMessage, 
                     WORD wParam, LONG lParam);

Arguments: hDlg       HWND, which is the handle to the Search dialog box.
           iMessage   Unsigned (type of message).
           wParam     WORD parameter.
           lParam     LONG parameter.

Description: Processes messages for Search dialog box.

Returns: TRUE      Returned to Windows if it processes a message.
         FALSE(0)  Returned if DefDlgProc should handle the message.

***********************************************************************/

#ifdef __BORLANDC__
#pragma argsused       /* This pragma is used for Borland C++. */
#endif

BOOL FAR PASCAL SearchDlgProc(HWND hDlg, unsigned iMessage, 
                  WORD wParam, LONG lParam)
{
  /* Initial values of dialog box settings. */

  static int nSearchField = IDD_LASTNAMEEDIT;
  static int nSearchMode = IDD_SEARCHFIRST;
  static int bContinueSearch = FALSE;
  static char szSearchBuffer[MAXFIELDSIZE] = "";

  HCURSOR hCursor;    /* Handle to a cursor. */

  switch (iMessage)
  {
    case WM_INITDIALOG:

      /* Make initial button settings. */

      CheckRadioButton(hDlg, IDD_LASTNAMEEDIT, IDD_NOTESEDIT, nSearchField);
      SetDlgItemText(hDlg, IDD_SEARCHSTRINGEDIT, szSearchBuffer);
      CheckRadioButton(hDlg, IDD_SEARCHFIRST, IDD_SEARCHNEXT, nSearchMode);
      CheckDlgButton(hDlg, IDD_CONTINUESEARCH, bContinueSearch);
      PostMessage(hDlg, WM_NEXTDLGCTL, GetDlgItem(hDlg, 
        IDD_SEARCHSTRINGEDIT) , 1L);
      SendDlgItemMessage(hDlg, IDD_SEARCHSTRINGEDIT, 
        EM_SETSEL, 0, 0xFFFF0000);
      break;

    case WM_COMMAND:
      switch (wParam)
      {
        /* Determine the field on which to search. */
  
        case IDD_LASTNAMEEDIT:
        case IDD_FIRSTNAMEEDIT:
        case IDD_ADDRESSEDIT:
        case IDD_CITYEDIT:
        case IDD_STATEEDIT:
        case IDD_ZIPEDIT:
        case IDD_PHONEEDIT:
        case IDD_DATEEDIT:
        case IDD_NOTESEDIT:

          nSearchField = wParam;
          CheckRadioButton(hDlg, IDD_LASTNAMEEDIT, IDD_NOTESEDIT, wParam);
            break;

          /* Determine whether to begin the search at the first record or */
          /* begin the search at the record following the current record. */

        case IDD_SEARCHFIRST:
        case IDD_SEARCHNEXT:

          nSearchMode = wParam;
          CheckRadioButton(hDlg, IDD_SEARCHFIRST, IDD_SEARCHNEXT, wParam);
          break;

          /* If this button is checked, another search may be processed   */
          /* without having to reinvoke the search dialog box.            */
 
        case IDD_CONTINUESEARCH:

          bContinueSearch = !bContinueSearch;
          CheckDlgButton(hDlg, IDD_CONTINUESEARCH, bContinueSearch);
            break;

          /* Start the search. */
 
        case IDD_OK:

          hCursor = SetCursor(LoadCursor(NULL, IDC_WAIT));
          GetDlgItemText(hDlg, IDD_SEARCHSTRINGEDIT, szSearchBuffer,
            MAXFIELDSIZE);

          /* nSearchField - IDD_FIRST + 1 is the (Paradox) field			 */
          /* number of the record field on which to search.              */

          if (! Search(nSearchField - IDD_FIRST + 1, szSearchBuffer,
            (nSearchMode == IDD_SEARCHFIRST) ? SEARCHFIRST : SEARCHNEXT))
          {
            MessageBox(hDlg, "Search Failed.", "Search Message",
              MB_OK | MB_ICONHAND);
          }
          SetCursor(hCursor);

          if (! bContinueSearch)
            EndDialog(hDlg, 0);
          break;

          /* Exit the dialog box. */

        case IDD_CANCEL:
          GetDlgItemText(hDlg, IDD_SEARCHSTRINGEDIT, szSearchBuffer,
            MAXFIELDSIZE);
          EndDialog(hDlg, 0);
          break;

        default:

          return FALSE;
      }
      break;

    case WM_CLOSE:
      SendMessage(hDlg, WM_COMMAND, IDD_CANCEL, 0L);
      break;

    default:

      return FALSE;
  }

  return TRUE;
}


/**********************************************************************

Function: BOOL FAR PASCAL AboutDlgProc(HWND hDlg, unsigned iMessage, 
                            WORD wParam, LONG lParam);

Arguments: hDlg            HWND dialogbox handle.
           iMessage        Unsigned (type of message).
           wParam          WORD parameter.
           lParam          LONG parameter.

Description: Processes messages for "About" dialog box.

Returns: TRUE is returned to Windows if it processes a message,
         and FALSE (0) if DefDlgProc should handle the message.

**********************************************************************/

#ifdef __BORLANDC__
#pragma argsused        /* This pragma is used for Borland C++. */
#endif

BOOL FAR PASCAL AboutDlgProc(HWND hDlg, unsigned iMessage, 
                  WORD wParam, LONG lParam)
{
  switch (iMessage) {

    case WM_INITDIALOG:

      return TRUE;

    case WM_COMMAND:

      if (wParam == IDOK || wParam == IDCANCEL) {
        EndDialog(hDlg, TRUE);
        return TRUE;
      }
      break;
  }

    return FALSE;
}
