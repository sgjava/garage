#ifndef __WFONEDEX_H
#define __WFONEDEX_H


#include <windows.h>

#include "pxengine.h"


/* Constants used in resources: wfonedex.rc */
#include "wfonerc.h"


#define FAIL 1

/* Defined in WINMAIN.C. */

int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, 
             LPSTR lpszCmdLine, int nCmdShow);

extern char szAppName[];    /* Application name. */
extern HANDLE hInst;        /* Handle to current instance of application. */
extern HWND hDlgModeless;   /* Handle to modeless dialog box. */


/* Defined in DIALOGS.C. */

BOOL FAR PASCAL FonedexDlgProc(HWND hDlg, unsigned iMessage, WORD wParam,
                                LONG lParam);
BOOL FAR PASCAL SearchDlgProc(HWND hDlg, unsigned iMessage, WORD wParam,
                               LONG lParam);
BOOL FAR PASCAL AboutDlgProc(HWND hDlg, unsigned iMessage, WORD wParam,
                              LONG lParam);


/* Defined in WFONEDEX.C. */

int Init(void);
int OpenFonedex(void);
int CloseFonedex(void);
int Search(int FieldNumber, char *Buffer, int mode);
int ProcessRecord(void);
void UpdateRecord(void);
int IsRecordChanged(void);
void DisplayRecord(void);
void SetRecord(void);
void BlankDisplayedRecord(void);
int GetData(RECORDHANDLE rechandle, FIELDHANDLE fh, char s[]);
int PutData(FIELDHANDLE fh, char *s);
int Error(int rc);
void Message(char *message);

extern RECORDHANDLE recHandle;     /* Record buffer. */
extern RECORDHANDLE SaveRecHandle; /* Save record buffer. */
extern TABLEHANDLE tblHandle;      /* Table handle. */
extern int TableIsOpen;


/* Name of FONEDEX table. */

#define DATAFILE        "wfonedex"

#define MAXFIELDSIZE    120


#endif /* __WFONEDEX_H */
