#include "wfonedex.h"
#include <pxengine.h>

#include <ctype.h>
#include <stdio.h>
#include <string.h>

RECORDHANDLE recHandle;      /* Record buffer */
RECORDHANDLE SaveRecHandle;  /* Save Record buffer */
TABLEHANDLE tblHandle;       /* Table handle */

char  far *names[] = {
    "Last Name",
    "First Name",
    "Address",
    "City",
    "State",
    "ZIP Code",
    "Phone Number",
    "Date Last Phoned",
    "Notes"
};

char far *types[] = {
    "A15",
    "A15",
    "A40",
    "A15",
    "A15",
    "N",
    "A20",
    "D",
    "A120"
};

/* Number of fields */
int nfields = sizeof( names ) / sizeof( char far * );

/* Field handles to be used in primary key. */
FIELDHANDLE fldHandles[] = { 1, 2 };


extern int TableIsOpen = FALSE; /* Table is open */


/*******************************************************************************

    Function:

        int Init( void );

    Arguments:
        None

    Description:
        Initializes the Paradox environment,
        creates a new fonedex database if one does not already exist,
        creates a primary index on the last and first name fields of
        the table, and opens the table.

    Returns:
        0 if successful and 1 if not.

******************************************************************************/

int Init( void )
{
    int bExist;                 /* Used to determine table already exists. */

    /* Initialize the engine. */
    if ( Error( PXWinInit( szAppName, PXSHARED ) ) )
        return 1;

    /* Create a new table if one does not already exist. */
    Error( PXTblExist( DATAFILE, &bExist ) );
    if ( ! bExist ) {
        /* Try and create it */
        if ( Error( PXTblCreate( DATAFILE, nfields, names, types ) ) )
            return 1;

        /* Successful create, Now add Primary Index */
        if ( Error( PXKeyAdd( DATAFILE, sizeof( fldHandles ) /
                  sizeof( FIELDHANDLE ), fldHandles, PRIMARY ) ) )
            return 1;

    }

    return OpenFonedex();
}


/*******************************************************************************

    Function:

        int OpenFonedex( void );

    Arguments:
        None

    Description:
        Opens the table, and allocates and empties a
        record buffer.

    Returns:
        1 if the Fonedex could not be opened as expected.
        0 if successful.

******************************************************************************/

int OpenFonedex( void )
{
    /* Attempt to open the table. */
    if ( Error( PXTblOpen( DATAFILE, &tblHandle, 0, TRUE ) ) )
          return 1;

    /* Allocate a record buffer. */
    if ( Error( PXRecBufOpen( tblHandle, &recHandle ) ) )
          return 1;
    if ( Error( PXRecBufOpen( tblHandle, &SaveRecHandle ) ) )
          return 1;

    TableIsOpen = TRUE;

    /* Empty the current record buffer */
    if ( Error( PXRecBufEmpty( recHandle ) ) )
        return 1;
    if ( Error( PXRecBufEmpty( SaveRecHandle ) ) )
        return 1;

    return 0;
}


/*******************************************************************************

    Function:

        int CloseFonedex( void );

    Arguments:
        None

    Description:
        Closes the fonedex table if opened.

    Returns:
        TRUE if the table was closed;
        FALSE if the table could not be closed.

******************************************************************************/

int CloseFonedex( void )
{
    int iBufError,    /* Used to determine Error closing Record Buffer */
        iSavBufError, /* Used to determine Error closing Save Buffer */
        iTblError;    /* Used to determine Error closing Table */

    if ( !TableIsOpen )
    {
          Message( "Close Fonedex: Table was not open." );
          return FALSE;
    }

    /* Set open flag to FALSE */
    TableIsOpen = FALSE;

    /* Free the record buffer. */
    iBufError = Error( PXRecBufClose( recHandle ) );
    iSavBufError = Error( PXRecBufClose( SaveRecHandle ) );

    /* Close the table. */
    iTblError = Error( PXTblClose( tblHandle ) );

    /*  return FALSE upon error closing Table */
    if ( iTblError )
          return FALSE;

    /*  return FALSE upon error closing Record Buffer */
    if ( ( iBufError ) || ( iSavBufError ) )
          return FALSE;

    return TRUE;
}


/*******************************************************************************

    Function:

        int Search( int FieldNumber, char *Buffer, int mode );

    Arguments:
        hWnd            handle to window which is parent of any message
                           boxes that result from the search.
        FieldNumber     Field number selected
        Buffer          string which is search input of field
        mode            search mode (SEARCHFIRST or SEARCHNEXT)

    Description:
        Search on the field corresponding to FieldNumber and display
        record if found.

    Returns:
        TRUE if the search succeeds (a record is found such that
        the field determined by FieldNumber matches the contents of
        Buffer);
        FALSE if the search fails.

******************************************************************************/

int Search( int FieldNumber, char *Buffer, int mode )
{
    /* Refresh the database in case anyone else has updated it */
    PXNetTblRefresh( tblHandle );

    /* Translate input field to search on */
    /* If that fails, or ... */
    if ( ( PutData( FieldNumber, Buffer ) != PXSUCCESS ) ||
        /* If no match found, or ... */
        ( PXSrchFld( tblHandle, recHandle, FieldNumber, mode ) != PXSUCCESS ) ||
        /* If you cannot get the record found, return FALSE */
        ( Error( PXRecGet( tblHandle, recHandle ) ) ) )
    {
        DisplayRecord();
        return FALSE;   /* Return if search cannot go on */
    }
    /* Put new record into save record */
    Error( PXRecBufCopy( recHandle, SaveRecHandle ) );
    DisplayRecord();
    return TRUE;
}


/*******************************************************************************

    Function:

        int ProcessRecord( void );

    Arguments:
        None.

    Description:
        Locks the record and calls IsRecordChanged and UpdateRecord.

    Returns:
        TRUE if the records differ;
        FALSE otherwise.

******************************************************************************/

int ProcessRecord( void )
{

    static LOCKHANDLE lckHandle;
    int iLock,
        iUpdate;

    /* Lock the record */
    iLock = PXNetRecLock( tblHandle, &lckHandle );
    if ( iLock == PXERR_TABLEEMPTY )
    {  
         MessageBox( hDlgModeless, "Could Not Update Current Record", 
             "Update Failed:  Empty Table", MB_OKCANCEL | MB_DEFBUTTON2 );
         return FALSE;
    }

    if ( iLock == PXERR_RECDELETED )
    {
        iUpdate = MessageBox( hDlgModeless, "Another User has Deleted the Record",
             "Insert Record", MB_OKCANCEL | MB_DEFBUTTON2 );
        if ( iUpdate == IDOK )
        {
             /* Insert Record */   
             SetRecord();
             if ( Error ( PXRecInsert( tblHandle, recHandle ) ) )
             {
                  Message( "Insert failed: PXRecInsert failed." );
                  return FALSE;
             }
             Error( PXRecBufCopy ( recHandle, SaveRecHandle ) );
             return TRUE;
        }
        else
        {
             /* Update the Dialog Box with New Record */
             DisplayRecord();
             return FALSE;
        }
    }

    if ( iLock )
    {
        Message( "Update failed: Could not lock current record." );
        return FALSE;
    }

   if ( IsRecordChanged() )
   {
        iUpdate = MessageBox( hDlgModeless, "Another User has Modified the Record",
             "Update Record", MB_OKCANCEL | MB_DEFBUTTON2 );
        if ( iUpdate != IDOK )
        {
             /* Update the Dialog Box with New Record */
             DisplayRecord();
             Error( PXNetRecUnlock( tblHandle, lckHandle ) );
             return FALSE;
        }
   }

    UpdateRecord();

    /* And unlock record */
    if ( Error( PXNetRecUnlock( tblHandle, lckHandle ) ) )
         return FALSE;

    return TRUE;

}


/*******************************************************************************

    Function:

        void UpdateRecord( void );

    Arguments:
        None

    Description:
        Updates the current record in a Fonedex table.

    Returns:
        None

******************************************************************************/

void UpdateRecord( void )
{

    int rc;

    SetRecord();

    /* Update it */
    if (Error( PXRecUpdate( tblHandle, recHandle ) ) )
    {
        Message( "Update failed: PXRecUpdate failed." );
        return;
    }
    Error( PXRecBufCopy ( recHandle, SaveRecHandle ) );

}


/*******************************************************************************

    Function:

        int IsRecordChanged( void );

    Arguments:
        None

    Description:
        Determines whether original record read from the table is different
        from record in the table.

    Returns:
        TRUE if the records differ;
        FALSE otherwise.

******************************************************************************/

int IsRecordChanged( void )
{
    int nFlds;
    int rc;
    int i;
    char buf1[MAXFIELDSIZE];
    char buf2[MAXFIELDSIZE];

    /* If the current record could not be retrieved (eg, the table is empty
       or another user deleted the record), return fail; in particular,
       FondexDlgProc will interpret this as a sign not to attempt to
       update the table.
       If the record could not be gotten, display an error message (unless
       the table is empty). */
    rc = PXRecGet( tblHandle, recHandle );
    if ( rc == PXERR_TABLEEMPTY )
        return FALSE;
    if ( rc )
    {
        Error( rc );
        return FALSE;
    }

    /*  Determine number of fields in a record */
    Error( PXRecNFlds( tblHandle, &nFlds ) );

    for ( i = 1; i <= nFlds; i++ )
    {
        /* Get string from field in Original record. */
        GetData( SaveRecHandle, i, buf1 );
        /* Get string from field in table's current record. */
        GetData( recHandle, i, buf2 );
        /* If any field differs, return TRUE. */
        if ( strcmp( buf1, buf2 ) )
            return TRUE;
    }
    return FALSE;
}


/*******************************************************************************

    Function:

        void DisplayRecord( void );

    Arguments:
        None

    Description:
        Displays the current record in a dialog box.  This function
        assumes hDlgModeless is the handle to a dialog box which is currently
        the top window and which has items corresponding to a fonedex record.

    Returns:
        None

******************************************************************************/

void DisplayRecord( void )
{
    char buf[MAXFIELDSIZE];
    int i;
    int rc;

    rc = PXRecGet( tblHandle, recHandle );
    Error( PXRecBufCopy( recHandle, SaveRecHandle ) );
    /* If the table is empty, display an empty record. */
    if ( rc != PXSUCCESS ) {
        if ( rc == PXERR_TABLEEMPTY ) {
            if ( ( Error( PXRecBufEmpty( recHandle ) ) ) ||
                     ( Error( PXRecBufEmpty ( SaveRecHandle ) ) ) )
                return;
        }
        else
            return;
    }
    for ( i = IDD_LASTNAMEEDIT; i <= IDD_NOTESEDIT; i++ )
    {
        if ( GetData( recHandle, i - IDD_FIRST + 1, buf ) != PXSUCCESS )
            return;
        SetDlgItemText( hDlgModeless, i, buf );
    }
}


/*******************************************************************************

    Function:

        void SetRecord( void );

    Arguments:
        None

    Description:
        Sets the fields of the record buffer identified by recHandle to the
        values in the edit controls of the dialog box.  This function
        assumes hDlgModeless is the handle to the dialog box which is currently
        the top window and which has items corresponding to a fonedex record.

    Returns:
        None

******************************************************************************/

void SetRecord( void )
{
    char buf[MAXFIELDSIZE];
    int i;

    for ( i = IDD_LASTNAMEEDIT; i <= IDD_NOTESEDIT; i++ )
    {
        GetDlgItemText( hDlgModeless, i, buf, MAXFIELDSIZE );
        PutData( i - IDD_FIRST + 1, buf );
    }
}


/******************************************************************************

    Function:

        void BlankDisplayedRecord( void );

    Arguments:
        None

    Description:
        Display a blank record.

    Returns:
        None

******************************************************************************/

void BlankDisplayedRecord( void )
{
    int i;

    /* Blank out fields in display */
    for ( i = IDD_LASTNAMEEDIT; i <= IDD_NOTESEDIT; i++ )
    {
        SetDlgItemText( hDlgModeless, i, "" );
    }
}


/*******************************************************************************

    Function:

        int GetData( RECORDHANDLE rechandle, FIELDHANDLE fh, char s[] );

    Arguments:
        rechandle               recordhandle of record
        FieldNumber             field number to retrieve data
        s                       string where data is stored

    Description:
        Retrieves in a string format any valid Paradox type.

    Returns:
        PXSUCCESS  No errors retrieving data
        FAIL     Error retrieving data

******************************************************************************/

int GetData( RECORDHANDLE rechandle, FIELDHANDLE fh, char s[] )
{
    long theDate;
    int month, day, year;
    double theValue;
    short theShort;
    int isBlank;

    /* if this field is blank, we want to return a blank string */
    if ( !Error( PXFldBlank( rechandle, fh, &isBlank ) ) )
    {
        if ( isBlank )
        {
            s[0] = '\0';
            return PXSUCCESS;
        }
    }
    else
        return FAIL;

    switch( types[fh-1][0] )
    {
        case 'a':
        case 'A':
            if ( Error( PXGetAlpha( rechandle, fh, BUFSIZ, s ) ) )
                return FAIL;
            break;
        case 'd':
        case 'D':
            if ( !Error( PXGetDate( rechandle, fh, &theDate ) ) )
            {
                PXDateDecode( theDate, &month, &day, &year );
                sprintf( s, "%d/%d/%d", month, day, year );
            }
            else
                return FAIL;
            break;
        case 'n':
        case 'N':
            if ( !Error( PXGetDoub( rechandle, fh, &theValue ) ) )
                sprintf( s, "%5.0lf", theValue );
            else
                return FAIL;
            break;
        case '$':
            if ( !Error( PXGetDoub( rechandle, fh, &theValue ) ) )
                sprintf( s, "%4.2lf", theValue );
            else
                return FAIL;
            break;
        case 's':
        case 'S':
            if ( !Error( PXGetShort( rechandle, fh, &theShort ) ) )
                sprintf( s, "%d", theShort );
            else
                return FAIL;
            break;
    }
    return( PXSUCCESS );
}


/*******************************************************************************

    Function:

        int PutData( FIELDHANDLE fh, char *s );

    Arguments:
        FieldNumber             field number to store data
        s                       string to be stored

    Description:
        Stores a string in any valid Paradox type.

    Returns:
        PXSUCCESS  No errors storing data
        FAIL     Error storing data

******************************************************************************/

int PutData( FIELDHANDLE fh, char *s )
{
    long theDate;
    int month, day, year;
    double theValue;
    short theShort;

    /* If the field is blank, put a blank into the record buffer. */
    if ( !strcmp( s, "" ) ) {
        if ( Error( PXPutBlank( recHandle, fh ) ) )
            return FAIL;
        else
            return PXSUCCESS;
    }
    switch( types[fh-1][0] )
    {
        case 'a':
        case 'A':
            if ( Error( PXPutAlpha( recHandle, fh, s ) ) )
                return FAIL;
            break;

        case 'D':
        case 'd':
            sscanf( s, "%d/%d/%d", &month, &day, &year );
            if ( ( Error( PXDateEncode( month, day, year, &theDate ) ) ) ||
                 ( Error( PXPutDate( recHandle, fh, theDate ) ) ) )
                return FAIL;
            break;

        case '$':
        case 'N':
        case 'n':
            sscanf( s, "%lf", &theValue );
            if ( Error( PXPutDoub( recHandle, fh, theValue ) ) )
                return FAIL;
            break;
        case 'S':
        case 's':
            sscanf( s, "%d", &theShort );
            if ( Error( PXPutShort( recHandle, fh, theShort ) ) )
                return FAIL;
            break;
    }

    return( PXSUCCESS );
}


/*******************************************************************************

    Function:

        int Error( int rc );

    Arguments:
        rc                  return code from a PX... function

    Description:
        Prints error message if an error has occurred.

    Returns:
        current error code

******************************************************************************/

int Error( int rc )
{
    char MessageBuffer[128];

    if ( rc != PXSUCCESS ) {
        sprintf( MessageBuffer, "FONEDEX: %s", PXErrMsg( rc ) );
        MessageBox( hDlgModeless, MessageBuffer, NULL, MB_OK | MB_ICONHAND );
    }

    return rc;
}


/******************************************************************************

    Function:

        void Message( char *message );

    Arguments:
        message             String to be printed in message box.

    Description:
        Prints message in a message box.

    Returns:
        None

******************************************************************************/

void Message( char *message )
{
    MessageBox( hDlgModeless, message, "Message", MB_OK | MB_ICONASTERISK );
}
