/*       Copyright (c) 1990, 1992 by Borland International, Inc.        */

/*
 * WFONEDEX.C Electronic file card application - Windows version
 *
 * Description: Allows simple database design and access of an electronic 
 *              file card database. Records can be added, deleted, updated 
 *              and searched in a multiuser environment.
 *
 * Compilation: To compile and link the example program with Turbo C 
 *              (and Borland Make files):
 *                
 *              make -fbcmake    (uses the file BCMAKE).
 *
 *              With MS C (and MS make):
 *
 *              make mscmake or nmk mscmake   (uses the file MSCMAKE).
 *
 * Execution: This example program runs under Windows. Choose
 *            wfonedex.exe from the file manager. (You can also either
 *            run the program or add it as an item to the File menu in
 *            the Window's Program Manager.)
 *
 *
 */

#include "wfonedex.h"

extern char szAppName[] = "Fonedex";  /* Application name. */
extern HANDLE hInst = 0;              /* Handle to current instance 
                                         of application. */

extern HWND hDlgModeless = 0;         /* Handle to modeless dialog box. */

/*********************************************************************

Function: int PASCAL WinMain( HANDLE hInstance, HANDLE hPrevInstance,
                       LPSTR lpszCmdLine, int nCmdShow );

Arguments: hInstance       HANDLE to current instance.
           hPrevInstance   HANDLE to previous instance of program.
           lpCmdLine       LPSTR command line.
           nCmdShow        Int (show-window) type.

Description: Creates modeless dialog box and processes message loop.

Returns:

**********************************************************************/

#ifdef __BORLANDC__
#pragma argsused       /* This pragma is used for Borland C++ */
#endif
int PASCAL WinMain(HANDLE hInstance, HANDLE hPrevInstance, 
             LPSTR lpszCmdLine, int nCmdShow)
{
  HMENU hMenu;
  MSG msg;

  if (hPrevInstance)
  {
    MessageBox(NULL, "Fonedex is already running.", "Windows Fonedex",
      MB_OK | MB_ICONINFORMATION);
      return 1;
  }

  hInst = hInstance;

  /* Create modeless dialog box. */

  hDlgModeless = CreateDialog(hInstance, szAppName, NULL,
    MakeProcInstance(FonedexDlgProc, hInstance));

  /* Add Help item to system menu. */

  hMenu = GetSystemMenu(hDlgModeless, FALSE);
  AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
  AppendMenu(hMenu, MF_BYCOMMAND | MF_STRING, IDM_ABOUT, "&About...");

  while (GetMessage(&msg, NULL, 0, 0))
  {
    if (hDlgModeless == 0 ||
      !IsDialogMessage(hDlgModeless, &msg))
    {
      TranslateMessage(&msg);
      DispatchMessage(&msg);
    }
  }
  return (msg.wParam);
}
