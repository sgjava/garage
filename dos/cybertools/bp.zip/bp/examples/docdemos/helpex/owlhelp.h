#define	cm_Print	104

/* define help items */

#define cm_About	300
#define cm_HelpIndex	301
#define cm_HelpKeyboard	302
#define cm_HelpHelp	303

