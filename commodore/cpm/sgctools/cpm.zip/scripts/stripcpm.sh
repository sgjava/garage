#!/bin/sh

# Strip $1a characters from CP/M files.

sed -i 's/\x1a//g' ~/.dosemu/drive_c/tmp/*.h
sed -i 's/\x1a//g' ~/.dosemu/drive_c/tmp/*.c
sed -i 's/\x1a//g' ~/.dosemu/drive_c/tmp/*.mak
sed -i 's/\x1a//g' ~/.dosemu/drive_c/tmp/*.sub

